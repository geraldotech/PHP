<?php


    echo $_POST['n1'];


?>

	