Requirements
- At least PHP 5.4.0 and MySQL 5
- Apache with mod_rewrite (nginx and other servers needs their own rewrite structure)
- Writing permission in /content and /images

Clean install
1. Upload the contents of the "chevereto" folder to your webserver
2. Go to http://yourwebsite.com and follow the instructions

Update from 3.X
1. Backup all your file changes (theme, routes, etc.)
2. Upload all the files and folders from "chevereto"
3. Login to your website (admin user) and then run http://www.mysite.com/install
Restore or merge your file changes (only if needed)
* Every release has a list of the affected files.
* This is useful if you are updating from immediate previous version and you don't want to overwrite all the files.
* If you are not updating from immediate previous version you should always do the step (2) of this list.

Update from 2.1 and newer
1. Save the DB connection info from includes/config.php
2. Save the __CHV_CRYPT_SALT__ that you have in includes/definitions.php
3. Upload all the files except for the images folder
4. Go to your website, the system will ask you for the DB connection info
5. Complete the process with the required information
6. The system MUST ask you for your __CHV_CRYPT_SALT__. If not, don't continue the process and ask for support

Update from 2.0.X and older
1. Update to 2.1 or newer using the instructions in those downloads
2. With the system updated you can now use the instructions for 2.1 and newer 