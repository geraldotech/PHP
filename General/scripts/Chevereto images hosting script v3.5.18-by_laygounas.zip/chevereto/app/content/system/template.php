<?php
/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
			<inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.
  
  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */
  
if(!defined('access') or !access) die('This file cannot be directly accessed.'); ?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $doctitle; ?></title>
<link rel="stylesheet" href="<?php echo G\absolute_to_url(CHV_PATH_PEAFOWL . 'peafowl.css'); ?>">
<link rel="stylesheet" href="<?php echo G\absolute_to_url(CHV_APP_PATH_SYSTEM . 'style.css'); ?>">
<link rel="shortcut icon" href="<?php echo G\absolute_to_url(CHV_APP_PATH_SYSTEM . 'favicon.png'); ?>">
</head>

<body>
	<div class="c20 center-box">
		<header id="header">
			<div id="logo"><img src="<?php echo G\absolute_to_url(CHV_APP_PATH_SYSTEM . 'chevereto.png'); ?>" alt=""></div>
		</header>
		<div id="content">
			<?php echo $html; ?>
		</div>
		<div id="powered">&copy; <a href="http://chevereto.com">Chevereto image hosting script</a></div>
	</div>
</body>

<script src="<?php echo G\absolute_to_url(CHV_PATH_PEAFOWL . 'js/jquery.min.js'); ?>"></script>
<script src="<?php echo G\absolute_to_url(CHV_PATH_PEAFOWL . 'js/scripts.js'); ?>"></script>
<script src="<?php echo G\absolute_to_url(CHV_PATH_PEAFOWL . 'peafowl.js'); ?>"></script>

<script>
PF.obj.l10n = <?php echo json_encode(CHV\get_translation_table()) ;?>;
</script>

</html>
