<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
			<inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.
  
  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */
  
namespace CHV;
use G, Exception;

$error_reporting_level = error_reporting();
error_reporting(E_ALL ^ E_NOTICE);

class L10n {
	
	private static $instance;
	const DEFAULT_SYSTEM_LANGUAGE_CODE = 'en';
	
	static $gettext, $translationtable, $available_languages;
	static $locale = 'en';
	
	public function __construct() {
		try {
			
			// Stock the available languages
			self::$available_languages = [];
			$directory = new \DirectoryIterator(CHV_APP_PATH_LANGUAGES);
			$regex  = new \RegexIterator($directory, '/^.+\.mo$/i', \RegexIterator::GET_MATCH);
			
			foreach($regex as $file) {
				$file = $file[0];
				$locale_code = basename($file, '.mo');
				self::$available_languages[$locale_code] = get_locales()[$locale_code];
			}	
			
			// Remove any missing lang array
			self::$available_languages = array_filter(self::$available_languages);
			
			// Set default website locale
			if(array_key_exists(getSetting('default_language'), self::$available_languages)) {
				$locale = getSetting('default_language');
			}
			
			// Auto-language?
			if(getSetting('auto_language') and !Login::isLoggedUser()) {
				foreach(G\get_client_languages() as $k => $v) {
					$user_locale = str_replace('-', '_', $k);
					if(array_key_exists($user_locale, self::$available_languages)) {
						$locale = $user_locale;
						break;
					} else {
						// try to use a base language
						foreach(self::$available_languages as $k => $v) {
							if($v['base'] == substr($user_locale, 0, 2)) {
								$locale = $k;
								break;
							}
						}
					}
					if($locale) break;	
				};
			}
			// Override with the user selected lang
			if(Login::isLoggedUser() or $_COOKIE['USER_SELECTED_LANG']) {
				$user_lang = Login::getUser() ? Login::getUser()['language'] : $_COOKIE['USER_SELECTED_LANG'];
				if(array_key_exists($user_lang, self::$available_languages)) {
					$locale = $user_lang;
				}
			}
			
			// Set some language definitions
			if(!defined('CHV_LANGUAGE_CODE')) define('CHV_LANGUAGE_CODE', $locale);
			if(!defined('CHV_LANGUAGE_FILE')) define('CHV_LANGUAGE_FILE', CHV_APP_PATH_LANGUAGES . $locale . '.mo');
			
			// Stock the static $locale
			self::$locale = $locale;
			
			// Stock the translation object and table array
			if(file_exists(CHV_LANGUAGE_FILE)){
				// Include php-Gettext
				require_once(CHV_APP_PATH_LIB_VENDOR . 'php-gettext.php');
				self::$gettext = new \Gettext_PHP(CHV_LANGUAGE_FILE);
				self::$translationtable = self::$gettext->translationTable;
			}
			
			self::$instance = $this;
			
		} catch (Exception $e) {
			throw new L10nException($e->getMessage(), 400);
		}
	}
	
	public static function getInstance() {
		if(is_null(self::$instance)) {
			self::$instance = new self;
		}
		return self::$instance;
	}
	
	public static function getStatic($var) {
		$instance = self::getInstance();
		return $instance::$$var;
	}
	
	public static function getAvailableLangs() {
		return self::getStatic('available_languages');
	}
	
	public static function getGettext() {
		return self::getStatic('gettext');
	}
	
	public static function getTranslation() {
		return self::getStatic('translationtable');
	}
	
	public static function getLocale() {
		return self::getStatic('locale');
	}

}

class L10nException extends Exception {}

error_reporting($error_reporting_level);