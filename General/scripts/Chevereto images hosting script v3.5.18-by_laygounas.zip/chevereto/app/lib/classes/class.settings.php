<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
			<inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.
  
  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */
  
namespace CHV;
use G, Exception;

class Settings {
	
	private static $instance;
	
	static $settings;
	static $defaults;
	
	public function __construct() {
		try {
			
			try {
				$db_settings = DB::get('settings', 'all', NULL, ['field' => 'name', 'order' => 'asc']);
				foreach($db_settings as $k => $v) {
					$v = DB::formatRow($v);
					$value = $v['value'];
					$default = $v['default'];
					if($v['typeset'] == 'bool') {
						$value = $value == 1;
						$default = $default == 1;
					}
					$settings[$v['name']] = $value;
					$defaults[$v['name']] = $default;
				}
				// Append some magic settings
				foreach(Login::getSocialServices(['get' => 'all']) as $k => $v) { // Must get all to avoid endless nesting
					if($settings[$k]) {
						$settings['social_signin'] = true;
						break;
					}
				}
				
			} catch(Exception $e) {
				$settings = [];
				$defaults = [];
			}
			
			if(!$db_settings) {
				//throw new Exception("Can't find any DB setting. Table seems to be empty.", 400);
			}
			
			// Inject the missing settings
			$injected = [
				// 3.3.0
				'listing_pagination_mode' 		=> 'classic',
				'website_mode'					=> 'public',
				'website_content_privacy_mode'	=> 'default',
				// 3.3.1
				'website_explore_page'	=> 1,
				// 3.2.0
				'theme_download_button'	=> 1,
				'enable_signups'		=> 1,
				'website_mode'			=> 'public',
				// 3.4.4
				'website_search'			=> 1,
				'website_random'			=> 1,
				'theme_show_social_share'	=> 1,
				'theme_show_embed_content'	=> 1,
				'theme_show_embed_uploader'	=> 1,
				// 3.4.5
				'user_routing'						=> 1,
				'require_user_email_confirmation'	=> 1,
				'require_user_email_social_signup'	=> 1,
				// 3.5.15
				'homepage_style'			=> 'landing',
				'logged_user_logo_link'		=> 'homepage',
			];
			
			// Default listing thing
			$device_to_columns = [
				'phone'  => 1,
				'phablet'=> 3,
				'tablet' => 4,
				'laptop' => 5,
				'desktop'=> 6
			];
			foreach($device_to_columns as $k => $v) {
				$injected['listing_columns_' . $k] = $v;
			}
			
			foreach($injected as $k => $v) {
				if(!array_key_exists($k, $settings)) {
					$settings[$k] = $v;
					$defaults[$k] = $v;
				}
			}
			
			// Virtual settings
			$settings['listing_device_to_columns'] = [];
			foreach($device_to_columns as $k => $v) {
				$settings['listing_device_to_columns'][$k] = $settings['listing_columns_' . $k];
			}
			
			// Harcoded settings
			$settings = array_merge($settings, [
				'username_min_length'		=> 3,
				'username_max_length'		=> 16,
				'username_pattern'			=> '^[\w]{3,16}$',
				'user_password_min_length'	=> 4,
				'user_password_max_length'	=> 255,
				'user_password_pattern'		=> '^.{4,255}$',
				'maintenance_image'			=> 'default/maintenance.jpg',
			]);
			
			if(!$settings['active_storage']) {
				$settings['active_storage'] = NULL;
			}
			
			self::$settings = $settings;
			self::$defaults = $defaults;
			
		} catch (Exception $e) {
			throw new SettingsException($e->getMessage(), 400);
		}
	}
	
	public static function getInstance() {
		if(is_null(self::$instance)) {
			self::$instance = new self;
		}
		return self::$instance;
	}
	
	public static function getStatic($var) {
		$instance = self::getInstance();
		return $instance::$$var;
	}
	
	public static function get($key=NULL) {
		$settings = self::getStatic('settings');
		if(!is_null($key)) {
			return $settings[$key];
		} else {
			return $settings;
		}
	}
	
	public static function getDefaults($key=NULL) {
		$defaults = self::getStatic('defaults');
		if(!is_null($key)) {
			return $defaults[$key];
		} else {
			return $defaults;
		}
	}
	
	public static function getDefault($key) {
		return self::getDefaults($key);
	}
	
	public static function setValues($values) {
		self::$settings = $values;
	}
	
	public static function setValue($key, $value) {
		$settings = self::getStatic('settings');
		self::$settings[$key] = $value;
	}

}

class SettingsException extends Exception {}