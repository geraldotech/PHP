<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
			<inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.
  
  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */

if(!defined('access') or !access) die('This file cannot be directly accessed.');

// Initiate the l10n class
new CHV\l10n;

/*** Set some functions in the global namespace ***/

// Gettext with parsed arguments
function _s($string, $args=NULL) {
	if(empty($string)) return $string;
	$gettext = CHV\L10n::getGettext();
	$string = !is_object($gettext) ? $string : $gettext->gettext($string);
	if($args) {
		$fn = is_array($args) ? 'strtr' : 'sprintf';
		$string = $fn($string, $args);
	}
	return $string;
}
// Same as _s but with echo
function _se($string, $args=NULL) {
	echo _s($string, $args);
}

// Plural version of _s
function _n($msg1, $msg2, $int) {
	if(empty($msg1)) return $msg1;
	$gettext = CHV\L10n::getGettext();
	$message = !is_object($gettext) ? ($int == 1 ? $msg1 : $msg2) : $gettext->ngettext($msg1, $msg2, $int);
	return _s($message, $int);
}
// Same as _n but with echo
function _ne($msg1, $msg2, $int) {
	echo _n($msg1, $msg2, $int);
}