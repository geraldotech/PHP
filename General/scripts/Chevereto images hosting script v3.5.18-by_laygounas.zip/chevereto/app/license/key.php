<?php

/* --------------------------------------------------------------------

  Chevereto
  http://chevereto.com/

  @author	Rodolfo Berrios A. <http://rodolfoberrios.com/>
			<inbox@rodolfoberrios.com>

  Copyright (C) Rodolfo Berrios A. All rights reserved.
  
  BY USING THIS SOFTWARE YOU DECLARE TO ACCEPT THE CHEVERETO EULA
  http://chevereto.com/license

  --------------------------------------------------------------------- */
  
$license = 'Ztdu:c1f439f62c51992edd3814ad554956e68edb0c0827cf88513547d854f97aa8c2ee82986edfa8c8f859ce639c8fc912105fd44192a2a2ef18ed992bfd96683843';