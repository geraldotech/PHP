<?php
$route = function($handler) {
	require_once(CHV_APP_PATH_INSTALL . 'installer.php');
};