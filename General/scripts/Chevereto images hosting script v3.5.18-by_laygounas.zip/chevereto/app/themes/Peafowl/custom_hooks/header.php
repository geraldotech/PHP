<?php
if(!defined('access') or !access) die('This file cannot be directly accessed.');
/* Add here your custom header code */
?>
