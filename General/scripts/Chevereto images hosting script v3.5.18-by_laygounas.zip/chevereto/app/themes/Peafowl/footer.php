<?php if(!defined('access') or !access) die('This file cannot be directly accessed.'); ?>

<div id="powered-by" class="footer">Powered by <a href="http://chevereto.com">Chevereto image hosting script</a></div>

<?php G\Render\include_theme_file('snippets/embed_tpl'); ?>

<?php
if(is_upload_allowed()) {
	G\Render\include_theme_file('snippets/anywhere_upload');
}
?>

<?php
if(!CHV\Login::isLoggedUser()) {
	G\Render\include_theme_file('snippets/modal_login');
}
?>

<?php G\Render\include_theme_file('custom_hooks/footer'); ?>

<?php CHV\Render\include_peafowl_foot(); ?>

<script src="<?php echo CHV\Render\versionize_src(G\Render\get_app_lib_file_url('chevereto.js')); ?>"></script>

<?php if(CHV\getSetting('website_search')) { ?>
<script type="application/ld+json">
{
	"@context": "http://schema.org",
	"@type": "WebSite",
	"url": "<?php echo G\get_base_url(); ?>",
	"potentialAction": {
		"@type": "SearchAction",
		"target": "<?php echo G\get_base_url('search/images/?q={q}'); ?>",
		"query-input": "required name=q"
	}
}
</script>
<?php } ?>

<script>
PF.obj.config.base_url = "<?php echo G\get_base_url(); ?>";
PF.obj.config.json_api = "<?php echo G\get_base_url('json'); ?>";
PF.obj.config.listing.items_per_page = "<?php echo CHV\getSetting('listing_items_per_page'); ?>";
PF.obj.config.listing.device_to_columns = <?php echo json_encode(CHV\getSetting('listing_device_to_columns')); ?>;
PF.obj.config.auth_token = "<?php echo get_auth_token(); ?>";

PF.obj.l10n = <?php echo json_encode(CHV\get_translation_table()) ;?>;

if(typeof CHV == "undefined") {
	CHV = {obj: {}, fn: {}, str:{}};
}

CHV.obj.vars = {
	urls: {
		home: PF.obj.config.base_url,
		search: "<?php echo G\get_base_url("search"); ?>"
	}
};

CHV.obj.config = {
	image : {
		max_filesize: "<?php echo CHV\getSetting('upload_max_filesize_mb') . ' MB'; ?>"
	},
	user: {
		avatar_max_filesize: "1 MB",
		background_max_filesize: "1 MB"
	}
};

<?php
	$logged_user = CHV\Login::getUser();
	if($logged_user) {
		$logged_user_array = [];
		foreach(['name', 'username', 'id', 'url', 'url_albums'] as $arr) {
			$logged_user_array[$arr] = $logged_user[$arr == 'id' ? 'id_encoded' : $arr];
		}
		
?>
CHV.obj.logged_user = <?php echo json_encode($logged_user_array); ?>;
<?php
	}
	if($logged_user['is_admin']) {
?>
CHV.obj.system_info = <?php echo json_encode(['version' => G\get_app_version()]); ?>;
<?php	
	}
?>

<?php
if(!G\isPreventedRoute() and !is_404() && in_array(G\get_route_name(), ["image", "album", "user", "settings"]) or (function_exists('is_dashboard_user') and is_dashboard_user())) {
	if(in_array(G\get_route_name(), ["settings", "dashboard"])) {
		$route = ['id'	=> NULL, 'url'	=> NULL];
		$route_user = get_user();
	} else {
		$route_fn = "get_".G\get_route_name();
		$route = $route_fn();
		$route_user = G\get_route_name() == "user" ? $route : $route["user"];
	}
?>
CHV.obj.resource = {
	id: "<?php echo $route["id_encoded"]; ?>",
	type: "<?php echo G\get_route_name(); ?>",
	url: "<?php echo (G\get_route_name() == "image" ?  $route["url_viewer"] : $route["url"]); ?>",
	parent_url: "<?php echo G\get_route_name() == "image" ? get_image()['album']['url'] : (G\get_route_name() == 'dashboard' ? NULL : $route_user['url']) ?>"
};

<?php
	if($route_user["id"]) {
?>
CHV.obj.resource.user = {
	name: "<?php echo G\safe_html($route_user["name"]); ?>",
	username: "<?php echo G\safe_html($route_user["username"]); ?>",
	id: "<?php echo $route_user["id_encoded"]; ?>",
	url: "<?php echo $route_user["url"]; ?>",
	url_albums: "<?php echo $route_user["url_albums"]; ?>"
};
<?php
	}
}
?>
</script>

<?php CHV\Render\show_queue_img(); ?>

</body>
</html>