<?php if(!defined('access') or !access) die('This file cannot be directly accessed.'); ?>
<div class="input-label c7">
	<label for="form-storage-name"><?php _se('Name'); ?></label>
	<input type="text" id="form-storage-name" name="form-storage-name" class="text-input" placeholder="<?php _se('Storage name') ?>" required maxlength="32">
</div>
<div class="input-label c5">
	<label for="form-storage-api_id"><?php _se('API'); ?></label>
	<select name="form-storage-api_id" id="form-storage-api_id" class="text-input" data-combo="storage-combo">
		<option value="1">Amazon S3</option>
		<option value="5">FTP</option>
		<option value="6">SFTP</option>
	</select>
</div>
<div id="storage-combo">
	<div data-combo-value="1" class="input-label c7 switch-combo">
		<label for="form-storage-region"><?php _se('Region'); ?></label>
		<select name="form-storage-region" id="form-storage-region" class=" text-input">
			<?php foreach(CHV\Storage::getAPIRegions('s3') as $k => $v) { ?>
			<option value="<?php echo $k; ?>"><?php echo $v; ?></option>
			<?php } ?>
		</select>
	</div>
	<div data-combo-value="1" class="switch-combo">
		<div class="input-label c7">
			<label for="form-storage-bucket">Bucket</label>
			<input type="text" id="form-storage-bucket" name="form-storage-bucket" class="text-input" placeholder="<?php _se('Storage bucket') ?>" required>
		</div>
		<div class="input-label c7">
			<label for="form-storage-key"><?php _se('Key'); ?></label>
			<input type="text" id="form-storage-key" name="form-storage-key" class="text-input" placeholder="<?php _se('Storage key') ?>" required>
		</div>
		<div class="input-label c7">
			<label for="form-storage-secret"><?php _se('Secret'); ?></label>
			<input type="text" id="form-storage-secret" name="form-storage-secret" class="text-input" placeholder="<?php _se('Storage secret') ?>" required>
		</div>
	</div>
	<div data-combo-value="5 6" class="switch-combo soft-hidden">
		<div class="input-label c7">
			<label for="form-storage-server"><?php _se('Server'); ?></label>
			<input type="text" id="form-storage-server" name="form-storage-server" class="text-input" placeholder="<?php _se('Server') ?>" required rel="template-tooltip" data-tiptip="right" data-title="<?php _se('Hostname or IP of the storage server'); ?>">
		</div>
		<div class="input-label c7">
			<label for="form-storage-bucket"><?php _se('Path'); ?></label>
			<input type="text" id="form-storage-bucket" name="form-storage-bucket" class="text-input" placeholder="<?php _se('Server path') ?>" required rel="template-tooltip" data-tiptip="right" data-title="<?php _se('Server path where the files will be stored'); ?>">
		</div>
		<div class="input-label c7">
			<label for="form-storage-key"><?php _se('Username'); ?></label>
			<input type="text" id="form-storage-key" name="form-storage-key" class="text-input" placeholder="<?php _se('Server username') ?>" required>
		</div>
		<div class="input-label c7">
			<label for="form-storage-secret"><?php _se('Password'); ?></label>
			<input type="text" id="form-storage-secret" name="form-storage-secret" class="text-input" placeholder="<?php _se('Server password') ?>" required>
		</div>
	</div>
	<div class="input-label">
		<div class="c7">
			<label for="form-storage-capacity"><?php _se('Storage capacity'); ?></label>
			<input type="text" id="form-storage-capacity" name="form-storage-capacity" class="text-input" placeholder="<?php _se('Example: 20 GB, 1 TB, etc.') ?>">
		</div>
		<div class="input-below"><?php _se('This storage will be disabled when it reach this capacity. Leave it blank or zero for no limit.'); ?></div>
	</div>
	<div class="input-label">
		<label for="form-storage-url">URL</label>
		<input type="text" id="form-storage-url" name="form-storage-url" class="text-input" placeholder="<?php _se('Storage URL') ?>" required>
		<div class="input-below"><?php _se('The system will map the images of this storage to this URL.'); ?></div>
	</div>
</div>