<?php if(!defined('access') or !access) die('This file cannot be directly accessed.'); ?>

<div class="content-empty">
	<span class="icon icon-drawer"></span>
	<h2><?php _se("There's nothing to show here."); ?></h2>
</div>