<div class="list-item-thumbs-container">
	<ul class="list-item-thumbs">
		<li>%1<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_1_THUMB_URL%" alt=""></a>%1</li>
		<li>%2<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_2_THUMB_URL%" alt=""></a>%2</li>
		<li>%3<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_3_THUMB_URL%" alt=""></a>%3</li>
		<li>%4<a href="%ALBUM_URL%"><img src="%ALBUM_IMAGES_SLICE_4_THUMB_URL%" alt=""></a>%4</li>
	</ul>
</div>