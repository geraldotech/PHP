<div class="list-item-desc">
	<div class="list-item-overflow"><?php _se('Uploaded by guest to Public'); ?></div>
</div>