<ul class="list-item-image-tools soft-hidden hover-display" data-action="list-tools">
	<li class="tool-select" data-action="select"><span data-icon-selected="icon-ok" data-icon-unselected="icon-checkbox-unchecked" class="btn-icon icon-checkbox-unchecked"></span><span class="label label-select"><?php _se('Select'); ?></span></li>
	<li class="tool-delete" data-action="delete"><span class="btn-icon icon-remove"></span><span class="label label-delete"><?php _se('Delete'); ?></span></li>
</ul>