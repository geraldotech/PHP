<?php
require_once( 'photo.php' );
?>