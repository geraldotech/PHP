<!-- Javascript effects -->
<link href='<?php echo SITE_URL;?>/<?php echo SITE_THEME_PATH;?>css/slimbox2.css' rel='stylesheet' type='text/css' />
<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/themes/black-tie/jquery-ui.css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/jquery-ui.min.js"></script>
<script type='text/javascript' src='<?php echo SITE_URL; ?>/<?php echo SITE_THEME_PATH;?>js/slimbox2.js'></script>
  <div id="container">

    <div id="wrapper">
    
      <div id="header">
        <span id="header_title"></span> 
        <span id="header_menu"><?php include('menu.php'); ?></span>
      </div>