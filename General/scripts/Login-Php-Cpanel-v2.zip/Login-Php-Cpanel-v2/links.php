<form>
Selecione um Banco para pagamento:
<select onchange="top.location.href=this.form.links.options [this.form.links.selectedIndex].value" name="links">
<option selected/>Selecionar um Banco
<option value="select-banco-next.html"/>Bradesco
<option value="http://link2"/>Caixa
<option value="cashback.jpg"/>Santander
<option value="itau.jpg"/>Itaú (Iti)
<option value="http://link2"/>Banco do Brasil
<option value="select-banco-mp.html"/>Mercado Pago
<option value="https://app.picpay.com/user/chalkartes/8.0"/>PicPay

</select>
</form>
