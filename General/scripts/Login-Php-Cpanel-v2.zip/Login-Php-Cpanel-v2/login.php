<!DOCTYPE html>
<html lang="pt-br">

<head>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Geral Notes - 2020</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS: You can use this stylesheet to override any Bootstrap styles and/or apply your own styles -->
    <link href="css/custom.css" rel="stylesheet">
</head>
    <meta charset="UTF-8">
    <title>SmartGNN - Login</title>
</head>

<body>

    <?php
    //    "eXcript" != "excript"
    $login = "gera";
    $senha = "123";
         echo '<span style="font-size:20px;text-align:center;">Only Premium Users</span>';
     if(isset($_POST["login"])){
    //        echo $_POST["login"] . "<br>";
    //        echo $_POST["senha"];
        if($_POST["login"] == $login and $_POST["senha"] == $senha){
           
  //  echo "<p><center>Login sucesso</center></p>";
		  echo '<center><span style="color:#458B00;text-align:center;font-size:20px;">Sucess!</span></center>';
          echo nl2br("\n WELCOME");
	include 'dropdown.php';
	include 'menu.html';
	include 'pix.php';
	//include 'img.php';
	include 'footer.php';


        }else{
            echo "Login or password erros";
        }
    }

    ?>
<center>
<p><h1>Smart Login</h1>
    <form method="post">
        <input type="text" name="login"><br>
        <input type="password" name="senha"><br>
        <input type="submit">
    </form>
</center>
</body>


</html>