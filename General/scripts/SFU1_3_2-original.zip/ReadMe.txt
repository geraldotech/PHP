---------------------------------------
#    Simplicity oF Upload == Jamal    #
---------------------------------------
            Version 1.3.2
---------------------------------------

Description:
------------
This script is easy to integrate in any other PHP script !
it allowes you to upload multiple files to your server easily, it's also safe to upload
server executable files like PHP, ASP, CGI .. etc

What does Jamal mean anyway ?
-----------------------------
Jamal means Beauty in Arabic!
I believe that simplcity in anything is "Jamal"!
When you can achive what you want with ease and simplcitiy, this IS beauty IMHO :D

License/Price:
--------------
this script is FREE but not to be used in porn/adult websites.
you can modify it if you want. all I ask for is to keep the ORIGINAL powered by text
above the upload button! if you don't like its place, change its place!
just make sure that the upload page contains something says that this upload
page is powered by Simplcity oF Upload ..
you may not redistribute this script. you may use this script in your other FREE
projects but I must be notified about it and credited for that.

---------------
IMPORTANT NOTE:
---------------
use this script at your own risk! misconfiguring the script may lead
to unwanted results and high risks because the script is all about
file upload and user input.
so read the notes you see in SFUConfig.php and this file ***CAREFULLY***
before you use this script!

Key Features:
-------------
-Multiple files upload.
-Extensions check.
-Extensions attributes.
-Max file size control.
-Show content after uploading.
-Change mode of the uploaded file.
-Ability to avoid files overwriting.
-Password protection.
-Email notification for upload.
-Log upload attempts in txt files.
-lots of small stuff that'll help you customizing the script performance.
-FREE :)

-- Multiple files upload:
pretty obvious, you can upload multiple files at a time !

-- Extensions check:
you can limit your users to upload certine type of files only !

-- Extensions attributes:
specify the allowed extensions that can be uploaded and how they will be
treated with attributes.. for example the attribute 'image' will take pictures and
display them in HTML's proper img tag, some files may be risky to upload so you
can set the attribute 'exec' so they will be renamed into txt files so
they will not be excuted ..

List of Attributes:
==================
-image  : will treat file as an image and will be displayed if needed!
-text   : these files will not be touched at all and their contents wont be checked, so
          becarful when you use this one.
-exec   : these files (like php, asp, cgi ..etc) may contain harmful codes
   	      that may harm your server so their content will be converted into safe-plain text
          and saved into a new .txt file.
-Package: files like zip and exe is best to be uploaded with this attribute! in general,
          any binary file that isn't an image goes here.
   END OF LIST
==================

--Show content after uploading:
you can either show the content of the files after they are uploaded and treated with
their attributes or not !
you can choose to show the images only, text files only , both of them or neither of them!

--Change mode of the uploaded file:
you can enable changing mode of the uploaded file, all you need to do is to enable this
feature and set the mode you want in the SFUConfig.php file.

--Ability to avoid files overwriting:
with an option in the configuration file, you can enable/disable files
overwriting, just as simple as writing true/false ;)

--Password protection:
now you can protect the upload form with a universal password so not anyone can
upload to your website.

--Email notification for upload:
enable this feature, and an email will be sent to you with information about any upload attemp
whether it succed or fail.
the message will have the IP address of the uploader and the files which the uploader tried to
upload.

--Log upload attempts in txt files:
with this feature enabled, text files will be created.
the files will be named after the uploader IP and it will contain the status of the
upload (succes or fail), the date and time of the upload along with the file name.

--lots of small stuff that'll help you customizing the script performance:
you can:
  * make the script fully HTMLed with Metatags!
  * highlight PHP files and save them into plain safe HTML files.
  * allow the users to change the number of upload fields.
  * use language files to translate the script to your own language!
  * enable/disable listing of succesful uploads.
  * enable/disable listing of errors occurred during the process.
  * list the files in the upload directory and limit them to the allowed extensions only.
  * show the upload limits before actually uploading.

--FREE:
it's FREE for non-commercial use, just keep the original "powered by" text ..
if you want to use it commercially email me at: saleh@phpsimplicity.com

ALL these features can be configured in SFUConfig.php file

Installation:
-------------
the package contains:
-upload.php    (Main Script)
-SFUConfig.php (Configuration File)
-functions.php (functions file)
-arabic.lng    (Arabic Language File)
-english.lng   (English Language File)
-ReadMe.txt    (this file)
-History.txt   (changes log file)
-FAQ.txt       (Frequently Asked Questions)
-realPath.php  (Find real path)

simply upload the core files:
-SFUConfig.php (after configuring)
-upload.php
-functions.php
and the language file(s) you want to the folder where you want to use them in!

note that you have to make all files in the same directory or you will have to edit
the files to point to the right directory!

make sure that you configure your script by editing SFUConfig.php before using the script!
you need to specify the real path of the uploads folder and the URL leading to it!
the URL would be easy to specify , but if you don't know how to find the real path then
run the file realPath.php and copy the path you see to the SFUConfig.php file. maker sure you 
delete the file (realpath.php) after using it!
one important thing to do, you MUST change mode of the directory that you will upload
your files into to permession 777 so you can allow uploading, otherwise you will get
an error and your uploads will allways fail!
changing mode can be done with most of FTP client programmes.

if you enabled files logging, you have to create a new dirctory where ever you want
and put its real path in the line you find in SFUConfig.php which looks like:
$log_path = '/home/usr/public_html/log/';
to know the realpath, just do as you did to before to find the upload real path ..

if you enabled email notification you have to set your email address in the variable $admin_email

after you configure the script,
if you want to integrate it to your site just add this line where you want to use it:

require_once('path/to/upload.php');

or call upload.php directly.
that's it ! :D

Author:
-------
Saleh F. Jamal (saleh@phpsimplicity.com)
aka NeverMind  (nevermind@phpsimplicity.com)

Suggestions/Comments:
---------------------
if you found any bug or have any suggestions/comments please visit the forum and post there
(Guest posting is allowed)
http://forum.phpsimplicity.com/


--------------------------------------
/* 1427-2006 Copy rights reserved to
     Saleh F. Jamal aka NeverMind   */
--------------------------------------
