<font size="6"><b>SFU RealPath Finder</b></font><br /><br />
<?php

echo 'Just copy what\'s in the text box below and paste it in the SFUConfig.php constant, SFU_REALPATH:<br /><br />

<input type="text" size="100" value="', dirname(__FILE__), '/" id="realpath" /><br /><br />

<font color="red">MAKE SURE YOU DELETE THIS FILE AFTER FINISHING!</font>';
?>