<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Y5SEDXH2BM"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-Y5SEDXH2BM');
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/mystyle2.css">

</head>
<div class="header">
 <p><a href="index.php">Fast Storage Direct link</a></p>
</div>
<p>
<div class="subheader">
<p>Hosting static website pages</p>
<p>.pdf .html .css .jpg . jpeg .png .gif .zip .txt</p>
</div>
<div class="limit">
<p>MAX: 10MB </p>
</div>
<p style="text-align:center;">Short custom page file: <strong>http://cdn.gpnote.tech/files</strong>MyCustompage.html</p>







