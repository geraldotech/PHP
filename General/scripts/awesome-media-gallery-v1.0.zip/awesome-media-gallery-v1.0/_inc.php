<?php
//ini_set('error_reporting', E_ALL);

/////// MOKOALA ///////////
// This file initializes Mokoala
require_once 'admin/library/com/mokoala/Mokoala.php';

// The next logical redirect page
$logical_redirect = (!empty($config->site->referer) && $config->site->referer === $config->site->page ? '/' : $config->site->referer);

// Get an instance of the session object
$session = MK_Session::getInstance();

// Get an instance of the config object
$config = MK_Config::getInstance();

// Get an instance of the cookie object
$cookie = MK_Cookie::getInstance();

// Is Mokoala installed?
if( !$config->site->installed )
{
	header("Location: ".MK_Utility::serverUrl("admin/"), true, 302);
	exit;
}

// Connect to the database
MK_Database::connect(MK_Database::DBMS_MYSQL, $config->db->host, $config->db->username, $config->db->password, $config->db->name);

// If user is logging in decide which page they are redirected to next
if( !$config->extensions->core->login_url )
{
	$login_redirect = ltrim($logical_redirect, '/');
}
else
{
	$login_redirect = !empty($config->extensions->core->login_url) ? $config->extensions->core->login_url : '/';	
}

//GET USER INSTANCE
$user_module = MK_RecordModuleManager::getFromType('user');

//MOBILE DETECT
require('includes/Mobile_Detect.php');
global $deviceType;
$detect = new Mobile_Detect;
$deviceType = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer');
$scriptVersion = $detect->getScriptVersion();

//ENGAGE FUNCTIONS. DH 21/08
include ('includes/functions.php');

//SOCIAL LOGIN FUNCTIONS
include ('includes/functions-social-login.php');

// If user session has expired but cookie is still active
if( $cookie->login && empty($session->login) )
{
	$session->login = $cookie->login;
}

// Get current user
if( !empty($session->login) )
{
    MK_Authorizer::authorizeById( $session->login );
}

$user = MK_Authorizer::authorize();

$this_filename = explode('/', $_SERVER['SCRIPT_NAME']);
$this_filename = array_pop($this_filename);
$head_title = array($config->site->name);

//HELPER CLASSES. DH 27/11

//Pluralize
include ('includes/classes/pluralize.php');

//Less Complier
include ('includes/classes/lessc.inc.php');


//CREATE ARRAYS FOR EDITABLE
//GET GALLERIES
$num = 0;
$gallery_list = MK_RecordModuleManager::getFromType('image_gallery'); //Gallery Info


if($gallery_list->records() != NULL) {

    foreach($gallery_list->getRecords() as $gallery) {
        $gallery_id_array[$num] = $gallery->getId();
        $gallery_name_array[$num] = $gallery->getName();;
        $num++;
    }

    $gallery_id_array_encoded = json_encode($gallery_id_array);
    $gallery_name_array_encoded = json_encode($gallery_name_array);
    $galleries_array_combined = array_combine($gallery_id_array,$gallery_name_array);

    $num = 0;
    $galleries_data = "{ ";

    $total = sizeof($gallery_id_array);

    foreach($gallery_id_array as $value) {
        $galleries_data .= "'" . $value . "' : '" . $gallery_name_array[$num] . "'";
        if ($total<>$num) { $galleries_data .= ",";}
        $num++;	
    }
    $galleries_data .= " }";
    
}


//GET USER TYPES 
$num = 0;
$users_types_list = MK_RecordModuleManager::getFromType('user_type'); //User Category

foreach($users_types_list->getRecords() as $users_types) {
	$users_types_id_array[$num] = $users_types->getId();
	$users_types_name_array[$num] = $users_types->getTitle();;
	$num++;
}

$users_types_id_array_encoded = json_encode($users_types_id_array);
$users_types_name_array_encoded = json_encode($users_types_name_array);
$users_types_array_combined = array_combine($users_types_id_array,$users_types_name_array);

$num = 0;
$users_types_data = "{ ";

$total = sizeof($users_types_id_array);

foreach($users_types_id_array as $value) {
	$users_types_data .= "'" . $value . "' : '" . $users_types_name_array[$num] . "'";
	if ($total<>$num) { $users_types_data .= ",";}
	$num++;	
}

$users_types_data .= " }";




?>