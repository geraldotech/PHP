<?php
//IMPORTANT QUERY PARAMETERS

//Gets
$section       = (MK_Request::getQuery('section')<>'')    ? htmlspecialchars(MK_Utility::sanitize(MK_Request::getQuery('section'), true, true )) : '';
$order_by      = (MK_Request::getQuery('order-by')<>'')   ? MK_Utility::sanitize(MK_Request::getQuery('order-by'), true, true ) : '';
$gallery_type  = (MK_Request::getQuery('media')<>'')      ? MK_Utility::sanitize(MK_Request::getQuery('media'), true, true ) : '';
$image_id      = (MK_Request::getQuery('image')<>'')      ? MK_Utility::sanitize(MK_Request::getQuery('image'), true, true ) : '';
$gallery_id    = (MK_Request::getQuery('gallery')<>'')    ? MK_Utility::sanitize(MK_Request::getQuery('gallery'), true, true ) : '';
$action        = (MK_Request::getQuery('action')<>'')     ? MK_Request::getQuery('action') : '';
$comment_id    = (MK_Request::getQuery('comment')<>'')    ? MK_Utility::sanitize(MK_Request::getQuery('comment'), true, true ) : '';
$user_id       = (MK_Request::getQuery('user')<>'')       ? MK_Utility::sanitize(MK_Request::getQuery('user'), true, true ) : '';
$user_name     = (MK_Request::getQuery('username')<>'')   ? MK_Utility::sanitize(MK_Request::getQuery('username'), true, true ) : '';
$platform      = (MK_Request::getQuery('platform')<>'')   ? MK_Utility::sanitize(MK_Request::getQuery('platform'), true, true ) : ''; 
$tag           = (MK_Request::getQuery('tag')<>'')        ? MK_Utility::sanitize(MK_Request::getQuery('tag'), true, true ) : '';
$slug          = (MK_Request::getQuery('slug')<>'')       ? MK_Utility::sanitize(MK_Request::getQuery('slug'), true, false ) : '';

//Posts
$search_keywords = (MK_Request::getQuery('s')<>'')      ? MK_Utility::sanitize(MK_Request::getQuery('s'), true, false ) : '';

//SET GALLERY TYPE NAME
$image_type_name = '';

if ($gallery_type == 1) {

	$image_type_name = 'images';

} elseif ($gallery_type == 2) {

	$image_type_name = 'videos';

}


//Page Names
$home_page    = 'index.php'; 
$image_page   = 'image.php';
$member_page  = 'member.php';
$members_page = 'members.php';

//VARIABLES
$footer_caption      = $config->site->caption;
$footer_copyright    = 'Copyright &copy; ' . (date("Y") - 1) . '-' . date("Y") . ' ' . $config->site->name;
$modal_logo_path     = $config->site->logo; //'img/logo-modal.png'


// HEIGHTS AND WIDTHS
$mwsi = 993; // max_width_single_image;
$mhsi = 2000; // max_height_single_image;

$wci = 100; // width_carrousel_image;
$hci = 100; // height_carrousel_image;

$wca = 100; // width_comment_avatar;
$hca = 100; // height_comment_avatar;

$wib = 480; // width_image_box;
$hib = 360; // height_image_box;





//PLACEHOLDERS FOR EDITABLE FIELDS
$txt_placeholder_arr                    = array();
$txt_placeholder_arr['display_name']    = '(Choose a name)';
$txt_placeholder_arr['username']        = '(Choose a username)';
$txt_placeholder_arr['region']          = '(Enter your location)';
$txt_placeholder_arr['website']         = '(Enter your website)';
$txt_placeholder_arr['about']           = '(Add a description about you)';
$txt_placeholder_arr['demo_reel_url']   = '(Add a link to your video)';
$txt_placeholder_arr['skills']          = '(Add a summary of your skills and experience)';
$txt_placeholder_arr['software']        = '(Add a description about your favorite software and tools)';
$txt_placeholder_arr['category']        = '(Choose a category)';
$txt_placeholder_arr['gender']          = '(Add a gender)';
$txt_placeholder_arr['occupation']      = '(Add an occupation)';
$txt_placeholder_arr['resume_url']      = '(Add a link to your resume)';
$txt_placeholder_arr['facebook_url']    = '(Add link to Facebook profile)';
$txt_placeholder_arr['twitter_url']     = '(Add link to Twitter profile)';
$txt_placeholder_arr['google_url']      = '(Add link to Google profile)';
$txt_placeholder_arr['linkedin_url']    = '(Add link to LinkedIn profile)';
$txt_placeholder_arr['kickstarter_url'] = '(Add link to Kickstarter profile)';
$txt_placeholder_arr['years_of_experience'] = '0';
$txt_placeholder_arr['description']     = '(Add a description)';

$freelancing = false; //MAKE TRUE IF YOU WANT TO ENABLE FREELANCING OPTIONS - NOT TESTED ?>