<div class="block">
    <h2>Dashboard / Installed Components</h2>
    <p>Select which components are already already installed and which area available to install.</p>

<?php
	print $this->form;
?>
</div>
