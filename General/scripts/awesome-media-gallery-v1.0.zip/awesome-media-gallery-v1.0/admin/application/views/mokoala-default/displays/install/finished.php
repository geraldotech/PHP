<div class="block clear-fix">
    <h2>Installation</h2>
    <h3>Finished</h3>
    <p>And that's it. Don't worry if you made any mistakes or want to change things in the future as everything is editable via the <a href="<?php print $this->uri( array('controller' => 'dashboard', 'section' => 'settings') ); ?>">Settings</a> page.</p>
    <p>Since you've just created your account you have been automatically logged in.</p>
    <div class="clear-fix form-field-link field-nextfinish">
        <a href="<?php print $this->uri( array('controller' => 'dashboard' )); ?>">Proceed to Dashboard</a>
    </div>
</div>