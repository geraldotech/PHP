    <div class="block">
<h2>Installation</h2>
    <h3>Step 3: Your Account</h3>
    <p>All that's left is to create your user account. Don't worry if you've made any mistakes you can always go back!</p>
    <?php print $this->install_form; ?>
</div>