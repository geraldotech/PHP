
<div class="block">
    <h2><?php print $this->module->getName(); ?> / <?php print $this->title; ?></h2>
    <?php
    
        print $this->form;
    
    ?>
</div>