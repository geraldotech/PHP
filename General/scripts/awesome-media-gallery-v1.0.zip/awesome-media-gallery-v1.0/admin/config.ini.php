db.host = ""
db.name = ""
db.username = ""
db.password = ""
site.upload_path = "tpl/uploads/"
site.installed = "0"
site.name = ""
site.desc = "Awesome Media Gallery is the best social image and video sharing php framework. Users can upload images, photos, videos, and receive comments, likes, and follows."
site.default_avatar = "tpl/uploads/default-avatar.png"
site.caption = "A Community to Join, Upload, and Like"
site.enable_footer = "1"
site.email = ""
site.email_signature = 
site.url = ""
site.mode = "product"
site.date_format = "Y-m-d"
site.error_reporting = "0"
site.time_format = "H:i:s"
site.template = "mokoala-default/default"
site.valid_file_extensions = "pdf,doc,docx,ppt,pptx,pps,ppsx,odt,xls,xlsx,mp3,m4a,ogg,wav,mp4,m4v,mov,wmv,avi,mpg,ogv,3gp,3g2,jpg,jpeg,jpe,jif,jfif,jfi,gif,png,7z,zip,rar"
site.timezone = "America/New_York"
user.timeout = "31556926"
site.log_actions = "1"
extensions.core.email_verification = "0"
extensions.core.logout_url = 
extensions.core.login_url = 
extensions.core.register_url = 
db.prefix = "mk_"
extensions.gallery.display_mode = "images"
extensions.gallery.filter_style = "link-list"
extensions.gallery.image_list_mode = "complex"
extensions.gallery.image_comments = "1"
extensions.gallery.search = "1"
site.analytics = 
site.email_template = "&lt;html&gt;
&lt;head&gt;
&lt;style type=&quot;text/css&quot;&gt;
html, body{
  font-family:Georgia, &quot;Times New Roman&quot;, Times, serif;
  text-align:center;
}

a{ color:#ac4a4a; }

h1{
font-size:40px;
font-weignt:bold; 
text-align:center;
padding: 20px 0 10px 0;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;table align=&quot;center&quot; style=&quot;margin:0 auto 0 auto; text-align:left; width:600px;&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot; border=&quot;0&quot;&gt;
&lt;tr&gt;
&lt;td&gt;&lt;h1&gt;{site_name}&lt;/h1&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td style=&quot;border-top:1px solid #d4d4d4; padding:15px  0 15px 0;&quot;&gt;{email_content}&lt;/td&gt;
&lt;/tr&gt;
&lt;/table&gt;
&lt;/body&gt;
&lt;/html&gt;"
site.email_text_signup = "&lt;p&gt;Dear {user_display_name},&lt;br /&gt;&lt;br /&gt;Thank you for signing up.&lt;br /&gt;&lt;br /&gt;Please enjoy your time within &lt;a href=&quot;http://awesome-gallery.engagefb.com&quot;&gt;our community&lt;/a&gt;.&lt;/p&gt;"
site.email_text_verfification = "&lt;p&gt;Dear {user_display_name},&lt;br /&gt;&lt;br /&gt;Thank you for registering your account at {site_name}. Please click the link below (or copy it into your browser) to verify your email address. We look forward seeing you there !&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;{verification_link}&quot;&gt;{verification_link}&lt;/a&gt;.&lt;/p&gt;
"
extensions.core.email_admin_signup = "1"
site.logo = "tpl/uploads/awesomemediagallerylogo.png"
site.logo_sticky = "tpl/uploads/awesomemediagallerylogosticky.png"
site.adhome728x90 = ""
site.adhome242x90 = ""
site.adsidebar160x600 = ""
site.dev_mode = "1"
site.facebook.app_id = ""
site.facebook.app_secret = ""
site.facebook.login = "0"
site.twitter.app_key = ""
site.twitter.app_secret = ""
site.twitter.login = "0"
site.yahoo.client_id = ""
site.yahoo.client_secret = ""
site.yahoo.login = "0"
site.windowslive.client_id = ""
site.windowslive.client_secret = ""
site.windowslive.login = "0"
site.google.client_id = ""
site.google.client_secret = ""
site.google.login = "0"
site.linkedin.client_id = ""
site.linkedin.client_secret = ""
site.linkedin.login = "0"
site.title = "Awesome Media Gallery"
site.enable_search = "1"
site.enable_comments = "1"
site.enable_reporting = "1"
site.enable_tracking = "1"
site.bitly.login_id = ""
site.bitly.app_key = ""
site.bitly.enabled = "0"
site.email_subject_signup = "Be Awesome!"
site.social.twitter = ""
site.social.facebook = ""
site.social.image_wide = ""
site.social.image_square = ""
beacon.lastrun = ""
site.enable_autoplay = "1"
site.social.instagram = 
site.social.flickr = 
site.social.google_plus = 
site.social.youtube = 
site.social.vimeo = 
site.social.blog = 
site.social.pinterest = 
site.enable_page_loader = "1"
site.home_per_page = "36"
site.profiles.enable_gender = "1"
site.profiles.enable_video = "1"
site.profiles.enable_skills = "1"