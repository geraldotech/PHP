<?php

class MK_API_REST_Server
{
    
    protected $parameters;
    protected $method;
    protected $status;
    
    protected $response = array( 'status' => 'ok', 'status_code' => '200', 'status_message' => '', 'body' => array( ) );
    
    public function processRequest( $method, $parameters, MK_RecordUser $user = null )
    {
        if ( !empty( $parameters[ 'module' ] ) ) {
            if ( $method == 'post' ) {
                
            } else {
                try {
                    $module = MK_RecordModuleManager::getFromType( $parameters[ 'module' ] );
                    unset( $parameters[ 'module' ] );
                    
                    $expand = isset( $parameters[ 'expand' ] ) ? (boolean) $parameters[ 'expand' ] : true;
                    unset( $parameters[ 'expand' ] );
                    
                    $request = isset( $parameters[ 'request' ] ) ? (array) $parameters[ 'request' ] : null;
                    unset( $parameters[ 'request' ] );
                    
             
                    
                    
                    // Insert record
                    if ( !empty( $user ) && $user->isAuthorized() && !empty( $parameters[ 'action' ] ) && !empty( $parameters[ 'fields' ] ) && $parameters[ 'action' ] == 'add' ) {
                        $new_record = MK_RecordManager::getNewRecord( $module->getId() );
                        
                        foreach ( $parameters[ 'fields' ] as $field => $field_value ) {
                            $new_record->setMetaValue( $field, stripslashes($field_value) );
                        }
                        
                        $new_record->save();
                        
                        $module_slug = $module->getSlug();
                        
                        switch ( $module_slug ) {
                            
                            case 'comments':
                                
                                $image_id     = $new_record->getImage();
                                $image_module = MK_RecordModuleManager::getFromType( 'image' );
                                $image        = MK_RecordManager::getFromId( $image_module->getId(), $image_id );
                                
                                $notification_text = '<a href="member.php?user=' . $user->getId() . '">' . $user->getDisplayName() . '</a> added a new comment on <a href="image.php?image=' . $image->getId() . '">' . $image->getTitle() . '</a>';
                                
                                
                                $user->addNotification( $notification_text, true, null, 'comment' );
                                
                                
                                
                                
                                break;
                            
                            case 'favourites':
                                
                                
                                $image_id     = $new_record->getImage();
                                $image_module = MK_RecordModuleManager::getFromType( 'image' );
                                $image        = MK_RecordManager::getFromId( $image_module->getId(), $image_id );
                                
                                
                                $notification_text = '<a href="member.php?user=' . $user->getId() . '">' . $user->getDisplayName() . '</a> added <a href="image.php?image=' . $image->getId() . '">' . $image->getTitle() . '</a> as a favorite';
                                
                                
                                $user->addNotification( $notification_text, true, null, 'like' );
                                
                                
                                
                                
                                break;
                            
                            case 'comments-likes':
                                
                                
                                $comment_id = $new_record->getId();
                                
                                
                                $comment_module = MK_RecordModuleManager::getFromType( 'image_comment' );
                                $comment        = MK_RecordManager::getFromId( $comment_module->getId(), $comment_id );
                                $image_id       = $comment->getImage();
                                $image_module   = MK_RecordModuleManager::getFromType( 'image' );
                                $image          = MK_RecordManager::getFromId( $image_module->getId(), $image_id );
                                
                                
                                $notification_text = '<a href="member.php?user=' . $user->getId() . '">' . $user->getDisplayName() . '</a> likes a <a href="image.php?image=' . $image->getId() . '#comment-' . $comment_id . '">comment</a>.';
                                
                                
                                $user->addNotification( $notification_text, true, null, 'like' );
                                
                                
                                
                                
                                break;
                        }
                        
                        $this->response[ 'body' ] = $new_record->toArray( $expand, $request );
                    } elseif ( !empty( $parameters[ 'id' ] ) && !empty( $user ) && $user->isAuthorized() && !empty( $parameters[ 'action' ] ) && !empty( $parameters[ 'fields' ] ) && $parameters[ 'action' ] == 'update' ) {
                        $new_record = MK_RecordManager::getFromId( $module->getId(), $parameters[ 'id' ] );
                        
                       
                        
                        if ( $new_record->canEdit( $user ) ) {
                            foreach ( $parameters[ 'fields' ] as $field => $field_value ) {
                            
                                if (get_magic_quotes_gpc()) {
                                   
                                }
                            
                                $new_record->setMetaValue( $field, stripslashes($field_value) );
                                
                                 //echo 'New Shit:';
                                  //  var_dump($new_record);
                                //die;
                            }
                            
                            $new_record->save();
                            
                        } else {
                            //echo 'User cannot edit 3.';
                            // echo 'Logged in user:' . $user->getId();
                            //echo 'User field:'. $parameters['fields']['user'];
                            exit;
                        }
                        
                        $this->response[ 'body' ] = $new_record->toArray( $expand, $request );
                    }
                    // Either an ID or a list of IDs have been supplied
                        elseif ( !empty( $parameters[ 'id' ] ) && ( $id = $parameters[ 'id' ] ) ) {
                        
                        //echo 'AN ID HAS BEEN PASSED!';
                        
                        // Perform an action on specified records
                        if ( !empty( $user ) && $user->isAuthorized() && !empty( $parameters[ 'action' ] ) && $parameters[ 'action' ] == 'delete' ) {
                            //echo 'AUTHORIZED';
                            
                            
                            
                            if ( is_array( $id ) ) // More than one record to delete
                                {
                                $record_list = array( );
                                foreach ( $id as $_id ) {
                                    $record = MK_RecordManager::getFromId( $module->getId(), $_id );
                                    if ( $record->canDelete( $user ) ) {
                                        $record->delete();
                                    }
                                }
                                
                            } else // Single record to delete
                                {
                                //echo 'Single record to delete!';
                                
                                $record = MK_RecordManager::getFromId( $module->getId(), $id );
                                
                                //var_dump($record);
                                //echo'<br>';
                                //var_dump($user);
                                
                                if ( $record->canDelete( $user ) )
                                //if( $record->canEdit( $user ) )
                                    {
                                    $record->delete();
                                    //echo 'YES DELETE!';
                                } else {
                                    //echo 'User cannot delete!!';
                                }
                            }
                            
                            //exit();
                            
                        } elseif ( !empty( $parameters[ 'id' ] ) && !empty( $user ) && $user->isAuthorized() && !empty( $parameters[ 'action' ] ) && $parameters[ 'action' ] == 'report-image' ) {
                            //Report Image
                            $record = MK_RecordManager::getFromId( $module->getId(), $id );
                            $config = MK_Config::getInstance();
                            
                            $email = new MK_BrandedEmail();
                            $email->setSubject( 'Image Reported' )->setMessage( '<p>The image <a href="' . MK_Utility::serverUrl( 'image.php?image=' . $id ) . '">' . $record->getTitle() . '</a> has been reported.</p>' )->send( $config->site->email );
                            
                            //return 'Success';
                            
                            //$this->response['body'] = $record->toArray( $expand, $request );
                            
                            $this->response[ 'body' ] = $record->toArray( $expand, $request );
                            //echo 'I want to report image!';
                            //exit();
                            
                        }
                        
                        
                        
                        
                        // Return specified records
                        else {
                            if ( is_array( $id ) ) {
                                $record_list = array( );
                                foreach ( $id as $_id ) {
                                    $record        = MK_RecordManager::getFromId( $module->getId(), $_id );
                                    $record_list[] = $record->toArray( $expand, $request );
                                }
                                
                                $this->response[ 'body' ] = $record_list;
                            } else {
                                $record = MK_RecordManager::getFromId( $module->getId(), $id );
                                
                                $this->response[ 'body' ] = $record->toArray( $expand, $request );
                            }
                        }
                    } else {
                        
                        //echo 'Im in the else!';
                        //exit();
                        
                        $records   = array( );
                        $paginator = new MK_Paginator();
                        $paginator->setPage( !empty( $parameters[ 'page' ] ) ? $parameters[ 'page' ] : 1 )->setPerPage( !empty( $parameters[ 'per_page' ] ) ? $parameters[ 'per_page' ] : 10 );
                        
                        unset( $parameters[ 'page' ], $parameters[ 'per_page' ] );
                        
                        $search_parameters = array( );
                        
                        if ( !empty( $parameters[ 'keywords' ] ) ) {
                            $slug_field = $module->objectFieldSlug();
                            
                            $prepared_keywords = trim( $parameters[ 'keywords' ] );
                            $prepared_keywords = '%' . str_replace( ' ', '%', $prepared_keywords ) . '%';
                            $prepared_keywords = MK_Database::getInstance()->quote( $prepared_keywords );
                            
                            $search_parameters[] = array(
                                 'literal' => '`' . $slug_field->getName() . '` LIKE ' . $prepared_keywords 
                            );
                            
                            unset( $parameters[ 'keywords' ] );
                        }
                        
                        $options = array( );
                        if ( !empty( $parameters[ 'options' ] ) ) {
                            $options = $parameters[ 'options' ];
                            unset( $parameters[ 'options' ] );
                        }
                        
                        foreach ( $parameters as $parameter_key => $parameter_value ) {
                            $search_parameters[] = array(
                                 'field' => $parameter_key,
                                'value' => $parameter_value 
                            );
                        }
                        
                        if ( $search_parameters ) {
                            $module_records = $module->searchRecords( $search_parameters, $paginator, $options );
                        } else {
                            $module_records = $module->getRecords( $paginator, $options );
                        }
                        
                        foreach ( $module_records as $record ) {
                            $record_array = $record->toArray( $expand, $request );
                            
                            $text_indent = '';
                            
                            for ( $i = 0; $i < $record->getNestedLevel(); $i++ ) {
                                $text_indent .= '&nbsp;&nbsp;&nbsp;';
                            }
                            
                            $record_array[ 'text_indent' ] = $text_indent;
                            
                            $records[] = $record_array;
                        }
                        
                        $this->response[ 'body' ] = array(
                             'records' => $records,
                            'page' => $paginator->getPage(),
                            'per_page' => $paginator->getPerPage(),
                            'total_pages' => $paginator->getTotalPages(),
                            'total_records' => $paginator->getTotalRecords() 
                        );
                        
                    }
                    
                }
                catch ( Exception $e ) {
                    $this->response[ 'status_code' ] = '400';
                }
            }
        } else {
            $this->response[ 'status' ]      = 'error';
            $this->response[ 'status_code' ] = '400';
        }
        
        $this->response[ 'status_message' ] = MK_Request::getStatusCode( $this->response[ 'status_code' ] );
        
        return $this->response;
        
    }
    
}

?>