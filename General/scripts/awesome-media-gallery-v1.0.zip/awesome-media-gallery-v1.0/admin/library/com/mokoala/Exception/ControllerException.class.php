<?php

class MK_ControllerException extends MK_Exception{
	
}

?>