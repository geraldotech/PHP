<?php

class MK_Exception extends Exception{
	
}

?>