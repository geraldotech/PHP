<?php

class MK_ModuleException extends Exception{
	
}

?>