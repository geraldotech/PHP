<?php

class MK_ModuleRecordException extends Exception{
	
}

?>