<?php

class MK_SQLException extends Exception{
	
}

?>