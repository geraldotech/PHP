<?php

class MK_ViewException extends MK_Exception{
	
}

?>