<?php

require_once 'FormFieldFileImage.class.php';

class MK_Form_Field_File_Image_Multiple_Clone extends MK_Form_Field_File_Image_Multiple
{

}

?>