<?php

interface MK_Config_Handler_Interface{
	
}

?>