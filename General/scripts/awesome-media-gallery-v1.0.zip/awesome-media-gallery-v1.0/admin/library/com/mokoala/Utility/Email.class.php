<?php
class MK_Email{
	
	protected $sender_name;
	protected $sender_email;
	protected $replyto;
	protected $subject;
	protected $message;
	
	public function setSender($email, $name = null)
	{
		$this->sender_email = $email;
		$this->sender_name = $name;
		return $this;
	}
	
	public function setReplyTo($email)
	{
		$this->replyto = $email;
		return $this;
	}
	
	public function setSubject($subject)
	{
		$this->subject = $subject;
		return $this;
	}
	
	public function setMessage($message)
	{
		$this->message = $message;
		return $this;
	}
	
	public function getSubject()
	{
		return $this->subject;
	}
	
	public function getMessage()
	{
		return $this->message;
	}
	
	public function send($email, $name = null)
	{
		$mail = new PHPMailer();
		
		$mail->From = $this->sender_email;
		$mail->FromName = $this->sender_name;
		$mail->AddAddress($email, $name);
		$mail->AddReplyTo($this->sender_email, $this->sender_name);
		
		$mail->WordWrap = 50;
		$mail->IsHTML(true);
		
		$mail->Subject = $this->getSubject();
		$mail->Body    = $this->getMessage();
		$mail->AltBody = $this->message;
		
		$mail->Send();

		return $this;
	}

}

?>