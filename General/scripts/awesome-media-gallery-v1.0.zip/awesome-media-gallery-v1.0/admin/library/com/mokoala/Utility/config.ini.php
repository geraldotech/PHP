db.host = "localhost"
db.name = "engage_vfx_gallery"
db.username = "engage_vfx"
db.password = "h[tH_g#n_P2#"
site.upload_path = "tpl/uploads/"
site.installed = "1"
site.name = "VXF Workshops"
site.email = "jason@engagefb.com"
site.email_signature = 
site.url = "http://engagefb.com/vfx_gallery/"
site.date_format = "M jS Y"
site.error_reporting = "1"
site.time_format = "H:iA"
site.template = "mokoala-default/default"
site.valid_file_extensions = "pdf,doc,docx,ppt,pptx,pps,ppsx,odt,xls,xlsx,mp3,m4a,ogg,wav,mp4,m4v,mov,wmv,avi,mpg,ogv,3gp,3g2,jpg,jpeg,jpe,jif,jfif,jfi,gif,png,7z,zip,rar"
site.timezone = "Europe/London"
user.timeout = "31556926"
site.log_actions = "1"
extensions.core.email_verification = "0"
extensions.core.logout_url = 
extensions.core.login_url = 
extensions.core.register_url = 
db.prefix = "mk_"
extensions.gallery.display_mode = "images"
extensions.gallery.filter_style = "link-list"
extensions.gallery.image_list_mode = "complex"
extensions.gallery.image_comments = "1"
db.components[] = "community-gallery-manager"
db.components[] = "community-gallery-manager"
db.components[] = "core"
db.components[] = "core"
db.components[] = "post-manager"
db.components[] = "post-manager"
extensions.gallery.search = "1"
site.email_template = "&lt;html&gt;
&lt;head&gt;
&lt;style type=&quot;text/css&quot;&gt;
html, body{
  font-family:Georgia, &quot;Times New Roman&quot;, Times, serif;
  text-align:center;
}

a{ color:#ac4a4a; }

h1{
font-size:40px;
font-weignt:bold;
text-align:center;
padding: 20px 0 10px 0;
}
&lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;table align=&quot;left&quot; style=&quot;margin:0 auto 0 auto; text-align:left; width:600px;&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot; border=&quot;0&quot;&gt;
&lt;tr&gt;
&lt;td&gt;&lt;h1&gt;{site_name}&lt;/h1&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td style=&quot;border-top:1px solid #d4d4d4; padding:15px  0 15px 0;&quot;&gt;{email_content}&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td style=&quot;text-align:center; padding: 15px 0 0 0; font-weight:bold; border-top:1px solid #d4d4d4;&quot;&gt;Powered by &lt;a target=&quot;_blank&quot; href=&quot;{core_url}&quot;&gt;{core_name}&lt;/a&gt;&lt;/td&gt;
&lt;/tr&gt;
&lt;/table&gt;
&lt;/body&gt;
&lt;/html&gt;"
site.email_text_signup = "&lt;p&gt;Dear {user_display_name}&lt;br /&gt;&lt;br /&gt;Thankyou for signing up.&lt;/p&gt;"
site.email_text_verfification = "&lt;p&gt;Dear {user_display_name},&lt;br /&gt;&lt;br /&gt;Thank you for registering. Click the link below (or copy it into your browser) to verify your email address:&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;{verification_link}&quot;&gt;{verification_link}&lt;/a&gt;.&lt;/p&gt;"
extensions.core.email_admin_signup = "1"
site.facebook.app_id = "420217374707409"
site.facebook.app_secret = "3d00d45b0f6cc4a0c71e5eecbe01a0c7"
site.facebook.login = "1"
site.twitter.app_key = "GIP3tRm05Gq7TAS4V4g"
site.twitter.app_secret = "84yLKTYTMqvZrJc5Bz25xsodinVdLAFsPSbRlql7pBo"
site.twitter.login = "1"
site.yahoo.client_id = 
site.yahoo.client_secret = 
site.yahoo.login = "0"
site.windowslive.client_id = 
site.windowslive.client_secret = 
site.windowslive.login = "0"
site.google.client_id = 
site.google.client_secret = 
site.google.login = "0"
site.linkedin.client_id = "z11mrqhaq3py"
site.linkedin.client_secret = "LetdJxVUZNV8P1TR"
site.linkedin.login = "1"
