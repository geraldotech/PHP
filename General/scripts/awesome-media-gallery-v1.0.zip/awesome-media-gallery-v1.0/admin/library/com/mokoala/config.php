<?php
// Parse config
$config_ini = parse_ini_file(dirname(__FILE__).'/../../../config.ini.php');

foreach( $config_ini as $config_key => $config_value )
{
	if( is_string($config_value) )
	{
		$config_ini[$config_key] = MK_Utility::unescapeText( $config_value );
	}
}

// set timezone
$config_ini['site.timezone'] = !empty($config_ini['site.timezone']) ? $config_ini['site.timezone'] : 'Europe/London' ;
date_default_timezone_set($config_ini['site.timezone']);

// Set error reporting
$error_levels = array(
	0 => 0,
	1 => E_ERROR | E_WARNING | E_PARSE,
	2 => E_ALL
);
$error_level = !empty($config_ini['site.error_reporting']) ? $config_ini['site.error_reporting'] : 1;
$error_level = in_array($error_level, $error_levels) ? $error_level : 1;
$error_level = $error_levels[$error_level];

error_reporting( -1 );

// Current URI
$current_page = parse_url($_SERVER['REQUEST_URI']);
$current_page = $current_page['path'].(!empty($current_page['query']) ? '?'.$current_page['query'] : '').(!empty($current_page['fragment']) ? '#'.$current_page['fragment'] : '');

// Base URI
$base_href_path = pathinfo($_SERVER['SCRIPT_NAME'], PATHINFO_DIRNAME);
$cookie_base_href_path = rtrim( str_replace('admin', '', $base_href_path), '\\/' ).'/';

$current_page_name = str_replace_first($base_href_path, '', $current_page);

$base_href_protocol = ( array_key_exists('HTTPS', $_SERVER) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http' ).'://';
if( array_key_exists('HTTP_HOST', $_SERVER) && !empty($_SERVER['HTTP_HOST']) )
{
	$base_href_host = $_SERVER['HTTP_HOST'];
}
elseif( array_key_exists('SERVER_NAME', $_SERVER) && !empty($_SERVER['SERVER_NAME']) )
{
	$base_href_host = $_SERVER['SERVER_NAME'].( $_SERVER['SERVER_PORT'] !== 80 ? ':'.$_SERVER['SERVER_PORT'] : '' );
}
$base_href = rtrim( $base_href_protocol.$base_href_host.$base_href_path, '\\/' ).'/';

// $_POST, $_FILES, $_GET
$params = $_GET;
$post = array_merge_replace($_POST, $_FILES);

$path = array();

if( !empty( $params['module_path'] ) )
{
	$path = array_filter( explode( '/', $params['module_path'] ) );
	unset( $params['module_path'] );
}

MK_Request::init( $params, $post );

// Define Cookie & Session
$cookie_path = '/';
MK_Session::start( 'mk', $cookie_base_href_path, ( $_SERVER['SERVER_NAME'] === 'localhost' ? false : $base_href_host ) );
MK_Cookie::start(  $cookie_base_href_path, ( $_SERVER['SERVER_NAME'] === 'localhost' ? false : $base_href_host ) );

// Get session
$session = MK_Session::getInstance();

/*
	Referring URL
*/
$tidy_referer = '';
if( !empty($_SERVER['HTTP_REFERER']) )
{
	$tidy_referer = parse_url($_SERVER['HTTP_REFERER']);
	$tidy_referer = (!empty($tidy_referer['path']) ? $tidy_referer['path'] : '').(!empty($tidy_referer['query']) ? '?'.$tidy_referer['query'] : '').(!empty($tidy_referer['fragment']) ? '#'.$tidy_referer['fragment'] : '');
}
		
if(!empty($_SERVER['REQUEST_URI']))
{
	$tidy_current = parse_url($_SERVER['REQUEST_URI']);
	$tidy_current = (!empty($tidy_referer['path']) ? $tidy_referer['path'] : '').(!empty($tidy_current['query']) ? '?'.$tidy_current['query'] : '').(!empty($tidy_current['fragment']) ? '#'.$tidy_current['fragment'] : '');
}

// If no refer has been set
if( empty($session->referer) )
{
	// Has the user came from another site
	if(!empty($tidy_referer) && strpos($_SERVER['HTTP_REFERER'], $base_href_host) === false)
	{
		$http_referer = $tidy_referer;
	}
	// If not then set their session to the actual referer
	else
	{
		$http_referer = $tidy_current;
	}
}
elseif( $tidy_referer !== $tidy_current )
{
	$http_referer = $tidy_referer;
}
else
{
	$http_referer = $session->referer;
}

$session->referer = $http_referer;

// Custom module settings
foreach($config_ini as $custom_key => $custom_value)
{
	$config_key_sections = explode('.', $custom_key);
	if(count($config_key_sections) === 3 && $config_key_sections[0] === 'extensions')
	{
		$config_data['extensions'][$config_key_sections[1]][$config_key_sections[2]] = $custom_value;
	}
}

// Template / Theme
list($template, $template_theme) = explode('/', $config_ini['site.template']);

$config_data['db']['prefix'] 				= (string) !empty($config_ini['db.prefix']) ? $config_ini['db.prefix'] : null;
$config_data['db']['host'] 					= (string) !empty($config_ini['db.host']) ? $config_ini['db.host'] : null;
$config_data['db']['name'] 					= (string) !empty($config_ini['db.name']) ? $config_ini['db.name'] : null;
$config_data['db']['username'] 				= (string) !empty($config_ini['db.username']) ? $config_ini['db.username'] : null;
$config_data['db']['password'] 				= (string) !empty($config_ini['db.password']) ? $config_ini['db.password'] : null;
$config_data['db']['charset'] 				= (string) 'utf8';
$config_data['db']['components'] 			= !empty($config_ini['db.components']) ? $config_ini['db.components'] : array();

$config_data['site']['settings']['post_max_size'] = MK_Utility::getBytes( ini_get('post_max_size') );
$config_data['site']['settings']['upload_max_filesize'] = MK_Utility::getBytes( ini_get('upload_max_filesize') );
$config_data['site']['settings']['memory_limit'] = MK_Utility::getBytes( ini_get('memory_limit') );

$config_data['site']['bitly']['login_id'] 	= (string) !empty($config_ini['site.bitly.login_id']) ? $config_ini['site.bitly.login_id'] : null;
$config_data['site']['bitly']['app_key']	= (string) !empty($config_ini['site.bitly.app_key']) ? $config_ini['site.bitly.app_key'] : null;
$config_data['site']['bitly']['enabled']	= (boolean) !empty($config_ini['site.bitly.enabled']) ? $config_ini['site.bitly.enabled'] : null;


$config_data['site']['facebook']['app_id'] 	= (string) !empty($config_ini['site.facebook.app_id']) ? $config_ini['site.facebook.app_id'] : null;
$config_data['site']['facebook']['app_secret']	= (string) !empty($config_ini['site.facebook.app_secret']) ? $config_ini['site.facebook.app_secret'] : null;
$config_data['site']['facebook']['login']	= (boolean) !empty($config_ini['site.facebook.login']) ? $config_ini['site.facebook.login'] : null;

$config_data['site']['twitter']['app_key'] 	= (string) !empty($config_ini['site.twitter.app_key']) ? $config_ini['site.twitter.app_key'] : null;
$config_data['site']['twitter']['app_secret']	= (string) !empty($config_ini['site.twitter.app_secret']) ? $config_ini['site.twitter.app_secret'] : null;
$config_data['site']['twitter']['login']	= (boolean) !empty($config_ini['site.twitter.login']) ? $config_ini['site.twitter.login'] : null;

$config_data['site']['linkedin']['client_id'] 	= (string) !empty($config_ini['site.linkedin.client_id']) ? $config_ini['site.linkedin.client_id'] : null;
$config_data['site']['linkedin']['client_secret']	= (string) !empty($config_ini['site.linkedin.client_secret']) ? $config_ini['site.linkedin.client_secret'] : null;
$config_data['site']['linkedin']['login']	= (boolean) !empty($config_ini['site.linkedin.login']) ? $config_ini['site.linkedin.login'] : null;

$config_data['site']['yahoo']['client_id'] 	= (string) !empty($config_ini['site.yahoo.client_id']) ? $config_ini['site.yahoo.client_id'] : null;
$config_data['site']['yahoo']['client_secret']	= (string) !empty($config_ini['site.yahoo.client_secret']) ? $config_ini['site.yahoo.client_secret'] : null;
$config_data['site']['yahoo']['login']	= (boolean) !empty($config_ini['site.yahoo.login']) ? $config_ini['site.yahoo.login'] : null;

$config_data['site']['windowslive']['client_id'] 	= (string) !empty($config_ini['site.windowslive.client_id']) ? $config_ini['site.windowslive.client_id'] : null;
$config_data['site']['windowslive']['client_secret']= (string) !empty($config_ini['site.windowslive.client_secret']) ? $config_ini['site.windowslive.client_secret'] : null;
$config_data['site']['windowslive']['login']		= (boolean) !empty($config_ini['site.windowslive.login']) ? $config_ini['site.windowslive.login'] : null;

$config_data['site']['google']['client_id'] 	= (string) !empty($config_ini['site.google.client_id']) ? $config_ini['site.google.client_id'] : null;
$config_data['site']['google']['client_secret']= (string) !empty($config_ini['site.google.client_secret']) ? $config_ini['site.google.client_secret'] : null;
$config_data['site']['google']['login']		= (boolean) !empty($config_ini['site.google.login']) ? $config_ini['site.google.login'] : null;

$config_data['site']['hash'] 				= !empty($config_ini['site.hash']) ? $config_ini['site.hash'] : 'sha1';
$config_data['site']['installed'] 			= (boolean) !empty($config_ini['site.installed']) ? $config_ini['site.installed'] : null;
$config_data['site']['path'] 				= (string) realpath(dirname(__FILE__).'/../../../..');
$config_data['site']['base'] 				= (string) str_replace('admin', '', $base_href_path);
$config_data['site']['page'] 				= (string) $current_page;
$config_data['site']['page_name'] 			= (string) $current_page_name;
$config_data['site']['base_href'] 			= (string) $base_href;
$config_data['site']['upload_path']			= (string) !empty($config_ini['site.upload_path']) ? $config_ini['site.upload_path'] : null;

$config_data['admin']['path'] 				= (string) realpath(dirname(__FILE__).'/../../..');

$config_data['site']['valid_file_extensions'] 	= !empty($config_ini['site.valid_file_extensions']) ? explode(',', $config_ini['site.valid_file_extensions']) : array();
$config_data['site']['date_format'] 		= (string) !empty($config_ini['site.date_format']) ? $config_ini['site.date_format'] : null;
$config_data['site']['time_format'] 		= (string) !empty($config_ini['site.time_format']) ? $config_ini['site.time_format'] : null;
$config_data['site']['datetime_format'] 	= (string) $config_data['site']['date_format'].' '.$config_data['site']['time_format'];
$config_data['site']['referer'] 			= (string) $session->referer;
$config_data['site']['charset'] 			= (string) 'utf-8';


$config_data['site']['name'] 				= (string) !empty($config_ini['site.name']) ? $config_ini['site.name'] : null;

$config_data['site']['title'] 				= (string) !empty($config_ini['site.title']) ? $config_ini['site.title'] : null;
$config_data['site']['desc'] 				= (string) !empty($config_ini['site.desc']) ? $config_ini['site.desc'] : null;

$config_data['site']['caption'] 			= (string) !empty($config_ini['site.caption']) ? $config_ini['site.caption'] : null;

$config_data['site']['logo'] 				= (string) !empty($config_ini['site.logo']) ? $config_ini['site.logo'] : null;
$config_data['site']['logo_sticky'] 		= (string) !empty($config_ini['site.logo_sticky']) ? $config_ini['site.logo_sticky'] : null;
$config_data['site']['default_avatar'] 		= (string) !empty($config_ini['site.default_avatar']) ? $config_ini['site.default_avatar'] : null;

$config_data['site']['home_per_page'] 		= (boolean) !empty($config_ini['site.home_per_page']) ? $config_ini['site.home_per_page'] : false;

$config_data['site']['enable_page_loader'] 		= (boolean) !empty($config_ini['site.enable_page_loader']) ? $config_ini['site.enable_page_loader'] : false;
$config_data['site']['enable_footer'] 		= (boolean) !empty($config_ini['site.enable_footer']) ? $config_ini['site.enable_footer'] : false;
$config_data['site']['enable_search'] 		= (boolean) !empty($config_ini['site.enable_search']) ? $config_ini['site.enable_search'] : false;
$config_data['site']['enable_comments'] 	= (boolean) !empty($config_ini['site.enable_comments']) ? $config_ini['site.enable_comments'] : false;
$config_data['site']['enable_reporting'] 	= (boolean) !empty($config_ini['site.enable_reporting']) ? $config_ini['site.enable_reporting'] : false;
$config_data['site']['enable_autoplay'] 	= (boolean) !empty($config_ini['site.enable_autoplay']) ? $config_ini['site.enable_autoplay'] : false;
$config_data['site']['enable_tracking'] 	= (boolean) !empty($config_ini['site.enable_tracking']) ? $config_ini['site.enable_tracking'] : false;

$config_data['site']['profiles']['enable_gender'] 	= (boolean) !empty($config_ini['site.profiles.enable_gender']) ? $config_ini['site.profiles.enable_gender'] : false;
$config_data['site']['profiles']['enable_video'] 	= (boolean) !empty($config_ini['site.profiles.enable_video']) ? $config_ini['site.profiles.enable_video'] : false;
$config_data['site']['profiles']['enable_skills'] 	= (boolean) !empty($config_ini['site.profiles.enable_skills']) ? $config_ini['site.profiles.enable_skills'] : false;


$config_data['site']['dev_mode'] 			= (boolean) !empty($config_ini['site.dev_mode']) ? $config_ini['site.dev_mode'] : false;

$config_data['site']['social']['twitter'] 		= (string) !empty($config_ini['site.social.twitter']) ? $config_ini['site.social.twitter'] : null;
$config_data['site']['social']['facebook'] 	= (string) !empty($config_ini['site.social.facebook']) ? $config_ini['site.social.facebook'] : null;

$config_data['site']['social']['youtube'] 	= (string) !empty($config_ini['site.social.youtube']) ? $config_ini['site.social.youtube'] : null;
$config_data['site']['social']['instagram'] 	= (string) !empty($config_ini['site.social.instagram']) ? $config_ini['site.social.instagram'] : null;
$config_data['site']['social']['pinterest'] 	= (string) !empty($config_ini['site.social.pinterest']) ? $config_ini['site.social.pinterest'] : null;
$config_data['site']['social']['vimeo'] 	= (string) !empty($config_ini['site.social.vimeo']) ? $config_ini['site.social.vimeo'] : null;
$config_data['site']['social']['google_plus'] 	= (string) !empty($config_ini['site.social.google_plus']) ? $config_ini['site.social.google_plus'] : null;
$config_data['site']['social']['flickr'] 	= (string) !empty($config_ini['site.social.flickr']) ? $config_ini['site.social.flickr'] : null;
$config_data['site']['social']['blog'] 	= (string) !empty($config_ini['site.social.blog']) ? $config_ini['site.social.blog'] : null;

$config_data['site']['social']['image_square'] = (string) !empty($config_ini['site.social.image_square']) ? $config_ini['site.social.image_square'] : null;
$config_data['site']['social']['image_wide'] 	= (string) !empty($config_ini['site.social.image_wide']) ? $config_ini['site.social.image_wide'] : null;

$config_data['site']['style_primary'] 		= (string) !empty($config_ini['site.style_primary']) ? $config_ini['site.style_primary'] : null;
$config_data['site']['style_secondary'] 		= (string) !empty($config_ini['site.style_secondary']) ? $config_ini['site.style_secondary'] : null;
$config_data['site']['style_boxradius'] 		= (string) !empty($config_ini['site.style_boxradius']) ? $config_ini['site.style_boxradius'] : null;
$config_data['site']['style_boxshadow'] 		= (string) !empty($config_ini['site.style_boxshadow']) ? $config_ini['site.style_boxshadow'] : null;


$config_data['site']['analytics'] 			= (string) !empty($config_ini['site.analytics']) ? $config_ini['site.analytics'] : null;

$config_data['site']['adhome728x90'] 		= (string) !empty($config_ini['site.adhome728x90']) ? $config_ini['site.adhome728x90'] : null;
$config_data['site']['adhome242x90'] 		= (string) !empty($config_ini['site.adhome242x90']) ? $config_ini['site.adhome242x90'] : null;

$config_data['site']['adsidebar160x600'] 	= (string) !empty($config_ini['site.adsidebar160x600']) ? $config_ini['site.adsidebar160x600'] : null;

$config_data['site']['log_actions'] 		= (boolean) !empty($config_ini['site.log_actions']) ? $config_ini['site.log_actions'] : false;
$config_data['site']['url'] 				= (string) !empty($config_ini['site.url']) ? $config_ini['site.url'] : null;
$config_data['site']['timezone'] 			= (string) $config_ini['site.timezone'];

$config_data['site']['email'] 				= (string) !empty($config_ini['site.email']) ? $config_ini['site.email'] : null;

$config_data['site']['email_template'] 		= (string) !empty($config_ini['site.email_template']) ? $config_ini['site.email_template'] : null;

$config_data['site']['email_subject_signup']= (string) !empty($config_ini['site.email_subject_signup']) ? $config_ini['site.email_subject_signup'] : null;
$config_data['site']['email_text_signup'] 	= (string) !empty($config_ini['site.email_text_signup']) ? $config_ini['site.email_text_signup'] : null;

$config_data['site']['email_text_verfification'] 	= (string) !empty($config_ini['site.email_text_verfification']) ? $config_ini['site.email_text_verfification'] : null;



$config_data['site']['user_timeout'] 		= (integer) !empty($config_ini['user.timeout']) ? $config_ini['user.timeout'] : null;

$config_data['beacon']['lastrun'] 		= (integer) !empty($config_ini['beacon.lastrun']) ? $config_ini['beacon.lastrun'] : null;

$config_data['server']['local'] 			= (string) $_SERVER['SERVER_NAME'] === 'localhost' ? true : false;
$config_data['server']['name'] 				= (string) $base_href_host;
$config_data['server']['time'] 				= (integer) time();

$config_data['server']['execution_start'] 	= (float) !empty($start) ? $start : 0;

$config_data['template'] 					= (string) $template;
$config_data['template_theme'] 				= (string) $template_theme;
$config_data['template_theme_directory']	= (string) 'application/views/'.$template_theme.'/';

$config_data['core']['name'] 				= (string) 'Mokoala';
$config_data['core']['version'] 			= (string) '3.5.0';
//$config_data['core']['mode'] 				= (string) MK_Core::MODE_PRODUCT;
$config_data['core']['mode'] 				= (string) !empty($config_ini['site.mode']) ? $config_ini['site.mode'] : MK_Core::MODE_PRODUCT;

$config_data['core']['clean_uris'] 			= (boolean) false;
$config_data['core']['url'] 				= (string) 'http://mokoala.com/';

$config_data['instance']['name'] 			= (string) 'Mokoala CMS';
$config_data['instance']['version'] 		= (string) '1.0';
$config_data['instance']['url'] 			= (string) 'http://mokoala.com/';

// If the PayPal API details are defined then instantiate the PayPal API class 
if( function_exists('curl_init') && !empty($config_data['extensions']['payments_paypal']['api_signature']) && !empty($config_data['extensions']['payments_paypal']['api_password']) && !empty($config_data['extensions']['payments_paypal']['api_username']) && !empty($config_data['extensions']['payments_paypal']['currency']) )
{
	$config_data['paypal'] = new MK_PayPal($config_data['extensions']['payments_paypal']['api_username'], $config_data['extensions']['payments_paypal']['api_password'], $config_data['extensions']['payments_paypal']['api_signature'], true);
}

// If the Facebook API & Secret are defined then load the Facebook API class
if( function_exists('curl_init') && function_exists('json_encode') && !empty($config_data['site']['facebook']['app_secret']) && !empty($config_data['site']['facebook']['app_id']) )
{
	$facebook = new Facebook(array(
		'appId' => $config_data['site']['facebook']['app_id'],
		'secret' => $config_data['site']['facebook']['app_secret'],
		'cookie' => false
	));
	$config_data['facebook'] = $facebook;
}
else
{
	$config_data['site']['facebook']['login'] = (boolean) false;
	$config_data['facebook'] = null;
}

// If the Windows Live API details are defined then instantiate the Windows Live API class 
if( $config_data['site']['windowslive']['login'] && $config_data['site']['windowslive']['client_id'] && $config_data['site']['windowslive']['client_secret'] )
{
	$config_data['windowslive'] = new oauth_client_class();

	$config_data['windowslive']->server = 'Microsoft';
	$config_data['windowslive']->redirect_uri = $config_data['site']['url'] . 'sign-in.php?platform=windowslive';

	$config_data['windowslive']->client_id = $config_data['site']['windowslive']['client_id'];
	$config_data['windowslive']->client_secret = $config_data['site']['windowslive']['client_secret'];
	$config_data['windowslive']->scope = 'wl.basic wl.emails';

	$config_data['windowslive']->Initialize();
}
else
{
	$config_data['site']['windowslive']['login'] = (boolean) false;
	$config_data['windowslive'] = null;
}

// If the Twitter Key & Secret are defined then load the Twitter API class
if( !empty($config_data['site']['twitter']['app_secret']) && !empty($config_data['site']['twitter']['app_key']) )
{
	if(empty($session->twitter_access_token) && ( $oauth_verifier = MK_Request::getQuery('oauth_verifier') ) && !empty($session->twitter_oauth_token) && !empty($session->twitter_oauth_token_secret))
	{
		$twitter = new TwitterOAuth($config_data['site']['twitter']['app_key'], $config_data['site']['twitter']['app_secret'], $session->twitter_oauth_token, $session->twitter_oauth_token_secret);
		unset($session->twitter_oauth_token, $session->twitter_oauth_token_secret);
		
		$twitter_access_token = $twitter->getAccessToken($oauth_verifier);
		$session->twitter_access_token = true;
		$twitter = new TwitterOAuth($config_data['site']['twitter']['app_key'], $config_data['site']['twitter']['app_secret'], $twitter_access_token['oauth_token'], $twitter_access_token['oauth_token_secret']);
	}
	else
	{
		$twitter = new TwitterOAuth($config_data['site']['twitter']['app_key'], $config_data['site']['twitter']['app_secret']);
	}
	$config_data['twitter'] = $twitter;
}
else
{
	$config_data['site']['twitter']['login'] = (boolean) false;
	$config_data['twitter'] = null;
}

// If the Google Key & Secret are defined then load the Google API class
if( !empty($config_data['site']['google']['client_id']) && !empty($config_data['site']['google']['client_secret']) )
{
	$config_data['google'] = new oauth_client_class();

	$config_data['google']->server = 'Google';
	$config_data['google']->redirect_uri = $config_data['site']['url'] . 'sign-in.php?platform=google';

	$config_data['google']->client_id = $config_data['site']['google']['client_id'];
	$config_data['google']->client_secret = $config_data['site']['google']['client_secret'];
	$config_data['google']->scope = 'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile';

	$config_data['google']->Initialize();
}
else
{
	$config_data['site']['google']['login'] = (boolean) false;
	$config_data['google'] = null;
}

// If the Yahoo Key & Secret are defined then load the Yahoo API class
if( !empty($config_data['site']['yahoo']['client_id']) && !empty($config_data['site']['yahoo']['client_secret']) )
{
	$config_data['yahoo'] = new oauth_client_class();

	$config_data['yahoo']->server = 'Yahoo';
	$config_data['yahoo']->redirect_uri = $config_data['site']['url'] . 'sign-in.php?platform=yahoo';
	$config_data['yahoo']->client_id = $config_data['site']['yahoo']['client_id'];
	$config_data['yahoo']->client_secret = $config_data['site']['yahoo']['client_secret'];

	$config_data['yahoo']->Initialize();
}
else
{
	$config_data['site']['yahoo']['login'] = (boolean) false;
	$config_data['yahoo'] = null;
}

// If the LinkedIn Key & Secret are defined then load the LinkedIn API class
if( !empty($config_data['site']['linkedin']['client_id']) && !empty($config_data['site']['linkedin']['client_secret']) )
{
	$config_data['linkedin'] = new oauth_client_class();

	$config_data['linkedin']->server = 'LinkedIn';
	$config_data['linkedin']->redirect_uri = $config_data['site']['url'] . 'sign-in.php?platform=linkedin';
	$config_data['linkedin']->client_id = $config_data['site']['linkedin']['client_id'];
	$config_data['linkedin']->client_secret = $config_data['site']['linkedin']['client_secret'];
	$config_data['linkedin']->scope = 'r_basicprofile r_emailaddress r_fullprofile';

	$config_data['linkedin']->Initialize();
}
else
{
	$config_data['site']['linkedin']['login'] = (boolean) false;
	$config_data['linkedin'] = null;
}

MK_Config::loadConfig($config_data);
$config = MK_Config::getInstance();


?>