<?php
require_once '_inc.php';

//Variables
include ('_variables.php'); ?>
<?php header('Content-type: text/html; charset=utf-8');?>
<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
  <head>
	  <base href="<?php echo $config->site->url; ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="robots" content="noindex">
    <title><?php echo implode(' / ', $head_title); ?></title>
        <script type="text/javascript">

     window.onload = function() {
        if (parent) {
            
            var oHead = document.getElementsByTagName("head")[0];
            var arrStyleSheets = parent.document.getElementsByTagName("style");
            
            for (var i = 0; i < arrStyleSheets.length; i++)
                oHead.appendChild(arrStyleSheets[i].cloneNode(true));
                
            var arrExternalSytles = parent.document.getElementsByTagName("link");
            
            for (var i = 0; i < arrExternalSytles.length; i++)
                oHead.appendChild(arrExternalSytles[i].cloneNode(true));
        }
      }
      
    </script>
  </head>
  <body class="modal-body  modal-contact">
    <?php include ('includes/contact.php'); ?>    
  </body>
</html>