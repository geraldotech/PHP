<div class="footer-container">
    <footer><?php 
    
    if( $config->site->enable_footer == 1 ) { ?>
    
        <div class="top wrapper">
            <div class="pure-g-r">
        
                <div class="pure-u-1-2 float-left"> 
                    
                    <div id="footer-logo"><!-- Logo --> <?php 
                
                    if( $config->site->logo ) { ?>
                
                        <a href="index.php"><img src="<?php echo $config->site->logo; ?>"  alt="<?php echo $config->site->name; ?>"></a><?php 
                
                    } ?>
             
                    </div>
                
                    <div class="about-caption">
                        <?php echo $footer_caption; ?>  
                    </div>
                
                </div>
                
                <div class="pure-u-1-2 nav float-right"> 
                
                    <div class="pure-g-r">
                        
                        <div class="pure-u-1-3 link-col"><?php
                            if ( (!empty($config->site->social->facebook)) || (!empty($config->site->social->twitter)) || (!empty($config->site->social->pinterest)) || (!empty($config->site->social->blog)) ) { ?>
                        
                                <div class="title">Social</div>
                            
                                <ul class="links"><?php 
                                    if (!empty($config->site->social->facebook)) { ?>
                                        <li><a href="<?php echo $config->site->social->facebook; ?>" target="_self">Facebook</a></li><?php
                                    }
                                    
                                    if (!empty($config->site->social->twitter)) { ?>
                                        <li><a href="<?php echo convertTwitterUsernameUrl($config->site->social->twitter); ?>" target="_self">Twitter</a></li><?php
                                    }
                                    
                                    if (!empty($config->site->social->pinterest)) { ?>
                                        <li><a href="<?php echo $config->site->social->pinterest; ?>" target="_self">Pinterest</a></li><?php
                                    }
                                    
                                    if (!empty($config->site->social->blog)) { ?>
                                        <li><a href="<?php echo $config->site->social->blog; ?>" target="_self">Blog</a></li><?php
                                    } ?>
                                </ul><?php
                                
                            } ?>
                    
                        </div>
                    
                        <div class="pure-u-1-3 link-col"> 
                            
                            <div class="title">Contact</div>
                        
                            <ul class="links">
                                <li><a class="menu-item en-trigger" data-modal="modal-about" data-style="slide-up" href="#">About Us</a></li>
                                <li><a class="menu-item en-trigger" data-modal="modal-contact" data-style="slide-up" href="#">Email Us</a></li>
                            </ul>					
                    
                        </div>
                    
                        <div class="pure-u-1-3 link-col"> 
                            
                            <div class="title">Policies</div>
                        
                            <ul class="links">
                                <li><a href="privacy-policy.php" target="_self">Privacy Policy</a></li>
                                <li><span class="menu-item en-trigger" data-modal="modal-terms" data-style="slide-up" id="terms-conditions">Terms and Conditions</span></li>
                            </ul>
                        
                        </div>
                
                    </div>
            
                </div>	
        
            </div>
	
        </div><?php
        
    } ?>
    
    <div class="copyright">
        <div class="wrapper"><?php echo $footer_copyright; ?><span class="engage-mark">Developed by <a href="http://en.gg">ENGAGE</a></span></div>
    </div>
    
    <img src="trans.gif" height="1" width="1" border="0" class="trans">

    </footer>	

</div><?php

if ( ( $deviceType <> 'phone' ) &&  ( $deviceType <> 'tablet' ) ) { 

    include ('includes/modals.php'); 
	
} ?>

<!-- Overlay element for modals -->
<div class="en-overlay"></div>

<!-- Scripts Start Here -->
<script type="text/javascript"><?php

if( isset( $gallery_id_array_encoded ) ) {
    echo "var gallery_id_array = ". $gallery_id_array_encoded . ";\n";
}

if(isset($gallery_name_array_encoded)) {
    echo "var gallery_name_array = ". $gallery_name_array_encoded . ";\n";
}

echo "var users_types_id_array = ". $users_types_id_array_encoded . ";\n";
echo "var users_types_name_array = ". $users_types_name_array_encoded . ";\n"; 
echo "var users_types_data = ". $users_types_data . ";\n";

if(isset($galleries_data)) {
    echo "var galleries_data = ". $galleries_data . ";\n";
}

echo "txt_placeholder_arr = ". json_encode($txt_placeholder_arr) . ";\n";
?>
</script>

<!-- Modernizer -->
<script src="js/vendor/modernizr.custom.min.js"></script><?php

if (($deviceType <> 'phone') &&  ($deviceType <> 'tablet')) { ?>

    <!-- Inline editing script -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/jeditable.js/1.7.3/jeditable.min.js"></script>

    <!-- jQuery Upload Scripts -->
    <script src="upload/js/vendor/jquery.ui.widget.js"></script>
    <script src="upload/js/jquery.fileupload.js"></script>

    <!-- Drag Avatar & Resample-->
    <script src="js/vendor/avatar.js"></script>
    <script src="js/vendor/resample.js"></script><?php 

} ?>

<!-- The custom JS -->
<script src="js/main.js"></script>

<!-- NProgress AJAX Bar -->
<script src="//cdnjs.cloudflare.com/ajax/libs/nprogress/0.1.2/nprogress.min.js"></script>

<?php 
	//PAGE LOADER
	if (!empty($config->site->enable_page_loader) && ($config->site->enable_page_loader==true)) {
?>
		<script type="text/javascript">
		//LOAD PROGRESS BAR
        
        var Loading = {}
        Loading.timer = setInterval(function() { 
                NProgress.inc()
            } , 1000); 
            
        Loading.clear = function ClearMyInt(interval) {
            clearInterval(interval);
            interval = 0;
        }
        
        $(document).ready(function() { // executes when HTML-Document is loaded and DOM is ready
            NProgress.start();
            Loading.timer;
        });
        
        $(window).load(function() {
            NProgress.done();
            Loading.clear(Loading.timer);
        });
        
		</script>
<?php
	}
?>

<?php

if (($deviceType <> 'phone') &&  ($deviceType <> 'tablet')) { ?>

    <!-- FancyBox & Media Helper -->
    <script src="js/vendor/jquery.fancybox.mod.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/helpers/jquery.fancybox-media.js"></script><?php 
	
} ?>
	
<!-- Sticky JS -->
<script src="//cdn.jsdelivr.net/jquery.sticky/1.0.0/jquery.sticky.min.js"></script><?php

if (($deviceType <> 'phone') &&  ($deviceType <> 'tablet')) { ?>

    <!-- classie.js by @desandro: https://github.com/desandro/classie -->
    <script src="js/vendor/classie.js"></script>

    <!-- modalEffects.js by @codedrops: http://tympanus.net/codrops/2013/06/25/nifty-modal-window-effects/ -->
    <script src="js/vendor/modalEffects.min.js"></script><?php 

}

if ($deviceType <> 'phone') { ?>
	
    <!-- Carousel JS -->
    <script src="js/vendor/elastislide/jquerypp.custom.min.js"></script>
    <script src="js/vendor/elastislide/jquery.elastislide.min.js"></script><?php 

} ?>
	
<!-- Dropdowns for the menu -->
<script src="js/vendor/jquery.dropdown.min.js"></script>		<?php

if (($deviceType <> 'phone') &&  ($deviceType <> 'tablet')) { ?>
	
<!-- Nice tags -->
<script src="js/vendor/bootstrap-tagmanager.min.js"></script>	
	
<!-- iCheck -->
<script src="js/vendor/jquery.icheck.min.js"></script><?php 

} ?>

<!-- App Scroll https://github.com/jakiestfu/AppScroll.js -->
<script src="js/vendor/AppScroll.min.js"></script>

<!-- fitVids https://github.com/davatron5000/FitVids.js-->
<script src="//cdnjs.cloudflare.com/ajax/libs/fitvids/1.0.1/jquery.fitvids.min.js"></script><?php

if (($deviceType <> 'phone')) { ?>

    <!-- SocialCount -->
    <script src="js/vendor/socialcount.js"></script>
    <script src="js/vendor/socialcount.pinterest.js"></script>
    <!-- AutoResize TextArea -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/autosize.js/1.17.1/autosize-min.js"></script><?php 

} ?>

<!-- Fancy Select -->
<script src="js/vendor/fancySelect.js"></script>

<script src="js/plugins.js"></script>

<script src="js/custom.js"></script>

<script src="//crypto-js.googlecode.com/svn/tags/3.1.2/build/rollups/sha256.js"></script>

<script type="text/javascript">
    mokoala.base_href = '<?php print $config->site->base_href; ?>';
    mokoala.site_href = '<?php print $config->site->url; ?>';
    mokoala.settings_upload_max_filesize = '<?php print $config->site->settings->upload_max_filesize; ?>';

</script> 

<!-- Google Analytics Tracking Code Starts -->
<?php print $config->site->analytics; ?>
<!-- Google Analytics Tracking Code Ends -->

<!-- Scripts End Here -->
</body>
</html>