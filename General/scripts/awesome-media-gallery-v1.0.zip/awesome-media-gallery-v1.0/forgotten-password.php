<?php

require_once('_inc.php');



ob_start();



$head_title[] = 'Password Recovery';



if($user->isAuthorized()){

	header('Location: '.MK_Utility::serverUrl('/'), true, 302);

	exit;

}



$body_class[] = 'narrow';



$settings = array(

	'attributes' => array(

		'class' => 'clear-fix standard'

	)

);



$structure = array(

	'email' => array(

		//'label' => 'Your Email',

		'validation' => array(

			'email' => array(),

			'instance' => array(),

		),
    'attributes' => array(
        'placeholder' => 'Email Address'
			)

	),

	'submit' => array(

		'type' => 'submit',

		'attributes' => array(

			'value' => 'Recover password',
      'class' => 'btn-normal btn-primary'

		)

	)

);



$form = new MK_Form($structure, $settings);



if($form->isSuccessful())

{

	$user_type = MK_RecordModuleManager::getFromType('user');

	$user_search = array(

		array('field' => 'email', 'value' => $form->getField('email')->getValue()),
		array('field' => 'type', 'value' => MK_RecordUser::TYPE_CORE)

	);

	$user_search = $user_type->searchRecords($user_search);



	if( $reset_user = array_pop($user_search) )

	{

		$new_password = MK_Utility::getRandomPassword(8);

		$reset_user

			->setPassword($new_password)

			->save();

?>

<!--<h3>Password Recovery</h3>-->

<p class="alert alert-success">We have sent you an email containing your new password.</p>
<p class="alert alert-success"><a href="sign-in.php">Click here</a> to access the login screen.</p>

<?php

		$message = '<p style="padding: 0 22px;">Dear '.$reset_user->getDisplayName().',<br /><br />Your new password is: <strong>'.$new_password.'</strong></p>';

		$mailer = new MK_BrandedEmail();

		$mailer

			->setSubject('Password Recovery')

			->setMessage($message)

			->send($reset_user->getEmail(), $reset_user->getDisplayName());

	}

	else

	{

		$form->getField('email')->getValidator()->addError('This email does not match our records. Please try again.');

?>

		<!--<h3>Password Recovery</h3>-->

		<p style="padding: 0 22px;">Enter your email below, to reset your password.</p>
    <p style="padding: 0 22px;">If you sign in using a social network (Facebook/Google, etc.) then re-setting your password here will not work.</p>
<?php

		print $form->render();

	}

}

else

{

?>

		<!--<h3>Password Recovery</h3>-->

		<p style="padding: 0 22px;">Enter your email below, to reset your password.</p>
    <p style="padding: 0 22px;">NOTE: If you sign in using a social network (Facebook/Google, etc.) then re-setting your password here will not work.</p>
<?php



	print $form->render();

}



$output = ob_get_contents();

ob_end_clean(); ?>



<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
  <head>
	  <base href="<?php echo $config->site->url; ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="robots" content="noindex">
    <title><?php echo implode(' / ', $head_title); ?></title>
    <script type="text/javascript">



      window.onload = function() {
        if (parent) {
            
            var oHead = document.getElementsByTagName("head")[0];
            var arrStyleSheets = parent.document.getElementsByTagName("style");
            
            for (var i = 0; i < arrStyleSheets.length; i++)
                oHead.appendChild(arrStyleSheets[i].cloneNode(true));
                
            var arrExternalSytles = parent.document.getElementsByTagName("link");
            
            for (var i = 0; i < arrExternalSytles.length; i++)
                oHead.appendChild(arrExternalSytles[i].cloneNode(true));
            
        }
      
 	        var $ = jQuery = window.parent.$;
        
	     	        
   	        parent.$('#SignInFrame').css('height', '270px');

	        parent.$(".sign-in-container").css("max-height", '270px');
	        
	        parent.$(".sign-in-container").css("height", '270px');
      }

      

    </script>
  </head>
  <body class="modal-body modal-forgot-password"><?php

echo $output;?>
  </body>
</html>