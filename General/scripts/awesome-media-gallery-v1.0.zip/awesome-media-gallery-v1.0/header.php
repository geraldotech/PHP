<?php header('Content-type: text/html; charset=utf-8'); ?>
<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <base href="<?php echo $config->site->url; ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=10" />
    <meta charset="UTF-8">

    <?php
    //Custom SEO and Social Meta Tags
    include ('includes/social-meta-tags.php'); ?>

    <title><?php echo htmlspecialchars($meta_title); ?></title>
    <meta name="description" content="<?php echo $meta_description; ?>"> <?php 
	
    if( !empty($config->site->facebook->app_id) && $config->site->facebook->app_id ) { ?> 
        <meta property="fb:app_id" content="<?php echo $config->site->facebook->app_id; ?>"/><?php 
    } ?>
    <meta property="og:locale" content="en_US"/>
    <meta property="og:url" content="<?php echo "http://" . $_SERVER['HTTP_HOST'] . htmlspecialchars($_SERVER['REQUEST_URI']); ?>"/>
    <meta property="og:site_name" content="<?php echo $meta_sitename_clean; ?>"/>
    <meta property="og:title" content="<?php echo htmlspecialchars($meta_title) ?>">
    <meta property="og:description" content="<?php echo $meta_description; ?>">
    <meta property="og:image" content="<?php echo $meta_image_src; ?>">
    <?php echo $facebook_meta; ?>

    <meta property="twitter:card" content="<?php echo $meta_twitter_card_type; ?>">
    <meta property="twitter:site" content="<?php echo $site_twitter_handle; ?>">
    <meta property="twitter:creator" content="<?php echo $meta_twitter_creator;?>">
    <meta property="twitter:title" content="<?php echo htmlspecialchars($meta_title); ?>">
    <meta property="twitter:description" content="<?php echo $meta_description; ?>">
    <meta property="twitter:image" content="<?php echo $meta_image_src; ?>">
    <?php echo $twitter_meta;
    
    if (($deviceType == 'phone') || ($deviceType == 'tablet'))  {  ?>
        <meta name="viewport" content="width=device-width"><?php
    } else { ?>
        <meta name="viewport" content="width=device-width"><?php
    } ?>

    <!-- Favicon and Apple Icons Start -->
    <link href="favicon.png" rel="icon" type="image/x-icon">
    <!-- Favicon and Apple Icons End -->

    <!-- Stlye Sheets Start Here -->
    <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.2.0/pure-min.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="css/vendor/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/jquery-editable.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/component.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/jquery.dropdown.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/activity-feed.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/entypo.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/socicon.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/elastislide.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/nprogress.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/jquery.fancybox.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/socialcount.min.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/socialcount.pinterest.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/green.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/fancySelect.css"><?php 
    
    if ($config->site->dev_mode == 1) { //Less development mode. If turn on less will be recomplied on the fly.
        autoCompileLess('css/style.less', 'css/style.css');
    } ?>
    
    <link rel="stylesheet" type="text/css" href="css/style.css"><?php 

    if ($deviceType == 'phone') { ?>
        <link rel="stylesheet" type="text/css" href="css/mobile-phone.css"><?php
    } elseif ($deviceType == 'tablet') { ?>
        <link rel="stylesheet" type="text/css" href="css/mobile-tablet.css"><?php
    } ?>
    <!-- Stlye Sheets End Here -->

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>

    <!--[if lt IE 9]>
      <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
      <script>window.html5 || document.write('<script src="js/vendor/html5shiv.js"><\/script>')</script>
    <![endif]-->
</head>

<body>
  <!--[if lt IE 10]>
  <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
  <![endif]-->
 
<?php
$gallery_list             = MK_RecordModuleManager::getFromType('image_gallery');
$search_criteria_video[]  = array('literal' => "(`type_gallery` = 2)");
$gallery_videos           = $gallery_list->searchRecords($search_criteria_video);

$gallery_list_images      = MK_RecordModuleManager::getFromType('image_gallery');
$search_criteria_images[] = array('literal' => "(`type_gallery` = 1)");
$gallery_images           = $gallery_list_images->searchRecords($search_criteria_images); ?>
 
<div class="header-container <?php if ( $user->isAuthorized() ) echo 'logged-in'; ?>">

    <header class="clearfix">
  
        <div class="wrapper">
    
            <div class="pure-g-r">
      
                <div class="pure-u-1-2">
          
                    <div id="logo"><!-- Logo --><?php 
            
                        if( $config->site->logo ) { ?>
                
                            <a href="<?php echo $config->site->url; ?>"><img src="<?php echo $config->site->logo; ?>"  alt="<?php echo $meta_sitename_clean; ?>"></a><?php 
                         
                        } ?>
                        
                    </div>
          
                    <div class="pure-g"> 
                    
                        <div class="tagline">
                            <span id="tag-2"><?php echo $config->site->caption; ?></span>	
                        </div>
            
                    </div>
          
                </div>

                <div class="pure-u-1-2 header-sub">
          
                    <?php include ('includes/ad-header.php');
          
                    if ($config->site->enable_search) { //ENABLE SEARCH IN ADMIN $config->extensions->gallery->search ?>
          
                        <div class="search"><!-- Search Box --> 
       
                            <form name="form" autocomplete="on" enctype="multipart/form-data" method="get" action="index.php" class="pure-form">
            
                                <input placeholder="Search for Media Tags" type="text" class="data input-text pure-input" name="s" id="s" value="">
                                
                                <button class="pure-button header-search-button">
                                    <i class="search icon "></i> 	    
                                </button>
            
                            </form> 
            
                        </div><?php 
         
                    } ?>
          
                </div>

            </div>
      
        </div><!-- Wrapper Ends -->

        <div id="user-menu" class="stick blurheader"> <!-- Navigation Starts Here -->
    
            <div class="user-menu-bg"></div>
            
                <div class="wrapper">
      
                    <div class="nav pure-g-r">
        
                        <div class="pure-u-11-24">
          
                            <div class="logo-sticky"> <!-- Sticky Logo -->
                                
                                <a href="<?php echo $config->site->url; ?>"><img src="<?php echo $config->site->logo_sticky; ?>"  alt="<?php echo $meta_sitename_clean; ?>"></a>
                            
                            </div><?php 
            
                            if (isset($breadcrumb) && $breadcrumb <> '') { //Display Breadcrumb variable set from breadcrumbs.php ?>
              
                                <div class="breadcrumb"><?php 
                    
                                    echo $breadcrumb; ?>
                                
                                </div><?php
                            
                            } ?>
          
                        </div>
        
                    <div class="nav-main pure-u-13-24"><?php 
          
                        if( !$user->isAuthorized() ) { //Only Display the upload button for logged in users. DH ENGAGE 29/08. ?>
          
                            <span class="menu-item en-trigger" data-modal="modal-sign-up" data-style="slide-up"><i class="user-add icon"></i>Sign Up</span><?php
                        
                        } else { ?>
          
                            <span id="menu-item-upload" class="menu-item en-trigger" data-modal="modal-choose" data-style="slide-up"><i class="upload-2 icon"></i>Upload</span><?php
                            
                        } ?>
                    
                        <span class="menu-item"><i class="users icon"></i><a href="members">Members</a></span><?php 
          
                        if ( $gallery_videos != NULL ) { ?>
          
                             <!-- Videos Menu Starts -->
                            <span class="nav-dropdown menu-item" data-dropdown="#video-drop" data-vertical-offset="10" data-horizontal-offset="2">
                                <i class="video icon"></i>
                                <a href="#">Videos</a>
                                <i class="arrow-down-6 icon"></i>
                            </span>
                            
                            <div id="video-drop" class="dropdown dropdown-tip dropdown-anchor-right dropdown-relative">
                                <ul class="dropdown-menu"><?php

                                    foreach($gallery_videos as $gallery) {
                        
                                        $total_records = $image_module->getTotalRecords(array(
                                            array('field' => 'gallery', 'value' => $gallery->getId())
                                        )); ?>
                                    
                                        <li>
                                            <a href="gallery/<?php print $gallery->getId(); ?>"><div class="badge"><?php echo $total_records; ?></div><span><?php echo $gallery->getName(); ?></span></a>
                                        </li><?php
                                    } ?>
                                
                                </ul>
            
                            </div>
                            <!-- Video Menu Ends --><?php
                        
                        }
          
                        if ( $gallery_images != NULL ) { ?>
           
                             <!-- Photos Menu Starts -->
                            <span class="nav-dropdown menu-item" data-dropdown="#gallery-drop" data-vertical-offset="10" data-horizontal-offset="2">
                                <i class="pictures icon"></i>
                                <a href="#">Images</a>
                                <i class="arrow-down-6 icon"></i>
                            </span>
                            
                            <div id="gallery-drop" class="dropdown dropdown-tip dropdown-anchor-right dropdown-relative">
                                
                                <ul class="dropdown-menu"><?php
                
                                    $gallery_list_images      = MK_RecordModuleManager::getFromType('image_gallery');
                                    $search_criteria_images[] = array('literal' => "(`type_gallery` = 1)");
                                    $gallery_images           = $gallery_list_images->searchRecords($search_criteria_images);
                
                                    foreach($gallery_images as $gallery) {
                                        
                                        $total_records = $image_module->getTotalRecords(array(
                                            array('field' => 'gallery', 'value' => $gallery->getId())
                                        )); ?>
                                        
                                        <li>
                                            <a href="gallery/<?php print $gallery->getId(); ?>"><div class="badge"><?php echo $total_records; ?></div><span><?php echo $gallery->getName(); ?></span></a>
                                        </li><?php
                                    } ?>
                                    
                                </ul>
                            
                            </div>
                            <!-- Photos Menu Ends --><?php
                        
                        }
                        
                        if( $user->isAuthorized() ) {
              
                            $user_notification_module = MK_RecordModuleManager::getFromType('user_notification');
          
                            $activity_feed_unread = $user_notification_module->getTotalRecords(array(
                                array('field' => 'user', 'value' => $user->getId()),
                                array('field' => 'public', 'value' => 0),
                                array('field' => 'unread', 'value' => 1)
                            )); ?>        
                            
                            <!-- My Account Menu Starts -->
                            <span class="nav-dropdown menu-item" data-dropdown="#myaccount-drop" data-vertical-offset="10" data-horizontal-offset="8">
                
                            <span id="mini-avatar">
                                <img src="library/thumb.php?f=<?php echo ($user->getAvatar() ? $user->getAvatar() : $config->site->default_avatar ); ?>&amp;h=24&amp;w=24&amp;m=crop" alt="">
                            </span>
                
                            <span id="user-name"><?php echo $user->getDisplayName(); ?></span>
                                <i class="arrow-down-6 icon"></i>
                            </span>
              
                            <div id="myaccount-drop" class="dropdown dropdown-tip dropdown-anchor-right dropdown-relative">
               
                                <ul class="dropdown-menu">
                                    
                                    <li><a href="<?php echo getProfileUrl($user->getId()); ?>"><i class="user icon"></i><span>My Profile</span></a></li>
                  
                                    <li><a href="<?php echo getProfileUrl($user->getId()); ?>/activity"><i class="clock icon"></i><span>Activity Feed</span></a></li>
                  
                                    <li><a href="<?php echo getProfileUrl($user->getId()); ?>/images"> <i class="pictures icon"></i><span>Images</span></a></li>
                                    
                                    <li><a href="<?php echo getProfileUrl($user->getId()); ?>/videos"><i class="video icon"></i><span>Videos</span></a></li>
                  
                                    <li><a href="<?php echo getProfileUrl($user->getId()); ?>/likes"><i class="heart icon"></i><span>Favorites</span></a></li>
                  
                                    <li><a href="<?php echo getProfileUrl($user->getId()); ?>/followers"><i class="flow-tree icon"></i><span>Followers</span></a></li>
                  
                                    <li><a href="<?php echo getProfileUrl($user->getId()); ?>/following"><i class="flow-branch icon"></i><span>Following</span></a></li>
                  
                                    <li class="dropdown-divider"></li><?php 
                  
                                    if (empty($_SESSION["OAUTH_ACCESS_TOKEN"])) { //User is not logged in using a social network, show the change password link. ?>
                  
                                        <li><a href="#" class="en-trigger" data-modal="modal-change-password" data-style="slide-up"><i class="user-add icon"></i><span>Change Password</span></a></li><?php
                                    
                                    } ?>
                  
                                    <li><a href="sign-out.php"><i class="logout icon"></i><span>Sign Out</span></a></li>
                
                                </ul>
                            
                            </div>
                            <!-- My Account Menu Ends --><?php
            
                        } else { // User is not logged in ?>
              
                            <span class="menu-item en-trigger" data-modal="modal-sign-in" data-style="slide-up"><i class="key icon"></i> Sign In</span><?php 
            
                        } ?>

					</div> <!-- End Two Thirds -->
          
				</div>
			
            </div> <!-- Wrapper Ends -->

        </div> <!-- End Navigation -->

    </header>

</div>