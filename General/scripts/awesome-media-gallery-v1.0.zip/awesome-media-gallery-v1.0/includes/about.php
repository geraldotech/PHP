<div class="scroller about">
<h3>About These Modals</h3>

<p>You can easily build your own modals by following our methods. Note: Sometimes the modals need a small padding tweak to keep them from being slightly blurry. To adjust the modals, there are 4 main sections within the modal.less CSS file - make sure you study it a bit before making your changes. To find out more about manually adjusting fuzzy modals, <a href="http://awesome-gallery-docs.engagefb.com/Tips/Coding_Tips#modals" target="_blank" style="text-decoration:underline;">click here</a>.</p>
<br>
<p>Awesome Social Gallery!<br>
A sharing community<br><br>
Questions?<br>
<a href="mailto:hello@en.gg" style="text-decoration:underline;">Email us</a></p>

</div>