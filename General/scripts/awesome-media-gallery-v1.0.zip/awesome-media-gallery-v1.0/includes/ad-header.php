<div class="ad-space-top"><!-- Ad Space -->
	<!-- New Ad Space empty for next version -->
</div>