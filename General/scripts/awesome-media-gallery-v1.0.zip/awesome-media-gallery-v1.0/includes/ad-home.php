<div class="ad-space-home-wrapper">
	<div class="ad-bar-home" id="ad_holder"><?php
	    if($config->site->adhome728x90) { ?>
	        <div class="ad-space-home"><!-- Ad Space -->
	            <?php echo $config->site->adhome728x90; ?>
	        </div><?php
	    }
	    
	    if($config->site->adhome242x90) { ?>
	        <div class="ad-space-home2"><!-- Ad Space -->
	            <?php echo $config->site->adhome242x90; ?>
	        </div><?php
	    } ?>
	</div>
</div>