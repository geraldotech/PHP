<aside class="sidebar pure-u-1-4"><?php
    if($config->site->adsidebar160x600) { ?>
        <div class="side-ad"><?php 
            echo $config->site->adsidebar160x600; ?>
        </div><?php
    } ?>
</aside>