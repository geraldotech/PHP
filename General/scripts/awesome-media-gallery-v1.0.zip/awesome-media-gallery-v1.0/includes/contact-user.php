<?php
//print '<h3>Contact</h3>';

//echo ($user_id);
//exit();

if (($_SERVER['REQUEST_METHOD'] != 'POST') ) {

   try {
  
      if (!empty($user_id) ) {
      
        $user_module = MK_RecordModuleManager::getFromType('user');
        $user_record = MK_RecordManager::getFromId( $user_module->getId(), $user_id );
      
        $user_to_email = $user_record->getMetaValue('email');
      
      } else {
      
        throw new Exception("User not found.");
      
      }
  
  } catch( Exception $e ) {
    
        header('Location: ' . $config->site->url . 'not-found.php', true, 301);
        exit;
    
    }

} else {
  $user_to_email = NULL;
}

$settings = array(
	'attributes' => array(
		'class' => 'clear-fix standard'
	)
);

$structure = array(
	
	'name' => array(
		//'label' => 'Your Name',
		'validation' => array(
			'instance' => array(),
		),
    'attributes' => array(
      'placeholder' => 'Your Name'
		)
	),
  
  
  'email' => array(
		//'label' => 'Your Email',
		'validation' => array(
			'email' => array(),
			'instance' => array()
		),
    'attributes' => array(
      'placeholder' => 'Your Email Address'
		)
	),
  
	'message' => array(
		'type' => 'textarea',
		//'label' => 'Your Message',
		'validation' => array(
			'instance' => array(),
		),
    'attributes' => array(
      'placeholder' => 'Your Message'
		)
	),
  'user_to_email' => array(
    'attributes' => array(
      'type' => 'hidden',
    ),
    'value' => $user_to_email
  ),
	'send' => array(
		'type' => 'submit',
		'attributes' => array(
			'value' => 'Send Your Message',
      'class' => 'btn-normal btn-primary'
		)
	)
);

$contact_form = new MK_Form($structure, $settings);	

if($contact_form->isSuccessful())
{
	$message = "<p><strong>From:</strong> ".$contact_form->getField('name')->getValue()."<br><strong>From Email:</strong> ".$contact_form->getField('email')->getValue()."<br><br>".nl2br($contact_form->getField('message')->getValue())."</p>";
	$email = new MK_BrandedEmail();
	$email
		->setSubject('Someone has contacted you!')
		->setReplyTo($contact_form->getField('email')->getValue())
		->setMessage($message)
		//->send($config->site->email);
    ->send($contact_form->getField('user_to_email')->getValue());
    ?>
	<p class="notice-text">Thanks your message has been sent.</p>
<?php
}
else
{

  print $contact_form->render();
  
  }
?>
