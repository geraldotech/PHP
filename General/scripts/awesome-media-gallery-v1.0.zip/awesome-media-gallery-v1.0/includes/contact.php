<?php
//print '<h3>Contact</h3>';

$settings = array(
	'attributes' => array(
		'class' => 'clear-fix standard'
	)
);

$structure = array(
	'email' => array(
		//'label' => 'Your Email',
		'validation' => array(
			'email' => array(),
			'instance' => array()
		),
    'attributes' => array(
      'placeholder' => 'Your Email Address'
		)
	),
	'name' => array(
		//'label' => 'Your Name',
		'validation' => array(
			'instance' => array(),
		),
    'attributes' => array(
      'placeholder' => 'Your Name'
		)
	),
	'message' => array(
		'type' => 'textarea',
		//'label' => 'Your Message',
		'validation' => array(
			'instance' => array(),
		),
    'attributes' => array(
      'placeholder' => 'Your Message'
		)
	),
	'send' => array(
		'type' => 'submit',
		'attributes' => array(
			'value' => 'Send Your Message',
      'class' => 'btn-normal btn-primary'
		)
	)
);

$contact_form = new MK_Form($structure, $settings);	

if($contact_form->isSuccessful())
{
	$message = "<p><strong>Name:</strong> ".$contact_form->getField('name')->getValue()."<br><strong>Email:</strong> ".$contact_form->getField('email')->getValue()."<br><br>".nl2br($contact_form->getField('message')->getValue())."</p>";
	$email = new MK_BrandedEmail();
	$email
		->setSubject('Contact Form')
		->setReplyTo($contact_form->getField('email')->getValue())
		->setMessage($message)
		->send($config->site->email);
?>
	<p class="notice-text">Thanks for messaging us - we'll get back to you shortly.</p>
<?php
}
else
{
	print $contact_form->render();
}
?>
