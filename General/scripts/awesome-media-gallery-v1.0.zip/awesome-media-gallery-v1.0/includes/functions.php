<?php

function clean_name($tmp) {
	$tmp = str_replace(" & ","_",$tmp);
	$tmp = str_replace("&","_",$tmp);
	$tmp = str_replace("+","_",$tmp);
	$tmp = str_replace(".","",$tmp);
	$tmp = str_replace("\'s","s",$tmp);
	$tmp = str_replace("\'","",$tmp);
	$tmp = str_replace("/","",$tmp);	
	$tmp = str_replace("'","",$tmp);
	$tmp = str_replace(")","",$tmp);
	$tmp = str_replace("(","",$tmp);
	$tmp = str_replace(" - ","-",$tmp);						   
	$tmp = str_replace("  ","",$tmp);	
	$tmp = str_replace(" ","",$tmp);
	$tmp = trim($tmp);
	return $tmp;
}

function getImageTypeName($id = NULL) {
	if ($id==1){
		$n = 'image';
	} elseif ($id==2) {
		$n = 'video';
	} else{
		$n = '';
	}
	
	return $n;
}

function time_since($since) { //Should be passed in seconds
  $chunks = array(
      array(60 * 60 * 24 * 365 , 'yr'),
      array(60 * 60 * 24 * 30 , 'mth'),
      array(60 * 60 * 24 * 7, 'wk'),
      array(60 * 60 * 24 , 'day'),
      array(60 * 60 , 'hr'),
      array(60 , 'min'),
      array(1 , 'sec')
  );

  for ($i = 0, $j = count($chunks); $i < $j; $i++) {
      $seconds = $chunks[$i][0];
      $name = $chunks[$i][1];
      if (($count = floor($since / $seconds)) != 0) {
          break;
      }
  }

  $print = ($count == 1) ? '1 '.$name : "$count {$name}s";
  return $print;
}

function text2urls($Text) {
	if (preg_match("/http/", $Text) OR preg_match("/www/", $Text))
	{
	$Text = str_replace(" www" , " http://www" , $Text);
	$Explode = explode(" ", $Text);
	foreach($Explode as $Check) {if (preg_match("/http/", "$Check") OR preg_match("/www/", "$Check")) {$Text = str_replace($Check , "$Check" , $Text);}}
	}
	return $Text;
}

function makeClickableLinks($s) {
  return preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$1</a>', $s);
}

function truncate($string, $chars) {
	$string = preg_replace( "/\r|\n/", " / ", $string );
	
	if (strlen($string) > $chars) {
		$string = substr($string,0,$chars) . '...';
	} else {
		$string = $string;
	}
	return $string;
}


function emailReportedImage() {
  global $image;
  global $config;
  global $image_page;

  $email = new MK_BrandedEmail();
  $email
  ->setSubject('Image Reported')
  ->setMessage('<p>The image <a href="'.MK_Utility::serverUrl( $image_page.'?image='.$image->getId() ).'">'.$image->getTitle().'</a> has been reported.</p>')
  ->send( $config->site->email );
  return 'Success';
}

function returnFavouriteHeart() {

  global $user;
  global $image;
  global $image_favourite_module;
  global $total_favourites;
  global $image_favourites;
  global $favourite_id;
  global $favourite;

  if( $user->isAuthorized() ) {

    //GET WHETHER THIS IS A FAVORITE IMAGE OR NOT
      $favourite = $image_favourite_module->searchRecords(array(
				array('field' => 'image', 'value' => $image->getId()),
				array('field' => 'user', 'value' => $user->getId())
			));
			$favourite = array_pop($favourite);
      

    if (!empty($favourite)) { // USER HAS RIGHT TO KNOW IF IMAGE HAS BEEN LIKED BY HIM OR NOT

      $favourite_id = $favourite->getId(); 
      $fav_class    = 'remove-favourite';
      $has_fav      = 'favourite';
      $title_text   = 'Remove Favorite';
      
    } else {

        $favourite_id = ""; //Has not been favorited
        $fav_class  = 'add-favourite';
        $has_fav = '';
         $title_text   = 'Add Favorite';
    }


    /****************** LOGGED IN AND THIS IS NOT YOUR IMAGE PAGE *******************/
    if( $user->getId() != $image->getUser() ) { //OK TO FAVOURITE

      //$favourite = array_pop($favourite);

      $image_favourites = '<span title="'. $title_text .'" rel="image '. $fav_class .'" data-image-favourites-total="' . $total_favourites . '" class="pure-u meta-hearts stats red '.  $has_fav .'" data-user-id="' .$user->getId() . '" data-image-id="' .$image->getId() . '" data-image-favourite-id="' . $favourite_id . '"><i class="heart icon"></i><span class="text">' .number_format($total_favourites) . '</span></span>';

      
    } else { //CANNOT FAV IMAGE
      
      $image_favourites = '<span data-image-favourites-total="' . $total_favourites . '" class="pure-u meta-hearts stats" data-user-id="' .$user->getId() . '" data-image-id="' .$image->getId() . '"><i class="heart icon"></i><span class="text">' .number_format($total_favourites) . '</span></span>';
      
    } //END NOT YOUR PAGE 
      
  } else { //NOT LOGGED IN - CANNOT FAV IMAGE
	  
	  global $deviceType;
	  $modalClass = '';
	  if (!($deviceType=='phone') && !($deviceType=='tablet')){
		  $modalClass='en-trigger';
	  }
	
    $image_favourites = '<span data-image-favourites-total="' . $total_favourites . '" class="pure-u meta-hearts stats ' . $modalClass . '" data-modal="modal-sign-in" data-style="slide-up" data-user-id="' .$user->getId() . '" data-image-id="' .$image->getId() . '"><i class="heart icon"></i><span class="text">' .number_format($total_favourites) . '</span></span>';
    
  } 

  return $image_favourites;

}

function generateUsername( $displayName ) {

    $userName = str_replace(" ", "", $displayName );
    $userName = strtolower( $userName );
    
    return $userName;
}

/** 
  * Return embded url version of YouTube url.
  * @param string $url 
  * @return string 
  * Author: Daniel Hewes - ENGAGE INC
  */
function convertYouTubeUrl( $url ) {

    $search       = '/youtube\.com\/watch\?v=([a-zA-Z0-9s_s-]+)/smi';
    $search_short = '/youtu\.be\/([a-zA-Z0-9s_s-]+)/';
    
    $match = preg_match( $search, $url, $matches );
    
    if ( $match ) {
    
        return 'https://youtube.com/embed/' . $matches[1];
        
    } else {
    
        $match = preg_match( $search_short, $url, $matches );
        
        if ( $match ) {
        
            return 'https://youtube.com/embed/' . $matches[1];
        
        }
       
    }
    
}


/** 
  * Return embded url version of Vimeo url.
  * @param string $url 
  * @return string 
  * Author: Daniel Hewes - ENGAGE INC
  */
function convertVimeoUrl( $url ) { //Function to convert the vimeo watch URL to embed version
    

    $search     = '/vimeo\.com\/([0-9]{1,10})/';
    $replace    = "player.vimeo.com/video/$1";    
    $url        = preg_replace( $search, $replace, $url );
    
    $url = str_replace('http:', 'https:', $url);
    return $url;
}

/** 
  * Return embded url version of vine url.
  * @param string $url 
  * @return string 
  * Author: Daniel Hewes - ENGAGE INC
  */
function convertVine($url ) {
      
    //$url = $url . '/card?audio=1';
    $url = $url . '/embed/simple?audio=1';
    
    return $url;
    
}

/** 
  * Return True/False boolen. Check if url is YouTube.
  * @param string $url 
  * @return boolen
  * Author: Daniel Hewes - ENGAGE INC
  */
function isYouTube( $url ) {
     
    $rx = '#^http(?:s?)://(?:www\.)?youtu(?:be\.com/watch\?(?:.*?&(?:amp;)?)?v=|\.be/)([\w??\-]+)(?:&(?:amp;)?[\w\?=]*)?#i';

    $match = preg_match( $rx, $url, $matches );
    
    if ( $match == 1 ) {
    
        return true;
        
    } else {
    
        return false;
    
    }

}

/** 
  * Return True/False boolen. Check if url is Vimeo.
  * @param string $url 
  * @return boolen
  * Author: Daniel Hewes - ENGAGE INC
  */
function isVimeo( $url ) {

    $rx = '/^http:\/\/(www\.)?vimeo\.com\/(clip\:)?(\d+).*$/';
    
    $match = preg_match ($rx, $url, $matches);
    
    if ( $match == 1 ) {
    
        return true;
        
    } else {
    
        return false;
    
    }
    
}


/** 
  * Return True/False boolen. Check if url is Vine.
  * @param string $url 
  * @return boolen
  * Author: Daniel Hewes - ENGAGE INC
  */
function isVine( $url ) {

    $rx = '/^https:\/\/?vine\.co\/v\/?\b.*$/';
    
    $match = preg_match ($rx, $url, $matches );
    
    if ( $match == 1 ) {
    
        return true;
        
    } else {
    
        return false;
    
    }
    
}

/** 
  * Return Twitter username string
  * @param string $string 
  * @return string 
  * Author: Daniel Hewes - ENGAGE INC
  */
function convertTwitter( $url = NULL ) {

    $url = explode( "twitter.com/", $url );
    
    if( !empty( $url[1] ) ) {
    
        return '@' . $url[1];
    
    } else {
    
        return '';
    
    }
    
}

/** 
  * Return Twitter url string
  * @param string $string 
  * @return string 
  * Author: Daniel Hewes - ENGAGE INC
  */
function convertTwitterUsernameUrl( $username = NULL ) {

    $username = explode( "@", $username );
    
    if( !empty( $username[1] ) ) {
    
        return 'https://twitter.com/' . $username[1];
    
    } else {
    
        return '';
    
    }
    
}

/** 
  * Return URL-Friendly string slug
  * @param string $string 
  * @return string 
  * Author: Daniel Hewes - ENGAGE INC
  */
function seoUrl( $string ) {
    
    $string = strtolower($string); //Unwanted:  {UPPERCASE} ; / ? : @ & = + $ , . ! ~ * ' ( )
   
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string); //Strip any unwanted characters
    
    $string = preg_replace("/[\s-]+/", " ", $string); //Clean multiple dashes or whitespaces
    
    $string = preg_replace("/[\s_]/", "-", $string); //Convert whitespaces and underscore to dash
    
    return $string;
    
}

/** 
  * Return user profile url string
  * @param integer $userId 
  * @return string 
  * Author: Daniel Hewes - ENGAGE INC
  */
function getProfileUrl( $userId, $section = NULL ) {

    $user_module = MK_RecordModuleManager::getFromType( 'user' );
    $user        = MK_RecordManager::getFromId( $user_module->getId(), $userId );
    
    if ( $user->getUsername() ) {
    
        if ( !empty( $section ) ) { 
        
            $section = '/' . $section;
        
        }
    
       return $user->getUsername() . $section;
    
    } else {
        
        if ( !empty( $section ) ) {
        
            $section = '&amp;section=' . $section;
        
        }
        
        return 'member.php?user=' . $user->getId() . $section;
    
    }

}


function buildSearchOptions($gallery_id = NULL, $image_module_id, $tag = NULL, $order_by = NULL, $image_type = NULL, $search_keywords = NULL) {
    
    $image_module         = MK_RecordModuleManager::getFromType('image'); //Image details
    $gallery_module       = MK_RecordModuleManager::getFromType('image_gallery'); //Gallery Info
    $image_comment_module = MK_RecordModuleManager::getFromType('image_comment'); //Comments Info
    $field_module         = MK_RecordModuleManager::getFromType('module_field');
    $user_module          = MK_RecordModuleManager::getFromType('user');
    
    $options         = array();
    $search_criteria = array();
    
    //Setup the order by options.
    if ( !empty( $order_by ) ) {
    
        switch ( $order_by ) {
        
            case 'favorites' :
            
                $order_by_field = $field_module->searchRecords(array(
                    array('field' => 'module', 'value' => $image_module->getId()),
                    array('field' => 'name', 'value' => 'total_favourites')
                ));
                
                $order_by_field = array_pop( $order_by_field );

                $options = array(
                    'order_by' => array(
                        'field' => $order_by_field->getId(),
                        'direction' => 'DESC'
                    )
                );
            
            break;
            
            case 'comments' :
                
                $order_by_field = $field_module->searchRecords(array(
                    array('field' => 'module', 'value' => $image_module->getId()),
                    array('field' => 'name', 'value' => 'total_comments')
                ));
                
                $order_by_field = array_pop( $order_by_field );
                
                $options = array(
                    'order_by' => array(
                        'field' => $order_by_field->getId(),
                        'direction' => 'DESC'
                    )
                );
                
                break;
                
            case 'popular' :
            
                $order_by_field = $field_module->searchRecords(array(
                    array('field' => 'module', 'value' => $image_module->getId()),
                    array('field' => 'name', 'value' => 'views')
                ));
                
                $order_by_field = array_pop( $order_by_field );

                $options = array(
                    'order_by' => array(
                        'field' => $order_by_field->getId(),
                        'direction' => 'DESC'
                    )
                );
                
                break;
                
            case 'featured' : 
                
                $search_criteria[] = array(
                    'field' => 'featured', 'value' => 1
                );
      
                $order_by_field = $field_module->searchRecords(array(
                    array('field' => 'module', 'value' => $image_module->getId()),
                    array('field' => 'name', 'value' => 'featured_date')
                ));
                
                $order_by_field = array_pop( $order_by_field );
      
                $options = array(
                    'order_by' => array(
                        'field' => $order_by_field->getId(),
                        'direction' => 'DESC'
                    )
                );
                
                break;
        }
    
    }
    
     //Create search criteria on gallery id
    if ( !empty( $image_type ) ) {
    
        $search_criteria = array(
            array('literal' => ' `type_gallery` IN (' . $image_type . ') ')
        );
    
    }
    
    //Create search criteria on gallery id
    if ( !empty( $gallery_id ) ) {
    
        $search_criteria = array(
            array('literal' => ' `gallery` IN (' . $gallery_id . ') ')
		);
    
    }
    


    //Create search criteria on tag
    if( !empty( $tag ) ) {
        
        $tag_wildcard = '%,'.$tag.',%';
        
        $search_criteria[] = array('literal' => "CONCAT(',', `tags`, ',') LIKE ".MK_Database::getInstance()->quote($tag_wildcard));
    
    }
    
    if( !empty( $search_keywords ) ) {

        $keywords_wildcard = '%' . $search_keywords . '%';
        $keywords_wildcard = MK_Database::getInstance()->quote( $keywords_wildcard );
    
        $matching_galleries = array();
        $matching_users     = array();

        //Gallery Search
        $gallery_search = $gallery_module->searchRecords(array(
            array('literal' => "(`name` LIKE " . $keywords_wildcard . ")")
        ));
    
        foreach( $gallery_search as $gallery_search_single ) {
      
            $matching_galleries[] = $gallery_search_single->getId();
        
        }

        //User Search
        $user_search = $user_module->searchRecords(array(
            array('literal' => "(`display_name` LIKE " . $keywords_wildcard . ")")
        ));
    
        foreach( $user_search as $user_search_single ) {
        
            $matching_users[] = $user_search_single->getId();
        
        }

        //Keywords
        $search_criteria[] = array(
            'literal' => "(`title` LIKE " . $keywords_wildcard . " OR `description` LIKE " . $keywords_wildcard . " OR `tags` LIKE ".$keywords_wildcard ." ".( !empty($matching_galleries) ? " OR `gallery` IN(".implode(',', $matching_galleries).") " : "" ) . " " . ( !empty($matching_users) ? " OR `user` IN(".implode(',', $matching_users).") " : "" ) ." )"
        );
        
    }
    
    return array(
        'options'         => $options,
        'search_criteria' => $search_criteria
    );

}


function autoCompileLess($inputFile, $outputFile) {
  // load the cache
  $cacheFile = $inputFile.".cache";

  if (file_exists($cacheFile)) {
    $cache = unserialize(file_get_contents($cacheFile));
  } else {
    $cache = $inputFile;
  }

  $less = new lessc;
  
  try {
    $newCache = $less->cachedCompile($cache);
} catch (Exception $ex) {
    echo "lessphp fatal error: ".$ex->getMessage();
}
  
  

  if (!is_array($cache) || $newCache["updated"] > $cache["updated"]) {
    file_put_contents($cacheFile, serialize($newCache));
    file_put_contents($outputFile, $newCache['compiled']);
  }
}


function getShortUrl($url,$login,$appkey,$enabled) {
	if ($enabled==1) {
		$url = get_bitly_short_url($url,$login,$appkey);
		return $url;
	} else {
		return $url;
	}
	
}

//BITLY SHORT URL FUNCTIONS

/* returns the shortened url */
function get_bitly_short_url($url,$login,$appkey,$format='txt') {
	$connectURL = 'http://api.bit.ly/v3/shorten?login='.$login.'&apiKey='.$appkey.'&uri='.urlencode($url).'&format='.$format;
	return curl_get_result($connectURL);
}

/* returns expanded url */
function get_bitly_long_url($url,$login,$appkey,$format='txt') {
	$connectURL = 'http://api.bit.ly/v3/expand?login='.$login.'&apiKey='.$appkey.'&shortUrl='.urlencode($url).'&format='.$format;

	return curl_get_result($connectURL);
}

/* returns a result form url */
function curl_get_result($url) {
	$ch = curl_init();
	$timeout = 5;
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}


/** 
  * Returns an array of the last x members information
  * @param integer $count
  * @return array
  * Author: Daniel Hewes - ENGAGE INC
  */
function getLastMembers($count = NULL) {

    $members_module = MK_RecordModuleManager::getFromType('user');
    
    $members_search_criteria = array(); //Setup the search criteria array
    $options                 = array(
                                'order_by' => array(
                                    'field' => 376,
                                    'direction' => 'DESC'
                                    )
                                );

    $members = $members_module->searchRecords($members_search_criteria, NULL, $options); 

    $members = array_slice($members, 0, $count); //Trim down the array to the desired length.
    
    return $members;

}

/** 
  * Returns an array of the last x members images/videos
  * @param integer $count
  * @return array
  * Author: Daniel Hewes - ENGAGE INC
  */
function getItems($count = NULL, $type, $userId) {

    $image_module  = MK_RecordModuleManager::getFromType('image'); //Image details
    
    $images = $image_module->searchRecords(array(  
                                            array('field' => 'user', 'value' => $userId),
                                            array('field' => 'type_gallery', 'value' => $type))
                                            , NULL);

    $images = array_slice($images, 0, $count); //Trim down the array to the desired length.
    
    return $images;

}

/** 
  * Returns true is the file is an animated gif
  * @param string $file
  * @return boolen (only if true)
  * Author: Daniel Hewes - ENGAGE INC
  */
function isAnimatedGif($file) { //Returns true if file is an animated gif
    
    $filecontents = file_get_contents($file);
 
    $str_loc = 0;
    $count = 0;
 
    // There is no point in continuing after we find a 2nd frame
    while ( $count < 2 ) {
    
        $where1 = strpos($filecontents,"\x00\x21\xF9\x04", $str_loc);
        
        if ( $where1 === FALSE ) {
            break;
        }
 
        $str_loc = $where1 + 1;
        $where2  = strpos( $filecontents, "\x00\x2C", $str_loc);
        
        if ($where2 === FALSE) {
            break;
        } else {
        
            if ( $where1 + 8 == $where2) {
                $count++;
            }
        
            $str_loc = $where2 + 1;
        }
    }
 
    // gif is animated when it has two or more frames
    return ($count >= 2); 
}


?>