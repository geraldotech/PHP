<?php
$num_items = ($deviceType == 'phone')?12:$config->site->home_per_page;

$paginator = new MK_Paginator();
	$paginator
		->setPerPage($num_items)
		->setPage( MK_Request::getQuery('page', 1) );

/****************************** START SORT BY ******************************/

//echo 'ORDER BY IS:' . $order_by . '<br>';

$search_options = buildSearchOptions($gallery_id, $gallery_module->getId(), $tag, $order_by, $gallery_type, $search_keywords);

//ACTIVE BUTTONS
if( $order_by == 'latest' ) {$a1 = ' pure-button-active'; }else{$a1 = '';} 
if( $order_by == 'popular'){$a2 = ' pure-button-active'; }else{$a2 = '';} 
if( $order_by == 'comments' ){$a3 = ' pure-button-active'; }else{$a3 = '';}   
if( $order_by == 'favorites' ){$a4 = ' pure-button-active'; }else{$a4 = '';}   
if( $order_by == 'featured' ){$a5 = ' pure-button-active'; }else{$a5 = '';} 

if( $order_by == '' ){
  $a1 = ' pure-button-active'; 
} ?>

<?php

	if ($deviceType <> 'phone') { ?>

<!-- 728x90 Ad Banner -->
<?php include ('includes/ad-home.php'); ?> 

<?php 
	} ?>


<!-- Content Section GALLERY Starts Here -->
<section class="content gallery pure-u-1"> 
   
    <div class="gallery-nav">
	    <div class="not-visible">
			<select class="media-select selectize" id="media-select" onchange="window.location.replace(this.options[this.selectedIndex].value);">
		        <?php 
		        
		        	$current_url  = $_SERVER['REQUEST_URI'];
		        	$select_media = array(
		        		array(
		        			'type'  => 0,
		        			'text'  => 'All',
		        			'query' => 'index.php'
		        		),
		        		array(
		        			'type'  => 1,
		        			'text'  => "Images",
		        			'query' => 'media/images/'
		        		),
		        		array(
		        			'type'  => 2,
		        			'text'  => "Videos",
		        			'query' => 'media/videos/'
		        		)
		        	);
		        	foreach ($select_media as $selected){
			        	if ( $selected['type'] == $gallery_type ){
				        	echo '<option value="' . $selected['query'] . '" selected>'. $selected['text'] .'</option>';
			        	} else{
				        	echo '<option value="' . $selected['query'] . '">'. $selected['text'] .'</option>';
			        	}
		        	}
		        ?>
			</select><?php 
	    	
	    	$image_type_url = ( $image_type_name ) ? 'media/' . $image_type_name . '/' : ''; 
            $gallery_url    = ( !empty( $current_gallery ) ? 'gallery/' . $gallery_id . '/' : ''); ?>
        
	        <a href="<?php echo $gallery_url . $image_type_url; ?>order-by/latest<?php echo (!empty($search_keywords) ? '&amp;s='.$search_keywords : '')?><?php echo (!empty($tag) ? '&amp;tag='.$tag : '')?>" title="Newest Images"><div class="pure-button pure-button-primary<?php echo $a1; ?>"><span>Latest</span></div></a>
	          
	        <a href="<?php echo $gallery_url . $image_type_url; ?>order-by/popular<?php echo (!empty($search_keywords) ? '&amp;s='.$search_keywords : '')?><?php echo (!empty($tag) ? '&amp;tag='.$tag : '')?>" title="Most Views"><div class="pure-button pure-button-primary<?php echo $a2; ?>"><span>Popular</span></div></a>
	        
			<?php 
				if( !empty($config->site->enable_comments) && $config->site->enable_comments ) {
			?> 
	        <a href="<?php echo $gallery_url . $image_type_url; ?>order-by/comments<?php echo (!empty($search_keywords) ? '&amp;s='.$search_keywords : '')?><?php echo (!empty($tag) ? '&amp;tag='.$tag : '')?>" title="Most Comments"><div class="pure-button pure-button-primary<?php echo $a3; ?>"><span>Comments</span></div></a>	
	        <?php } ?>
	         
	        <a href="<?php echo $gallery_url . $image_type_url; ?>order-by/favorites<?php echo (!empty($search_keywords) ? '&amp;s='.$search_keywords : '')?><?php echo (!empty($tag) ? '&amp;tag='.$tag : '')?>" title="Most Favorites"><div class="pure-button pure-button-primary<?php echo $a4; ?>"><span>Favorites</span></div></a>
	          
	        <a href="<?php echo $gallery_url . $image_type_url; ?>order-by/featured" title="Featured"><div class="pure-button pure-button-primary<?php echo $a5; ?>"><span>Featured</span></div></a>
	    </div>
    </div>  

    <!-- Image grid-cs-cs Starts Here --><?php

    if( !empty($search_options) ) { //Using Search Criteria
   
      //  echo 'Using Serch Criteria';
        
        //var_dump($search_options);
       // die;
   
        $images = $image_module->searchRecords($search_options['search_criteria'], $paginator, $search_options['options']);

    } else {  //No Search Criteria
    
        $images = $image_module->getRecords($paginator, $search_options['options']);
    
    }

    if ( !empty( $images ) ) { ?>
    
        <ul class="awesome-gallery index" data-autoload="true"> <?php
    
        $counter = 0;
    
        foreach($images as $image)  {

            include 'includes/image-box.php';

        } //End Image Loop ?>
  
        </ul><?php
    
    } else { ?>
    
        <p class="alert alert-information">There are no items in this gallery.</p><?php
    
    } ?>
    
    <!-- Image grid-cs-cs Ends Here -->	            

    <div class="paginator"><?php echo $paginator->render($home_page.'?page={page}'.(!empty($current_gallery) ? '&amp;gallery='.$current_gallery->getId() : '').(!empty($search_keywords) ? '&amp;s='.$search_keywords : '').(!empty($order_by) ? '&amp;order-by='.$order_by : '')); ?></div>

</section>