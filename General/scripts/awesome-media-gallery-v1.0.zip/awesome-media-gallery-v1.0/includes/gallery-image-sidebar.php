<?php 
$rec_fav = $author->getTotalReceivedFavourites();
$rec_com = $author->getTotalReceivedComments();
$rec_view = $author->getTotalReceivedViews();

$tot_images = number_format($author->getTotalUserImages(1));
$tot_videos = number_format($author->getTotalUserImages(2));
$tot_followers = number_format($author->getTotalFollowers());
?>

<aside class="sidebar image-single pure-u-5-24">
	<div class="sidebar-wrapper">
		<span class="meta-avatar image loading">
			<a href="<?php echo $author->getUsername(); ?>"><img data-src="library/thumb.php?f=<?php echo ( $author_avatar ? $author_avatar : $config->site->default_avatar ); ?>&amp;m=crop&amp;w=225&amp;h=225" alt="<?php echo $author_name; ?>"></a>
		</span>
		
		<div class="meta-user-data">
	  
	    	<a href="<?php echo $author->getUsername(); ?>"><button class="pure-button pure-button-primary"><span>View Profile</span></button></a>
			<!--<button class="pure-button pure-button-primary pure-button-active check icon" data-style="slide-up"><span>Following</span></button>-->
	    <?php 
	    include 'includes/generate-follow-button.php';
	    echo $following_button; ?>
				
			<dl>
				<dt class="username"><?php echo $author_name; ?></dt>
				<dd class="meta-location"><?php echo $author->getMetaValue('region'); ?></dd>
				<dt>Member since: <?php  $member_since = MK_Utility::timeSince( strtotime($author->renderDateRegistered())); 
	        echo $member_since; ?></dt>
			</dl>
		</div>
		
		<div class="meta-image-details">
			
			
			<?php if( $level = $author->getMetaValue('category') ) { ?><span class="category meta-title">Category<span class="meta"><?php echo $users_types_array_combined[$level]; ?></span></span><?php } ?>
			
			<?php if( $occupation = $author->getMetaValue('occupation') ) { ?><span class="category meta-title">Occupation<span class="meta"><?php echo $occupation; ?></span></span><?php } ?>
			
			<?php if( $ye = $author->getMetaValue('years_of_experience') ) { ?><span class="category meta-title">Experience<span class="meta"><?php echo $ye; ?> years</span></span><?php } ?>
			
			<?php if ($freelancing) { ?>
			<span class="height meta-title">Freelancing<span class="meta"><?php echo $author->isMetaValue('available_for_freelance') ? 'Yes' : 'No'; ?></span></span>
			<?php }?>
			
		</div>
		
		<div class="meta-image-stats">
			<?php 
			if ($tot_images>0) {
			 ?>
			<span data-image-id="<?php echo $tot_images; ?>" class="pure-u meta-hearts stats">
			<i class="pictures icon"></i>
			<span class="attribute">Images</span><span class="text"><?php echo $tot_images; ?></span>
			</span>	
			<?php 
			}
			if ($tot_videos>0) {
			 ?>
			<span data-view-id="<?php echo $tot_videos; ?>" class="pure-u meta-views stats">
			<i class="video icon"></i>
				<span class="attribute">Videos</span><span class="text"><?php echo $tot_videos; ?></span>
			</span>
			<?php 
			}
			if ($tot_followers>0) {
			?>
			<span data-comment-id="<?php echo $tot_followers; ?>" class="pure-u meta-comment stats">
			<i class="users icon"></i>
				<span class="attribute">Followers</span><span class="text"><?php echo $tot_followers; ?></span>
			</span>	
			<?php 
			}
			if ($rec_fav>0) {
			 ?>
			<span data-image-id="<?php echo $rec_fav; ?>" class="pure-u meta-hearts stats">
			<i class="heart icon"></i>
			<span class="attribute">Fan Favourites</span><span class="text"><?php echo $rec_fav; ?></span>
			</span>
			<?php 
			}
			if ($rec_view>0) {
			 ?>
			<span data-view-id="<?php echo $rec_view; ?>" class="pure-u meta-views stats">
			<i class="eye icon"></i>
				<span class="attribute">Fan Views</span><span class="text"><?php echo $rec_view; ?></span>
			</span>
			<?php 
			}
			if (($rec_com>0) && ($config->extensions->gallery->image_comments)) {
			 ?>
			<span data-comment-id="<?php echo $rec_com; ?>" class="pure-u meta-comment stats">
			<i class="comment icon"></i>
			<span class="attribute">Fan Comments</span><span class="text"><?php echo $rec_com; ?></span>
			</span>	
			<?php 
			}
			 ?>
		</div>
		
	</div>
</aside>
