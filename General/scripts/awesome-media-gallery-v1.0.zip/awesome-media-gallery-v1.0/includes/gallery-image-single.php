<?php 

//Set Page Variables
$author           = $image->objectUser();
$author_id        = $author->getId();
$author_name      = $author->getDisplayName();
$author_avatar    = $author->getAvatar();
$gallery_id       = $gallery_id; //Retrieved in BreadCrumbs
$gallery_name     = $image->objectGallery()->getName();
$image_title      = $image->getTitle();
$image_type		  = $image->getMetaValue('type_gallery');
$video_url		  = $image->getMetaValue('video_url');
$image_type_name  = getImageTypeName($image_type);
$total_favourites = $image->getTotalFavourites(); //Get total favorties count
$build_href_prev  = ''; //Set prev button
$build_href_next  = ''; //Set next button

if ( !empty( $previous_image ) ) {
  $build_href_prev = $this_filename . '?image=' . $previous_image->getId();
  $build_href_prev .= ( !empty( $author ) ? '&amp;user='.$author->getId() : '' );
}

if ( !empty( $next_image ) ) {
  $build_href_next = $this_filename .'?image='. $next_image->getId();
  $build_href_next .= ( !empty( $author ) ? '&amp;user=' . $author->getId() : '' );
}

/***** Setup TAGS for Single Image *****/
if( $tags = $image->getTags() )	{
	$tags = explode(',', $tags);
}


//BUILD LINK BASED ON VIDEO VS. IMAGE
if ( $image_type == 2 ) { //VIDEO

    $img_string = $image->getImage();
    $popup_string = $video_url;

} elseif ( $image_type == 1 ){

    $img_string = 'library/thumb.php?f='.$image->getImage().'&amp;m=contain&amp;a=true&amp;w=' . $mwsi . '&amp;h=' . $mhsi;
    $popup_string = $config->site->url . $image->getImage();
    
}

/********************* IMAGE COMMENTING *********************/

//If commenting is turned on, setup the arroy.
if( !empty($config->site->enable_comments) && $config->site->enable_comments ) {
  
  $page = MK_Request::getQuery('comments-page', 1);
  
  $paginator = new MK_Paginator($page, 20);

  // Comment form
  $settings = array(
    'attributes' => array(
      'class' => 'clear-fix standard comment',
      'action' => $this_filename.'?image='.$image->getId().'#leave-comment'
    )
  );

  $fields = array(
    'comment' => array(
      'label' => 'Comment',
      'type' => 'textarea',
      'validation' => array(
        'instance' => array(),
        'length_max' => array(1000)
      ),
      'attributes' => array(
        'placeholder' => 'Write a comment...'
      )
    ),
    'user' => array(
      'attributes' => array(
        'type' => 'hidden',
      ),
      'value' => $user->getId()
    ),
    'image' => array(
      'attributes' => array(
        'type' => 'hidden',
      ),
      'value' => $image->getId()
    ),
    'post-comment' => array(
      'type' => 'submit',
      'attributes' => array(
        'value' => 'Post Comment'
      )
    )
  );

  $form = new MK_Form($fields, $settings);
}

//Setup the editing classes
if( ($user->isAuthorized() && ($user->getId() == $author->getId())) || ($user->objectGroup()->isAdmin()) ) {
		
    $edit_class          ="edit";
    $edit_type_text      ="edit-text";
    $edit_type_link      ="edit-link";
    $edit_type_textarea  ="edit-textarea";
    $edit_type_date      ="edit-date";
    $edit_type_yesno     ="edit-yesno";	
    $edit_type_tags      ="edit-tags";
    $edit_type_galleries ="edit-gallery";	
    $admin_mode          = 1;
    
} else {

    $edit_class          = "";
    $edit_type_text      = "";
    $edit_type_link      = "";
    $edit_type_textarea  = "";
    $edit_type_date      = "";
    $edit_type_yesno     = "";
    $edit_type_tags      = "";
    $edit_type_galleries = "";
    $admin_mode          = 0;
    
}

?>
<!-- Content Section GALLERY Starts Here -->
<section class="content gallery-single comments pure-u-19-24">                 

    <div class="single-image">
    
        <!-- Single Image Starts --><?php 
        
        if ( $image_type == 1 ) { //Type is image. ?>

            <div class="image-container image-large loading" role="main-gallery">
                
                <!-- Container Starts --><?php 
        
                //Extension check.
                $extension = explode('.', $image->getImage());
                $extension = array_pop($extension); ?>
                
                <a href="<?php echo $popup_string; ?>" class="fancybox-media" rel="group"><img data-src="<?php echo $img_string; ?>" alt="<?php echo $image->getTitle(); ?>" src=""></a><?php 
        
        } elseif ( $image_type == 2 ) { //Type is video ?>
        
            <div class="image-container image-large">
            
                <!-- Container Starts --><?php
                
                if (!empty($config->site->enable_autoplay)) {
	                $ap=$config->site->enable_autoplay;
                }else{
	                $ap=0;
                }
                
                if ( isYouTube ( $popup_string ) ) { //Its YouTube
                
                    $embed_string = convertYouTubeUrl( $popup_string ); //Convert url in to embed version ?>
            
                    <iframe id="ytplayer" type="text/html" src="<?php echo $embed_string . '?autoplay=' . $ap; ?>&amp;origin=<?php echo $config->site->url; ?>&amp;wmode=transparent&amp;theme=light" frameborder="0" /></iframe><?php
                
                } elseif ( isVimeo ( $popup_string ) ) { //Its Vimeo

                    $embed_string = convertVimeoUrl($popup_string); //Convert url in to embed version ?>

                    <iframe src="<?php echo $embed_string . '?autoplay=' . $ap; ?>" width="755" height="425" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe><?php

                } elseif ( isVine ( $popup_string ) ) { //Its Vine

                    $embed_string = convertVine($popup_string); //Convert url in to embed version ?>

                    <iframe src="<?php echo $embed_string; ?>" width="756" height="756" frameborder="0" scrolling="no" seamless="seamless" webkitallowfullscreen="webkitAllowFullScreen" mozallowfullscreen="mozallowfullscreen" allowfullscreen="allowfullscreen"></iframe><?php

                }
                
        } ?>
            
        <div class="meta-holder">
        
            <div class="meta-data holder">
                <!-- Meta Data --><?php 
                
                echo returnFavouriteHeart();
                
                if ($config->site->enable_comments) { //If Image comments are turned on. $config->extensions->gallery->image_comments ?>
                
                    <span class="pure-u meta-comment stats">
                        <i class="comment icon"></i>
                        <span class="text"><?php echo ( $image->getTotalComments() > 999 ? '999+' : $image->getTotalComments() ); ?></span>
                    </span><?php 
                
                } ?>
                
                <!-- View Count -->
                <span class="pure-u meta-views stats">
                    <i class="eye icon"></i>
                    <span class="text"><?php echo number_format($image->getViews()); ?></span>
                </span>
                              
                <!-- Posted X Ago -->
                <span class="meta-date pure-u">
                    <i class="clock icon"></i><?php echo time_since(time() - strtotime($image->getDateAdded())); ?> ago
                </span>
            
            </div>
        
        </div>

    </div><!-- Container Ends --><?php 
    
	//Check for more images to be used in the carousel and button.
	$more_images_paginator = new MK_Paginator(1, 50);
	$more_images_options = NULL;

	$more_images = $image_module->searchRecords(array(
        array('field' => 'user', 'value' => $image->getUser())
        ), $more_images_paginator, $more_images_options); ?>   
    
    <!-- Buttons Start -->
    <div class="meta-data buttons"><?php
	    	
        //View all button
        if( !empty( $more_images ) && ( ( count( $more_images ) ) > 1 ) ) { //There are more images! ?>
		
            <button id="fancybox-view-button" class="pure-button pure-button-primary">View All</button><?php
        
        }
	    	
	    //Delete Image Button
	    if( $image->canDelete( $user ) ) { //User can edit so show them a button. ?> 
        
            <a rel="image delete-image" href="<?php echo $this_filename . '?image=' . $image->getId(); ?>&amp;action=delete-image"><button class="pure-button pure-button-primary delete-button">Delete</button></a><?php
            
		} 
      
        //Full Image Button
        if($user->isAuthorized() ) { //If logged in then show download full image. 
      
            if ( $image_type == 1 ) { //Image. ?>
                <a title="View original source file" target="_blank" href="<?php print $image->getImage(); ?>"><button class="pure-button pure-button-primary viewfull-button">View Full Size</button></a><?php
        
            } elseif ( $image_type == 2 ) { //Video. ?>
  
                <a title="View original source file" target="_blank" href="<?php print $popup_string; ?>"><button class="pure-button pure-button-primary viewfull-button">View Original</button></a><?php
            
            }
      
        } 

	    //Report Image Button
	    if( $user->isAuthorized() && $user->getId() != $image->getUser() && $config->site->enable_reporting ) { ?>

            <a rel="image report-image" title="Report this image as inappropriate content" data-image-id="<?php echo $image->getId(); ?>"><button class="pure-button pure-button-primary report-button">Report</button></a><?php
		
        }
	    
	    //Featured Image Button + Logged in as Admin
        if( $user->objectGroup()->isAdmin() && $user->isAuthorized() ) {
	    
            if( $image->isFeatured() ) { 
	        
                $f_Query = 'remove-featured';
                $f_Class = 'pure-button-active';
                $f_Text = 'Featured';
	        
            } else {  
	        
                $f_Query = 'add-featured';
                $f_Class = '';
                $f_Text = 'Feature';
            
            } ?>

            <a data-image-id="<?php echo $image->getId(); ?>" href="<?php echo $this_filename . '?image=' . $image->getId() ?>&amp;action=<?php echo $f_Query; ?>"><button class="pure-button <?php echo $f_Class; ?> pure-button-primary feature-button" id="<?php if( $image->isFeatured() ) { ?>featured_button<?php } ?>"><span><?php echo $f_Text; ?></span></button></a><?php
        
	    }
        
        if ( $build_href_prev <> '' ) { 
            
            echo '<a href="' . $build_href_prev . '"><button class="pure-button pure-button-primary">Prev</button></a>';
            
        }
        
        if( $build_href_next <> '' ) {

            echo '<a href="' . $build_href_next . '"><button class="pure-button pure-button-primary">Next</button></a>';
            
        } ?> 

    </div><!-- Meta Data Ends -->
    
  </div><!-- Single Image Ends -->    <?php 

    if ($deviceType <> 'phone') {

        if( !empty($more_images) && ((count($more_images)) > 1) ) { //There are more images! ?>
        
            <!-- Carousel Starts -->
            <div class="related-images">
            
                <ul id="carousel" class="elastislide-list"><?php
              
                $counter = 0;
                $image_list = '';
                $double_flag = false;
                
                foreach( $more_images as $more_images_single ) {

                    $more_image_type = $more_images_single->getMetaValue('type_gallery');
                    $video_url       = $more_images_single->getMetaValue('video_url');
                    $extra_class     = '';
                    $youtube_class   = '';
                    $image_type_name = getImageTypeName($more_image_type);
                    
                    if ($image_type_name=='video') {
                        
                        $tn_src = ( 'library/thumb.php?f='.$more_images_single->getImage().'&amp;m=crop&amp;w=' . $wci . '&amp;h=' . $hci );
                        
                        $popup_str = $video_url;
                                    
                        if ( isYouTube( $popup_str ) ) {
            
                            $youtube_class = 'youtube';
                            
                            $tn_src = 'library/thumb.php?f='.$more_images_single->getImage().'&amp;m=crop-hd&amp;y=-25&amp;w=' . ($wci * 2) . '&amp;h=' . ( $hci * 2 );
                            
                        }
                        
                    } elseif ( $image_type_name == 'image' ) {
                        
                        $tn_src = 'library/thumb.php?f='.$more_images_single->getImage().'&amp;m=crop&amp;w=' . $wci . '&amp;h=' . $hci;
                        
                        echo $tn_src;
                        
                        $popup_str = $more_images_single->getImage();
                        
                    }
                
                    $counter++;
                    $title     = MK_Utility::escapeText($more_images_single->getTitle());		
                    $extension = explode('.', $more_images_single->getImage());
                    $extension = array_pop($extension); 
                  
                    if( $more_images_single->getId() == $image_id ) {
                        $extra_class = "current-image";
                    } else { //No match.
                        $extra_class = "";
                    }
                  
                    //build image list for fancybox
                    if ( $double_flag == true ) {
                        $image_list .= '<a href="' . $popup_str . '" rel="group" class="fancybox-media" style="display:none;visibility:hidden;"></a>';
                    }
                  
                    $double_flag = true; ?>
                  
                    <li class="<?php echo $youtube_class; ?>">
                        <a title="<?php echo $title; ?>" href="<?php echo $image_type_name . '/' .$more_images_single->getImageSlug(); ?>"><i class="<?php if ( $more_image_type == 2 ) { echo 'video'; } else { echo ($extension == 'gif') ? 'bolt' : 'camera'; } ?> icon rollover-icon"></i><img src="<?php echo $tn_src; ?>" class="<?php echo $extra_class; ?>" alt="<?php echo $title; ?>"></a>
                    </li><?php 
                  
                } //End for each ?>
                
                </ul>
            
                <!-- Image list for fancybox --> <?php         
                
                echo $image_list; //echo all images for fancybox ?>
            
            </div>
            <!-- Carousel Starts --><?php 
        } //if empty 

    } //End device check. ?>
    
    <br clear="all">
    
    <!-- Meta Data Starts -->
    <div class="image-meta pure-g-r">
        
        <div class="pure-u-1">
        
            <div class="pure-g-r">
        
                <!-- IMAGE TITLE -->
                <div class="pure-u-1-2 float-left">
        	
                    <div class="content-wrapper">
                
                        <h2 class="meta-name heading pure-u <?php echo $edit_class; ?> <?php echo $edit_type_text; ?>" data-module-name="image" data-id="<?php echo $image_id; ?>" data-field-name="title" data-field-text="<?php echo str_replace('"',"'",$image_title); ?>"><?php echo $image_title; ?></h2>
                    
                        <!-- Image Gallery Link -->
                        <span class="meta-category pure-u-1">
                            
                            <span class="<?php //echo $edit_class; ?> <?php echo $edit_type_galleries; ?>" data-module-name="image" data-id="<?php echo $image_id; ?>" data-field-name="gallery"><i class="pictures icon"></i><a href="./gallery/<?php echo $gallery_id; ?>" title=" <?php echo $gallery_name; ?>"><?php echo $gallery_name; ?></a></span>
                            
                            <span><i class="user icon"></i><a href="<?php echo getProfileUrl($author_id); ?>"><?php echo $author_name; ?></a></span>
                        
                        </span>
		
                        <!-- DESCRIPTION --><?php
                        $description = str_replace('"',"'",$image->getDescription());
                        
                        if ($description == '') { 
                            $description_text = $txt_placeholder_arr['description'];}
                        else {
                            $description_text = $description;
                        } ?>
		          
                        <p class="meta-content <?php echo $edit_class; ?> <?php echo $edit_type_textarea; ?>" data-module-name="image" data-id="<?php echo $image_id; ?>" data-field-name="description" data-field-text="<?php echo $description; ?>"><?php echo makeClickableLinks(str_replace('{{link}}', 'http://',stripslashes($description_text))); ?></p>
        
                    </div>
                    
                </div>
        
                <div class="pure-u-1-2 meta-description tag social float-right">
	    
                    <div class="meta-description">
                        
                        <!-- Social Share --><?php 
                
                        if ($deviceType <> 'phone') { ?>
                        
                            <div class="social-share">
                
                                <h4 class="heading"><i class="share icon"></i>Share</h4>
					
                                <div class="social-buttons">

                                    <!-- Social Buttons Go Here -->
                                    <?php 
                                    $social_url_encoded = urlencode($config->site->url . getImageTypeName($image_type) . '/' . $image->getImageSlug());
                                    $social_url = $config->site->url . getImageTypeName($image_type) . '/' . $image->getImageSlug();

                                    ?>
                                    <ul class="socialcount socialcount-large" data-url="<?php echo $social_url; ?>" data-share-text="<?php echo getShortUrl($social_url, $config->site->bitly->login_id, $config->site->bitly->app_key, $config->site->bitly->enabled) . ' - ' . $image_title . ' - ' . truncate($description_text, 100); ?>" data-media="<?php echo $social_url_encoded; ?>" data-description="<?php echo truncate($description,100);?>">
							
                                        <li class="facebook"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $social_url_encoded; ?>" title="Share on Facebook"><span class="socicon socicon-facebook"></span><span class="count">Like</span></a></li>
                                        <li class="twitter"><a href="https://twitter.com/intent/tweet?text=<?php echo $social_url_encoded; ?>" title="Share on Twitter"><span class="socicon socicon-twitter"></span><span class="count">Tweet</span></a></li>
                                        <li class="googleplus"><a href="https://plus.google.com/share?url=<?php echo $social_url_encoded; ?>" title="Share on Google Plus"><span class="socicon socicon-google"></span><span class="count">+1</span></a></li>
                                        <li class="pinterest"><a title="Pin It"><span class="socicon socicon-pinterest"></span><span class="count">Pin It</span></a></li>
                                    </ul>
					
                                </div>
				
                            </div><?php 
                            
                        } //END IF NOT PHONE ?>
				
                        <div class="meta-tag"><?php
	            
                        if ( $tags ) { ?>
                            <!-- TAGS -->
                            <h4 class="heading"><i class="tag icon"></i>Tags</h4><?php
        
                            foreach( $tags as $tag ) {
                                
                                $tag = trim( $tag );
                                echo '<a href="./tag/' . urlencode( $tag ) . '"><button class="tm-tag">' . $tag .'</button></a>';
                           
                            } 
                    
                        } else { ?>
                        
                            <div class="meta-tag pure-u-1 <?php echo $edit_class; ?> <?php echo $edit_type_tags; ?>" data-module-name="image" data-id="<?php echo $image_id; ?>" data-field-name="tags"></div><?php
                    
                        } ?>
                
                        </div>
	        
                    </div>
	    
                </div>
	    
                <div class="clearfix"></div>
      
            </div>
    
        </div>
      
    </div>
    <!-- Meta Data Ends -->
  
<?php if (($deviceType <> 'phone') &&  ($deviceType <> 'tablet')) { ?>

  <!-- COMMENTS -->
  <div id ="comment-anchor" class="comment-holder"><?php

    if( !empty($config->site->enable_comments) && $config->site->enable_comments ) {  //IF THERE ARE COMMENTS
	
		if( $form->isSuccessful() ) { //IF A NEW COMMENT HAS BEEN SUBMITTED
			
      $new_comment = MK_RecordManager::getNewRecord($image_comment_module->getId());
			$new_comment
				->setUser($user->getId())
				->setImage($image->getId())
				->setComment($form->getField('comment')->getValue())
				->save();
			
      //ADD ACTIVITY NOTE FOR COMMENTING USER
      $user->addNotification( '<a href="member.php?user='.$user->getId().'">'.$user->getDisplayName().'</a> commented on the image <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$new_comment->getId().'">'.$image->getTitle().'</a>' );

      //ADD ACTIVITY NOTE FOR AUTHOR OF IMAGE
      $image->objectUser()->addNotification('<a href="members.php?user='.$user->getId().'">'.$user->getDisplayName().'</a> commented on your image <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$new_comment->getId().'">'.$image->getTitle().'</a>', false, $user);
			
		} //END FORM SUBMITTED

		$comments_paginator = new MK_Paginator(1, 20);
	
		$image_comments = $image_comment_module->searchRecords(array(
			array('field' => 'image', 'value' => $image_id),
			array('field' => 'reply_to', 'value' => 0)
		), $comments_paginator);
?>

    <div class="comment-feed">
		<div class="comment-head">
			<h4 class="heading"><i class="chat icon"></i>Comments</h4>


			<div class="comment-count">
				<span class="total-comments"><?php echo ( $image->getTotalComments() > 999 ? '999+' : $image->getTotalComments() ); ?> Comments</span>
				
				<?php

				if (!$user->isAuthorized()) {
				?>
				<span class="spacing">|</span>
				<span class="en-trigger" data-modal="modal-sign-in" data-style="slide-up">Leave a Comment</span>
				<?php } ?>
			
			</div>

		</div>

    </div>
    
    <div class="comment-box"><!-- EMPTY? --></div><?php
		
    if(count($image_comments) > 0) { ?>
    
      <ul class="cbp_tmtimeline" data-autoload="true"><?php
    
        foreach($image_comments as $image_comment) { $in_replies=0;
				
          /********** SEARCH FOR REPLIES **********/
					$image_comment_replies = $image_comment_module->searchRecords(array(
            array(
              'field' => 'reply_to', 
              'value' =>$image_comment->getId()
              )
            )
          );

          /********** HAS REPLIES **********/
					if( !empty($image_comment_replies)) { $has_replies=true; } else { $has_replies=false; }
	
					$author_comment = $image_comment->objectUser();
					
					$image_comment_likes_count = $image_comment_like_module->getTotalRecords(array(
						array(
              'field' => 'comment', 
              'value' => $image_comment->getId()
            ),
					)); ?>

            <li <?php echo ($has_replies)?'class="has-replies"':'class="has-replies"'; ?> id="comment-<?php echo $image_comment->getId(); ?>">
            
            <div class="cbp_tmicon">
              <a href="member.php?user=<?php echo $author_comment->getId(); ?>"><img src="library/thumb.php?f=<?php echo ( $author_comment->getAvatar() ? $author_comment->getAvatar() : $config->site->default_avatar ); ?>&amp;m=crop&amp;<?php echo 'w=' . $wca . '&amp;h=' . $hca; ?>" alt="<?php echo $author_comment->getTitle(); ?>"></a>
            </div>

            <!-- DISPLAY A COMMENT  -->
            <div class="cbp_tmlabel">
              <span class="user"><a class="username-wrap" href="member.php?user=<?php echo $author_comment->getId(); ?>"><?php echo $author_comment->getDisplayName(); ?></a><time class="cbp_tmtime" datetime="<?php echo $image_comment->getDateAdded(); ?>"><span><?php echo time_since(time() - strtotime($image_comment->getDateAdded())); ?> ago
   
              </span></time>
              
                          
  					<?php  //DELETE + LIKE BUTTONS
					
					//SHOW DELETE BUTTON
					if( $image_comment->canDelete($user) ) { ?>
						<!--<a href="<?php echo $this_filename; ?>?image=<?php echo $image->getId(); ?>&amp;action=delete-comment&amp;comment=<?php echo $image_comment->getId(); ?>"><button><span>Delete</span></button></a>-->
            
            <span rel="comment delete-comment" data-comment-id="<?php echo $image_comment->getId(); ?>" class="delete-comment"><button><span>Delete</span></button></span>
            
            <?php
					}
					
					if( $user->isAuthorized() ) {
					
						$logged_in = 1;
						$extra_class = '';
						$extra_attr = '';
					}
					else {
					
						$logged_in = 0;
						$extra_class = 'en-trigger';
						$extra_attr = 'data-modal="modal-sign-in" data-style="slide-up"';
					
					}
					
					$image_comment_likes = $image_comment_like_module->searchRecords(array(
						array('field' => 'comment', 'value' => $image_comment->getId()),
						array('field' => 'user', 'value' => $user->getId()),
					));
					
					
              		if( $image_comment_likes = array_pop($image_comment_likes) ) { //User has already liked ?>
							 <span rel="image-comment <?php echo ($logged_in)? 'remove-like':''; ?>" data-image-comment-like-id="<?php echo $image_comment_likes->getId(); ?>" data-user-id="<?php echo $user->getId(); ?>" data-image-id="<?php echo $image->getId(); ?>" data-image-comment-likes-total="<?php echo $image_comment_likes_count; ?>" class="pure-u meta-hearts stats remove-like"><i class="heart icon"></i><span class="text"><?php echo number_format($image_comment_likes_count); ?></span></span>
					
					<?php 
							} else { ?>
					
							<span rel="image-comment <?php echo ($logged_in)? 'add-like':''; ?>" data-image-comment-id="<?php echo $image_comment->getId(); ?>" data-image-comment-like-id="" data-user-id="<?php echo $user->getId(); ?>" data-image-comment-likes-total="<?php echo $image_comment_likes_count; ?>" class="pure-u meta-hearts stats <?php echo $extra_class; ?>" <?php echo $extra_attr; ?>><i class="heart icon"></i><span class="text"><?php echo number_format($image_comment_likes_count); ?></span></span>
					
					<?php
							}
					?>
          <!--
							<?php if ($logged_in) { ?><button><span>Reply</span></button> <?php } ?>-->
	
            
              </span>
              <span><?php echo makeClickableLinks(str_replace('{{link}}', 'http://',nl2br(MK_Utility::escapeText($image_comment->getComment())))); ?></span>
            </div>

            <!-- CREATE COMMENT FORM AREA --><?php
        
            if( $user->isAuthorized() ) {
            
              $form_prefix = 'reply_'.$image_comment->getId();
          
              $comment_settings = array(
                'attributes' => array(
                  'class' => 'clear-fix standard',
                  'id' => $form_prefix,
                  'rel' => 'comment reply',
                  'action' => $this_filename.'?image='.$image->getId().'#reply_'.$image_comment->getId()
                )
              );
        
              $comment_fields = array(
                $form_prefix.'_comment' => array(
                  'label' => 'Comment',
                  'type' => 'textarea',
                  'validation' => array(
                    'instance' => array(),
                    'length_max' => array(500)
                  ),
                  'attributes' => array(
                    'placeholder' => 'Reply to this comment...'
                  )
                ),
                $form_prefix.'_user' => array(
                  'attributes' => array(
                    'type' => 'hidden',
                  ),
                  'value' => $user->getId()
                ),
                $form_prefix.'_image' => array(
                  'attributes' => array(
                    'type' => 'hidden',
                  ),
                  'value' => $image->getId()
                ),
                $form_prefix.'_reply_to' => array(
                  'attributes' => array(
                    'type' => 'hidden',
                  ),
                  'value' => $image_comment->getId()
                ),
                $form_prefix.'_post-reply' => array(
                  'type' => 'submit',
                  'attributes' => array(
                    'value' => 'Post Reply'
                  )
                )
              );
        
              $comment_form = new MK_Form($comment_fields, $comment_settings);

              if( $comment_form->isSuccessful() ) { //Comment was valid...
                $comment_reply = MK_RecordManager::getNewRecord( $image_comment_module->getId() );
                $comment_reply
                  ->setUser( $user->getId() )
                  ->setImage( $image->getId() )
                  ->setComment( $comment_form->getField($form_prefix.'_comment')->getValue() )
                  ->setReplyTo( $image_comment->getId() )
                  ->save();
                
                // ADD ACTIVITY FEED FOR USER COMMENTING
                $user->addNotification( '<a href="member.php?user='.$user->getId().'">'.$user->getDisplayName().'</a> replied to a <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$image_comment->getId().'">comment</a> on the image <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$comment_reply->getId().'">'.$image->getTitle().'</a>' );

                // ADD ACTIVITY FEED FOR IMAGE AUTHOR
                $author->addNotification( '<a href="member.php?user='.$user->getId().'">'.$user->getDisplayName().'</a> replied to a <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$image_comment->getId().'">comment</a> on the image <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$comment_reply->getId().'">'.$image->getTitle().'</a>' );
                
                // ADD ACTIVITY FEED FOR COMMENT AUTHOR
                $author_comment->addNotification('<a href="member.php?user='.$user->getId().'">'.$user->getDisplayName().'</a> replied to your <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$image_comment->getId().'">comment</a> on the image <a href="'.$this_filename.'?image='.$image->getId().'#comment-'.$comment_reply->getId().'">'.$image->getTitle().'</a>', false, $user);
              }
            } //END IF AUTHORISED USER AND COMMENT SUBMITTED
        
            //SEARCH FOR ANY REPLIES TO COMMENTS
            $image_comment_replies = $image_comment_module->searchRecords(array(
              array('field' => 'reply_to', 'value' => $image_comment->getId())
            ));
        
        // HAS REPLIES 
        if( !empty($image_comment_replies) || $user->isAuthorized() ) {?>

          <ul data-autoload="true" class="replies<?php echo ( count($image_comment_replies) > 3 ? ' replies-hidden' : '' ); ?>"><?php
        
            //LOOP THRU REPLIES
            foreach($image_comment_replies as $image_comment_reply) {	$in_replies=1;
              $image_comment_reply_likes_count = $image_comment_like_module->getTotalRecords(array(
                array('field' => 'comment', 'value' => $image_comment_reply->getId()),
              ));

              $author_reply = $image_comment_reply->objectUser(); ?>
          
              <li id="comment-<?php echo $image_comment_reply->getId(); ?>">
            
                <div class="cbp_tmicon">
                  <a href="member.php?user=<?php echo $author_reply->getId(); ?>"><img src="library/thumb.php?f=<?php echo ( $author_reply->getAvatar() ? $author_reply->getAvatar() : $config->site->default_avatar ); ?>&amp;m=crop&amp;<?php echo 'w=' . $wca . '&amp;h=' . $hca; ?>" alt="<?php echo $author_reply->getTitle(); ?>"></a>
                </div>
                                
              <div class="reply">
              
              
                <!-- HAS REPLY COMMENT AREA -->
                <div class="cbp_tmlabel">
                  <span class="user"><a class="username-wrap" href="member.php?user=<?php echo $author_reply->getId(); ?>"><?php echo $author_reply->getDisplayName(); ?></a><a href="<?php echo $this_filename; ?>?image=<?php echo $image->getId(); ?>#comment-<?php echo $image_comment_reply->getId(); ?>"><time class="cbp_tmtime" datetime="<?php echo $image_comment_reply->getDateAdded(); ?>"><span><?php echo time_since(time() - strtotime($image_comment_reply->getDateAdded())); ?> ago</span></time></a>
                  
                  
					<?php  //DELETE + LIKE BUTTONS
					
					//SHOW DELETE BUTTON
					if( $image_comment_reply->canDelete($user) ) { ?>
						<!--<a href="<?php echo $this_filename; ?>?image=<?php echo $image->getId(); ?>&amp;action=delete-comment&amp;comment=<?php echo $image_comment_reply->getId(); ?>"><button><span>Delete</span></button></a>-->
            
            
            <span rel="comment delete-comment" data-comment-id="<?php echo $image_comment_reply->getId(); ?>" class="delete-comment"><button><span>Delete</span></button>
            <?php
					}
					
					if( $user->isAuthorized() ) {
					
						$logged_in = 1;
						$extra_class = '';
						$extra_attr = '';
					}
					else {
					
						$logged_in = 0;
						$extra_class = 'en-trigger';
						$extra_attr = 'data-modal="modal-sign-in" data-style="slide-up"';
					
					}
					
						$image_comment_reply_likes = $image_comment_like_module->searchRecords(array(
						array('field' => 'comment', 'value' => $image_comment_reply->getId()),
						array('field' => 'user', 'value' => $user->getId()),
						));
					
					
						if( $image_comment_reply_likes = array_pop($image_comment_reply_likes) ) { //User Likes Comment ?>
							 <span rel="image-comment <?php echo ($logged_in)? 'remove-like':''; ?>" data-image-comment-like-id="<?php echo $image_comment_reply_likes->getId(); ?>" data-user-id="<?php echo $user->getId(); ?>" data-image-id="<?php echo $image->getId(); ?>" data-image-comment-likes-total="<?php echo $image_comment_reply_likes_count; ?>" class="pure-u meta-hearts stats remove-like"><i class="heart icon"></i><span class="text"><?php echo number_format($image_comment_reply_likes_count); ?></span></span>
					
					<?php 
							} else { ?>
					
							<span rel="image-comment <?php echo ($logged_in)? 'add-like':''; ?>" data-image-comment-id="<?php echo $image_comment_reply->getId(); ?>" data-user-id="<?php echo $user->getId(); ?>" data-image-comment-likes-total="<?php echo $image_comment_reply_likes_count; ?>" class="pure-u meta-hearts stats <?php echo $extra_class; ?>" <?php echo $extra_attr; ?>><i class="heart icon"></i><span class="text"><?php echo number_format($image_comment_reply_likes_count); ?></span></span>
					
					<?php
							}
					?>
                    </span>
                  
                  </span>
                  
                  <span><?php echo makeClickableLinks(str_replace('{{link}}', 'http://',nl2br(MK_Utility::escapeText($image_comment_reply->getComment())))); ?></span>
                </div>
              </li><?php
            } //FINISH REPLIES LOOP ?>

            <!-- VIEW ALL JAVASCRIPT BUTTON GOES HERE IF NEEDED UNHIDE EXTRA REPLIES --><?php
            //DISPLAY COMMENT FORM UNDER REPLIES IF NECESSARY
        
            if( $user->isAuthorized() ) { 
	            
	           // if ($in_replies==0) { echo '<ul class="replies">';}
            ?>
        
        
              <li class="clear-fix form"><?php
                
                if( $comment_form->isSuccessful() ) {	?>  
                  <p id="<?php echo $form_prefix; ?>" class="alert alert-success">Thank you for submitting your reply!</p><?php
                } else { //echo $in_replies;?>
                  
                  
                  <div class="cbp_tmicon">
                  <a href="member.php?user=<?php echo $user->getId(); ?>"><img src="library/thumb.php?f=<?php echo ( $user->getAvatar() ? $user->getAvatar() : $config->site->default_avatar ); ?>&amp;m=crop&amp;<?php echo 'w=' . $wca . '&amp;h=' . $hca; ?>"></a>
                  </div>
                  <div class="reply">
                  <div class="cbp_tmlabel"><?php echo $comment_form->render(); ?></div>
                  </div>

                  
                  <?php
                } //END IF COMMENT FORM SUBMITTED ?>
            
              </li><?php
              
	        //if ($in_replies==0) { echo '</ul>';}

            } //END IF USER IS AUTHORIZED ?>
          </ul><?php
    } //END IF HAS REPLIES AND AUTHORIZED ?>
    </li>
    
    <!-- ADD REPLIES BOX AT THE END -->
    
    <?php
 	} //END COMMENTS 
 	?>
	</ul>
	
	<div class="clear-fix paginator"><?php echo $paginator->render($this_filename."?comments-page={page}&image=" . $image_id . "#comments"); ?></div><?php
  
} else { ?>
	<!--<p class="alert alert-information">There are no comments, why not be the first to write one?</p>--><?php
} ?>	
	
<!--<h4 id="leave-comment">Leave a Comment</h4>--><?php

if($user->isAuthorized()) {
  if($form->isSuccessful()) { ?>
    <p class="alert alert-success">Thank you for submitting your comment!</p><?php
	} else { ?>
    <ul class="cbp_tmtimeline" data-autoload="true">
      <li id="main-reply-box">
        <div class="cbp_tmicon">
          <a href="member.php?user=<?php echo $user->getId(); ?>"><img src="library/thumb.php?f=<?php echo ( $user->getAvatar() ? $user->getAvatar() : $config->site->default_avatar ); ?>&amp;m=crop&amp;<?php echo 'w=' . $wca . '&amp;h=' . $hca; ?>"></a>
        </div>
        <div class="cbp_tmlabel"><?php echo $form->render(); ?></div>              
      </li>
    </ul><?php
	}
} else { ?>
	<p class="alert alert-information"><a href="#" class="en-trigger" data-modal="modal-sign-in" data-style="slide-up"><i class="chat icon"></i><span>Sign in to comment!</span></a></p><?php
}


}
?>

</div> <!-- COMMENT HOLDER -->

<?php } ?>
</section>
	

<?php if (($deviceType <> 'phone') &&  ($deviceType <> 'tablet')) { ?>

<!-- Sidebar Starts Here -->
<?php include ('gallery-image-sidebar.php'); ?>
<!-- Sidebar Starts Here -->

<?php } ?>