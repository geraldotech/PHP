<?php
//List Item Single Image Box
//This is an include file.
//image-box.php

$total_favourites = $image->getTotalFavourites(); //Total favs for this item.
$total_comments   = $image->getTotalComments(); //Total comment for this item.
$total_views      = $image->getViews(); //Total views for this item.
$gallery_name     = $image->getGallery() ? $image->objectGallery()->getName() : ''; //Gallery name the item belongs to.
$gallery_id       = $image->getGallery() ? $image->objectGallery()->getId() : ''; //Id of the gallery the item belongs to.
$image_type		  = $image->getMetaValue('type_gallery'); //Type of gallery the item belongs to.
$title            = MK_Utility::escapeText($image->getTitle()); //Title of the item.
$extension        = explode('.', $image->getImage()); //File extension check.
$extension        = array_pop($extension); //Pop extension.
$author           = $image->objectUser(); //Author of the item.
$extra_class      = ''; //Set extra class to empty for starters.

//Build links based on item type.
if ( $image_type == 2 ) { //VIDEO
	
    $src_string = 'library/thumb.php?f='.$image->getImage().'&amp;m=crop&amp;w=' . $wib . '&amp;h=' . $hib;
    $icon_class = 'video icon';
    $popup_url	= $image->getMetaValue('video_url');

    if ( isYouTube( $popup_url ) ) {
        $extra_class = 'youtube';
        $src_string = 'library/thumb.php?f='.$image->getImage().'&amp;m=crop-hd&amp;w=' . $wib . '&amp;h=' . ( $hib - 90 );
    }
    
    if ( isVimeo( $popup_url ) ) {
        $extra_class = 'vimeo';
        $src_string = 'library/thumb.php?f='.$image->getImage().'&amp;m=crop-hd&amp;w=' . '640' . '&amp;h=' . ( $hib - 90 );
    }
    
} elseif  ($image_type == 1 ) {

    $src_string = 'library/thumb.php?f='.$image->getImage().'&amp;m=crop&amp;w=' . $wib . '&amp;h=' . $hib;
    $icon_class = 'pictures icon';
    $popup_url  = $image->getImage();

} ?>		

<li class="pure-u-1-4">
  
    <figure>
      
        <a href="<?php if ( $image_type == 2 ) { echo 'video'; } else { echo 'image'; } echo '/' .$image->getImageSlug(); ?>" title="<?php echo $title; ?>">
        
            <span class="image loading <?php echo ( isset($extra_class) ? $extra_class : '' ); ?>"><?php 
             
                if ( $image_type == 2 ) { //If video use a different icon. ?>
             
                    <i class="video icon rollover-icon"></i><?php 

                } elseif ( $image_type == 1 )  {
             
                    if ($extension == 'gif') { //If GIF use a different icon. ?>
             
                        <i class="bolt icon rollover-icon"></i><?php
                    
                    } else { //Probably a jpg use the camera icon ?>
             
                        <i class="camera icon rollover-icon"></i><?php
                 
                    }
                } ?>
              
                <img class="meta-image<?php echo ( isset($extra_class) ? ' ' . $extra_class : '' ); ?>" src="data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs%3D" data-src="<?php echo $src_string; ?>" alt="<?php echo $title; ?>">
             
            </span>
            
        </a>

        <figcaption>
        
            <div class="pure-g">
                
                <!-- Author Avatar -->
                <div class="pure-u-1-12">
                
                    <span class="meta-avatar"><a href="<?php echo getProfileUrl( $author->getId() ); ?>"><img src="library/thumb.php?f=<?php echo ($author->getAvatar() ? $author->getAvatar() : $config->site->default_avatar ); ?>&amp;h=24&amp;w=24&amp;m=crop" alt="<?php echo $author->getDisplayName(); ?>"></a></span>
                
                </div>
                
                <!-- Author -->
                <div class="pure-u-1-2 name">
                    
                    <span class="meta-name"><a href="<?php echo getProfileUrl( $author->getId() ); ?>"><?php echo $author->getDisplayName(); ?></a></span>
                
                </div>
              
                <!-- Date Time Uploaded -->
                <div class="pure-u-1-12">
                    <span class="meta-date"><?php echo time_since(time() - strtotime($image->getDateAdded())); ?></span>
                </div>
          
            </div>
          
            <!-- Title -->
            <span class="meta-title"><a href="<?php if ( $image_type == 2 ) { echo 'video'; } else { echo 'image'; } echo '/' .$image->getImageSlug(); ?>" title="<?php echo $title; ?>"><?php echo $title; ?></a></span>

            <!-- Gallery Name -->
            <span class="meta-title meta-gallery"><i class="<?php echo $icon_class; ?>"></i><a href="gallery/<?php echo $gallery_id; ?>" title=" <?php echo $gallery_name; ?>"><?php echo $gallery_name; ?></a></span><?php
          
            if( $tags = $image->getTags() ) {

                $tags = explode(',', $tags); ?>
            
                <!-- Tags -->
                <span class="meta-tag">
                    <i class="tag icon"></i><?php
                    
                    foreach( $tags as $tag ) {
                        $tag = trim($tag); ?>
                        <a href="tag/<?php echo urlencode($tag); ?>"><?php echo $tag; ?></a><?php
                    } ?>
                
                </span><?php
              } ?>
          
        </figcaption>
        
        <div class="meta-icons">
          
            <!-- Favortie Heart -->
            <?php echo returnFavouriteHeart(); ?>

<?php 
	if( !empty($config->site->enable_comments) && $config->site->enable_comments ) {
?> 
            <!-- Comments -->
            <span data-comment-id="1" class="meta-comment">
                <a href="<?php if ($image_type==2) { echo 'video'; } else { echo 'image'; } echo '/' .$image->getImageSlug(); ?>#comment-anchor" title="<?php echo $title; ?>"><i class="comment icon"></i></a>
                <span class="text"><?php echo ( $total_comments > 999 ? '999+' : $total_comments ); ?></span>
            </span>
<?php 
	}
?>
          
            <!-- Views -->
            <span data-view-id="1" class="meta-views">
                <a href="<?php echo $popup_url; ?>" rel="group" class="fancybox-media"><i class="eye icon"></i></a>
                <span class="text"><?php echo ( $total_views > 999 ? '999+' : $total_views ); ?></span>
            </span>
          
        </div>
      
    </figure>

</li>