<?php

$num_items = ($deviceType == 'phone')?12:30;

$paginator = new MK_Paginator();

$paginator
  ->setPerPage($num_items)
  ->setPage( MK_Request::getQuery('page', 1) );

$images = $image_module->searchRecords(

	array(  
	array('field' => 'user', 'value' => $profile->getId()),
	array('field' => 'type_gallery', 'value' => 1))

	, $paginator);

if( !empty($images) ) { ?>
  <ul class="awesome-gallery" data-autoload="true"><?php
    $counter = 0;
    foreach( $images as $image ) {
       include 'includes/image-box.php';
    } ?>
  </ul>

  <div class="paginator clear-fix">
    <button class="pure-button pure-button-primary load-more ladda-button" data-style="slide-up">
      <span class="ladda-label"><?php 
        echo $paginator->render('member.php?section='.$section.'&amp;user='.$profile_id.'&amp;page={page}'); ?>
      </span>
    </button>
  </div><?php
} else { ?>
  <p class="alert alert-information"><?php echo $profile_name; ?> hasn't uploaded any images.</p><?php
} ?>
