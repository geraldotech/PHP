<div class="user-profile pure-g-r">
  
	<div class="pure-u-1-8 meta-avatar profile-avatar-wrap loading"><?php 
    
        if ( $admin_mode == 1 ) { ?>
            
            <div class="hover-wrapper">
                <div class="drag-hover"><div class="alert">Drag your image here</div>
            </div><?php 
        
        } ?>
	
        <img src="library/thumb.php?f=<?php echo ( $profile->getAvatar() ? $profile->getAvatar() : $config->site->default_avatar ); ?>&amp;h=250&amp;w=250&amp;m=crop"  src="data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs%3D" alt="<?php echo $profile->getDisplayName(); ?>" <?php if( $admin_mode == 1 ) echo ' id="js-my-avatar"';?>><?php 
  
        if( $admin_mode == 1 ) { ?>
    
            </div>
    
            <form id="fileupload-avatar" action="upload/server/php/" method="POST" enctype="multipart/form-data">
                <input type="file" id="avatar-img" name="files[]" accept="image/*">
                <input type="hidden" name="id" value="<?php echo $profile_id; ?>">
            </form><?php 
        
        } ?>
    
	</div>

	<div class="pure-u-7-8 meta-data">
  
	    <div class="account-meta">
        
			<div class="username-holder">
				
                <span id="profile-username" data-module-name="user" data-id="<?php echo $profile_id; ?>" data-field-name="display_name" data-type="text" class="meta-name <?php echo $edit_class; ?> <?php echo $edit_type_text; ?>" data-field-text="<?php echo $profile_name; ?>"><?php echo $profile_name; ?></span>
				
                <?php echo ( $user->isAuthorized() && $profile->isFollowing( $user ) ? ' <span class="follows-you"><small>Follows you</small></span>' : '' ); ?>
			
            </div>
			
			<div class="region-holder">
				
				<?php
                //Username section.
				$username = $profile->getMetaValue('username'); //Assign username variable from the profile meta.
                
				if( $username <> '' || $admin_mode == 1 ) { //Username is not blank or admin mode
					
                    if ($username == '') { //Username is blank, show placeholder. 
                        
                        $username_text = $txt_placeholder_arr['username'];
                        
                    } else { //Show username.
                    
                        $username_text = $username;
                    
                    } ?>
                
                    <span class="pure-u-1-3 meta-web">
                        <i class="user icon"></i>
                        <span style="float:none;" class=" <?php if ( $user->objectGroup()->isAdmin() && $user->isAuthorized() ) { echo $edit_class . ' ' . $edit_type_text;} ?>" data-module-name="user" data-id="<?php echo $profile_id; ?>" data-field-name="username" data-field-text="<?php echo $username; ?>"><?php echo $username_text; ?></span>
                    </span><?php
                    
				}
                
                //Region Section
				$region = $profile->getMetaValue('region'); //Assign region variable from the profile meta.
                
				if( $region <> '' || $admin_mode == 1  ) { 
					
                    if ($region == '') { 
                        
                        $region_text = $txt_placeholder_arr['region'];
                    
                    } else { 
                        
                        $region_text = $region;
                        
                    } ?>
				
                    <span class="pure-u-1-3 meta-web">
                        <i class="earth icon"></i>
                        <span style="float:none;" class=" <?php echo $edit_class; ?> <?php echo $edit_type_text; ?>" data-module-name="user" data-id="<?php echo $profile_id; ?>" data-field-name="region" data-field-text="<?php echo str_replace('"',"'",$region); ?>"><?php echo $region_text; ?></span>
                    </span><?php
                    
				}
                
                //Website section
				$website = $profile->getMetaValue('website'); //Assign website variable from the profile meta.
				
                if( $website <> '' || $admin_mode ==1 ) {
                
                    if ( $website == '' ) {
                        
                        $website_text = $txt_placeholder_arr['website'];
                    
                    } else {
                        
                        $website_text=$website;
                        
                    } ?>
				
                    <span class="pure-u-1-3 meta-web">
                        <i class="network icon"></i>
                        <a target="_blank" href="http://<?php echo str_replace("http://","",$website); ?>" class="<?php echo $edit_class; ?> <?php echo $edit_type_link; ?>" data-module-name="user" data-id="<?php echo $profile_id; ?>" data-field-name="website" data-field-url="<?php echo $website; ?>"><?php echo str_replace("http://","",$website_text); ?></a>
                    </span><?php
				
                } ?>
			</div>
            
	    </div>
	     
		<div class="user-actions"><?php

            //Start follow button generation.
            if( $user->isAuthorized() && $profile->getId() != $user->getId() ) { //Logged in and not own profile.
            
                if( $user->isFollowing( $profile ) ) { //Logged in user is following profile user.
					
                    $follow_instance = $user_follower_module->searchRecords(array(
                        array('field' => 'follower', 'value' => $user->getId()),
						array('field' => 'following', 'value' => $profile->getId())
					));
						
                    $follow_instance = array_pop($follow_instance);
			
                    //Make the button.
                    $following_button = '<a data-follower-object-id="'.$follow_instance->getId().'" data-follower-id="'.$user->getId().'" data-following-id="'.$profile_id .'" data-hover-text="Unfollow" class="button" data-hover-class="button" href="#" rel="user unfollow"><button class="pure-button pure-button-primary follow-button"><span>Following</span></button></a>';
                    
				} else {
			
					$following_button = '<a href="#" class="button" data-hover-text="" data-hover-class="button" data-follower-id="'.$user->getId().'" data-following-id="'.$profile_id .'" rel="user follow"><button class="pure-button pure-button-primary follow-button"><span>Follow</span></button></a>';
					
                }  
					
            } elseif ( $profile->getId() != $user->getId() ) {
					
                $following_button = '<a href="#" class="button en-trigger" data-modal="modal-sign-in" data-style="slide-up"><button class="pure-button pure-button-primary follow-button"><span>Follow</span></button></a>';
			
            } else {
                
                $following_button = NULL;
			
            }
			
			echo $following_button;
            //End follow button.
            
            //Contact button.
            $email_pub = $profile->isMetaValue('email_public');
            if ($user->isAuthorized() && $email_pub ==1) { //User is logged in. ?>
			
                <button class="pure-button pure-button-primary contact-button en-trigger" data-modal="modal-hire" data-style="slide-up"><span><?php echo 'Contact'; ?></span></button><?php 
            
            }
            
            //Delete user button
            if ( $user->objectGroup()->isAdmin() && $user->getId() != $profile->getId() )  { //Logged in as admin and not own profile. ?>
			
                <a rel="user delete-profile" href="<?php echo $this_filename . '?user=' . $profile_id; ?>&amp;action=delete-profile"><button class="pure-button pure-button-primary delete-button"><span>Delete</span></button></a><?php 
            
            } ?>
			
			<span class="last-seen">
                <i class="icon clock"></i>
                Member since:  <?php 
                $member_since = MK_Utility::timeSince( strtotime($profile->renderDateRegistered())); 
                echo $member_since; ?>
            </span>
			
			<span class="last-seen">
                <i class="icon clock"></i>
                Last seen: <?php
                $last_seen = MK_Utility::timeSince( strtotime($profile->renderLastLogin()) );
                
                if ( $profile->getMetaValue('last_login') == 0 ) {
                    echo 'Never';
                } else {
                    echo ucfirst($last_seen) . ' ago';
                } ?>
            </span>
		
		</div><?php 
        
        //Avaliable for freelance.
        if ( $freelancing ) { ?>
            <div class="freelancing-holder"><?php 
			
                $freelancing = $profile->getMetaValue('available_for_freelance'); ?>
                
                <span class="freelance">
                    <i class="icon <?php echo $profile->isMetaValue('available_for_freelance') ? 'checkmark' : 'cross'; ?>"></i>Available for freelance: <span class="<?php echo $edit_class; ?> <?php echo $edit_type_yesno_freelance; ?>" data-module-name="user" data-id="<?php echo $profile_id; ?>" data-field-name="available_for_freelance"><?php echo $freelancing ? 'Yes' : 'No'; ?></span>
                </span> 
			
            </div><?php 
        } ?>
		
	</div>
    
</div>