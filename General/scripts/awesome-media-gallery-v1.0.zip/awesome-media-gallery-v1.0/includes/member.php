<?php

$profile_flag = 0;

if( $id = $user_id ) {

	$id = explode( '-' , $id );
	$id = array_shift( $id );
	
	$profile = $user_record; //Already generated in BREADCRUMB
	
	$profile_name   = $profile->getDisplayName();
	$profile_image  = ( $profile->getAvatar() ? $profile->getAvatar() : $config->site->default_avatar );
	$profile_email  = $profile->getEmail(); 
	$profile_id     = $profile->getId();
}

/*EDITING*/
$admin_mode   = 0;
$editing_mode = 0;

if( ($user->isAuthorized() && ($user->getId() == $profile->getId())) || ($user->objectGroup()->isAdmin()) ) { //User is logged in, viewing own profile or is an admin.

    $edit_class                = "edit";
    $edit_type_text            = "edit-text";
    $edit_type_link            = "edit-link";
    $edit_type_textarea        = "edit-textarea";
    $edit_type_category        = "edit-category";
    $edit_type_gender          = "edit-gender";
    $edit_type_date            = "edit-date";
    $edit_type_yesno           = "edit-yesno";	
    $edit_type_yesno_freelance = "edit-yesno-freelance";
    $edit_type_tags            = "edit-tags";	
    $admin_mode                = 1;
    
} else {
    
    $edit_class = "";
    $edit_type_text = "";
    $edit_type_link = "";
    $edit_type_textarea = "";
    $edit_type_category = "";
    $edit_type_gender = "";
    $edit_type_date = "";
    $edit_type_yesno = "";
    $edit_type_yesno_freelance = "";
    $edit_type_tags = "";
    $admin_mode = 0;
    
}
	
?>
<!-- Content Section PROFILE Starts Here -->
<section class="content profile pure-u-3-4"> 

    <!-- User  Profile Starts Here --><?php
        include ("member-profile.php"); ?>
    <!-- User Profile Ends Here -->

    <div class="user-profile-nav">

        <a href="<?php echo getProfileUrl( $profile_id ); ?>"><button class="pure-button pure-button-primary <?php if ( $section == 'about' || empty( $section ) ) echo 'pure-button-active'; ?>"><span>Profile</span></button></a>

        <a href="<?php echo getProfileUrl( $profile_id, 'images' ); ?>"><button class="pure-button pure-button-primary <?php if ( $section == 'images' ) echo 'pure-button-active'; ?>"><span>Images</span></button></a>

        <a href="<?php echo getProfileUrl( $profile_id, 'videos' ); ?>"><button class="pure-button pure-button-primary <?php if ( $section == 'videos' ) echo 'pure-button-active'; ?>"><span>Videos</span></button></a>

        <a href="<?php echo getProfileUrl( $profile_id, 'followers' ); ?>"><button class="pure-button pure-button-primary <?php if ( $section == 'followers' ) echo 'pure-button-active'; ?>"><span>Followers</span></button></a>

        <a href="<?php echo getProfileUrl( $profile_id, 'following' ); ?>"><button class="pure-button pure-button-primary <?php if ( $section == 'following' ) echo 'pure-button-active'; ?>"><span>Following</span></button></a>

        <a href="<?php echo getProfileUrl( $profile_id, 'likes' ); ?>"><button class="pure-button pure-button-primary <?php if ( $section == 'likes' ) echo 'pure-button-active'; ?>"><span>Favorites</span></button></a>

        <a href="<?php echo getProfileUrl( $profile_id, 'activity' ); ?>"><button class="pure-button pure-button-primary <?php if ( $section == 'activity' ) echo 'pure-button-active'; ?>"><span>Activity</span></button></a>

    </div><?php

    switch ($section) {
        case 'about':
            include('includes/member-about.php');
            break;
        case 'following':
            include('includes/member-following.php');
            break;
        case 'followers':
            include('includes/member-followers.php');
            break;
        case 'activity':
            include('includes/member-activity.php');
            break;
        case 'images':
            include('includes/member-images.php');
            break;
        case 'videos':
            include('includes/member-videos.php');
            break;
        case 'likes':
            include('includes/member-likes.php');
            break;
        default:
            include('includes/member-about.php');
    } ?>
    
</section>

<!-- Sidebar Starts Here --><?php

if (  ($deviceType <> 'phone' ) &&  ( $deviceType <> 'tablet' ) ) { //Only show sidebar on desktop.
    
    include ('includes/ad-sidebar.php'); 

} ?>

<!-- Sidebar Ends Here -->