<?php

$num_items = ($deviceType == 'phone')?24:60;

$total_records        = $user_module->getTotalRecords();
$user_catgegory_list  = $users_types_array_combined;
$paginator            = new MK_Paginator( MK_Request::getQuery('page', 1), $num_items );
$user_search_criteria = array(); //Setup the search criteria array
$options              = array(
                            'order_by' => array(
                                'field' => 376,
                                'direction' => 'ASC'
                            )
                        );
                        
if( !empty( $section ) ) { //Specified user type.
    
    $key = array_search(ucfirst($section), $user_catgegory_list); //Convert section to category id.
    
    $user_search_criteria[] = array(
        'literal' => "(`category` = " . $key . ")"
    );
    
    $active = '';
    
    $member_type = ucfirst($section);
    
} else { //All.

    $active = 'pure-button-active';
    
    $member_type = 'Members';

}

$users = $user_module->searchRecords($user_search_criteria, $paginator, $options); 

$plural = new Inflect; ?>

<section class="content members pure-g-r"> 

<div class="members-nav">
    
    <a href="members" title="All">
        <div class="pure-button pure-button-primary  <?php echo $active; ?>">
            <span>All <?php //echo '(' . $total_records . ')'; ?></span>
        </div>
    </a><?php

    foreach ( $user_catgegory_list as $key => $value ) {
    
        if ($value == ucfirst($section)) { //Set active class for button state. DH
        
            $active = 'pure-button-active';
        
        } else {
        
            $active = ''; //Reset the active class for the next loop. DH
        
        }
    
        $total_records = $user_module->getTotalRecords(array(
            array('field' => 'category', 'value' => $key)
        )); 
        
        if($total_records > 0) { ?>
       
            <a href="members/<?php echo strtolower($value); ?>" title="<?php echo $value; ?>">
                <div class="pure-button pure-button-primary <?php echo $active; ?>">
                    <span><?php echo $plural->pluralize($value); //. ' (' . $total_records . ')'; ?></span>
                </div>
            </a><?php
        
        }
    } ?>
    
</div>     

<!-- Members grid-cs-cs Starts Here -->
<?php

if( !empty($users) ) { 

    $count = $paginator->getTotalRecords();?>
    
  <h2 class="sub-title"><?php echo $plural->pluralize_if($count, $member_type); ?></h2>
  
    <ul data-autoload="true" class="members"><?php
        
        foreach( $users as $member ) 	{
            
            include ('includes/member-box.php');
        
        } ?> 
        
    </ul>

    <div class="paginator clear-fix">
    
        <div class="pure-button pure-button-primary load-more ladda-button" data-style="slide-up">
            <span class="ladda-label"><?php 
                echo $paginator->render('members.php?page={page}'); ?>
            </span>
        </div>
        
    </div><?php

} else { ?>

  <p class="alert alert-warning">There are no members</p><?php
  
} ?>

</section>