<?php

if (($_SERVER['PHP_SELF'] = "member.php") && !empty($user_id) && ($email_pub == 1)) { ?>
<!-- Hire Me Modal -->
<div class="en-modal en-effect-1" id="modal-hire">
  <div class="en-content">
    <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>"></div>
    <div class="hire-container">
      <iframe id="ContactUserFrame" src="contact-user.php?user=<?php echo $user_id; ?>" seamless="seamless"></iframe>
    </div>
    <a class="en-close circled-cross icon"></a>
  </div>
</div><?php
} ?>

<div class="en-modal en-effect-1" id="modal-sign-in">
  <div class="en-content">
    <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>"></div>
    <div class="sign-in-container">
      <iframe id="SignInFrame" src="sign-in.php" seamless="seamless"></iframe>
      <a class="en-close circled-cross icon"></a>
	</div>
  </div> 
</div><!-- END EN-MODAL -->

<div class="en-modal en-effect-1" id="modal-sign-up">
  <div class="en-content">
    <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>"></div>
    <div class="sign-up-container">
      <iframe id="SignUpFrame" src="sign-up.php" seamless="seamless"></iframe>
      <a class="en-close circled-cross icon"></a>
	</div>
  </div> 
</div><!-- END EN-MODAL -->

<div class="en-modal en-effect-1" id="modal-contact">
  <div class="en-content">
    <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>"></div>
    <div class="contact-container">
      <iframe id="ContactFrame" src="contact.php" seamless="seamless"></iframe>
      <a class="en-close circled-cross icon"></a>
	</div>
  </div> 
</div><!-- END EN-MODAL -->

<div class="en-modal en-effect-1" id="modal-about">
  <div class="en-content">
    <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>"></div>
    <div class="about-container">
      <iframe id="AboutFrame" src="about.php" seamless="seamless"></iframe>
      <a class="en-close circled-cross icon"></a>
	</div>
  </div> 
</div><!-- END EN-MODAL -->

<div class="en-modal en-effect-1" id="modal-terms">
  <div class="en-content">
    <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>"></div>
    <div class="terms-container">
      <iframe id="TermsFrame" src="terms.php" seamless="seamless"></iframe>
      <a class="en-close circled-cross"><button class="pure-button pure-button-primary">Close</button></a>
	</div>
  </div> 
</div><!-- END EN-MODAL -->

<div class="en-modal en-effect-1" id="modal-change-password">
  <div class="en-content">
    <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>"></div>
    <div class="password-container">
      <iframe id="ChangePasswordFrame" src="change-password.php" seamless="seamless"></iframe>
      <a class="en-close circled-cross icon"></a>
	</div>
  </div> 
</div><!-- END EN-MODAL -->

<div class="en-modal en-effect-1" id="modal-choose">
  <div class="en-content">
    <!--Title in upload choose.php <div class="modal-title"><img src="<?php echo $modal_logo_path; ?>" alt=""></div>-->
    <div class="choose-container">
    <iframe id="ChooseFrame" data-src="upload-choose.php" seamless="seamless"></iframe>
	</div>
	<a class="en-close circled-cross icon"></a>
  </div> 
</div><!-- END EN-MODAL -->