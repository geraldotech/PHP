<?php
require_once '_inc.php';

// We get an instance of the image & gallery module
$image_module              = MK_RecordModuleManager::getFromType('image'); //Image details
$gallery_module            = MK_RecordModuleManager::getFromType('image_gallery'); //Gallery Info
$image_favourite_module    = MK_RecordModuleManager::getFromType('image_favourite'); //Fav info
$image_comment_module      = MK_RecordModuleManager::getFromType('image_comment'); //Comments Info
$image_comment_like_module = MK_RecordModuleManager::getFromType('image_comment_like'); //Comment Likes Info
$field_module              = MK_RecordModuleManager::getFromType('module_field');
$user_follower_module      = MK_RecordModuleManager::getFromType('user_follower'); //Follow

//Variables
require_once '_variables.php';

//CREATE BREADCRUMB
include ('includes/breadcrumbs.php');

// Header Starts Here
require_once 'header.php';

?>
<div class="main-container">
  <div class="main wrapper clearfix pure-g-r">  

	  <section class="content generic pure-g-r"> 
	  
		<h2>Privacy Policy</h2>
		<p>[Last update: Dec 2013]</p>
		<h3>Information we gather:</h3>
		<p>The following information is gathered from our website visitors:<br />IP address</p>
		
		<h3>How we use the information we gather:</h3>
		<p>We use the information to enhance our site.</p>
		
		<h3>The people that are given access to this information:</h3>
		<p>Your personal information is accessible by site administrators</p>
		
		<h3>The security measures we have in place to protect your personal information:</h3>
		<p>To safeguard your personal information, please do not upload anything you want to keep private.</p>
		
		<h3>Use of cookies:</h3>
		<p>Our website makes use of cookies which are small digital files that are stored in your web browser that enable us to track your return visits to our website.</p>
		<p>Your browser settings may allow you to block these cookies, but we recommend you have them enabled to help us personalise your experience of our website.</p>
				  	  
	  </section>

  </div>
</div>

<!-- Footer Starts Here -->
<?php include ('footer.php'); ?>
<!-- Footer Ends Here -->