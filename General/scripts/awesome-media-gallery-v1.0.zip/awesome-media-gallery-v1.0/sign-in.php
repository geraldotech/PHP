<?php
require_once( '_inc.php' );

//Variables
include( '_variables.php' );

header( 'Content-type: text/html; charset=utf-8' );

ob_start();

$head_title[] = 'Sign In';

//$callback_url = MK_Utility::serverUrl( 'sign-in.php' );
$callback_url = MK_Utility::serverUrl( 'index.php' );

if ( $user->isAuthorized() ) { // If the user is already logged in then return them to the homepage
    //header('Location: '.MK_Utility::serverUrl('/'), true, 302);
    echo 'You are signed in. Please wait...';
    exit;
}

if ( $config->site->yahoo->login && $platform === 'yahoo' ) { // If the user clicked the 'sign in with Yahoo' link
    
} elseif ( $config->site->windowslive->login && $platform === 'windowslive' ) { // If the user clicked the 'sign in with Windows Live' link
    
} elseif ( $config->site->facebook->login && $platform === 'facebook' ) { // If the user clicked the 'sign in with Facebook' link
    
    $config          = MK_Config::getInstance();
    $facebook_return = MK_Utility::serverUrl( '/' );
    //$facebook_return = $callback_url;
    $facebook_url    = $config->facebook->getLoginUrl( array(
         'redirect_uri' => $facebook_return,
        //'redirect_uri' => $facebook_return,
        'scope' => 'email,user_photos' 
    ) );
    //echo $facebook_url;
    header( 'Location: ' . $facebook_url, true, 302 );
    exit;
    
} elseif ( $config->site->twitter->login && $platform === 'twitter' && empty( $session->registration_details ) ) { // If the user clicked the 'sign in with Twitter' link
    
    $config = MK_Config::getInstance();
    
    $callback_url = MK_Utility::serverUrl( 'sign-in.php?platform=twitter' );
    
    $twitter_request_token = $config->twitter->getRequestToken( $callback_url );
    
    $session->twitter_oauth_token        = $twitter_request_token['oauth_token'];
    $session->twitter_oauth_token_secret = $twitter_request_token['oauth_token_secret'];
    
    $twitter_url = $config->twitter->getAuthorizeURL( $session->twitter_oauth_token );
    
    header( 'Location: ' . $twitter_url, true, 302 );
    exit;
    
} elseif ( $config->site->google->login && $platform === 'google' ) { // If the user clicked the 'sign in with Google' link
    
    
    
    
} elseif ( $platform === 'core' ) { // User is logging in with their site account
    unset( $session->registration_details );
}

$user_module  = MK_RecordModuleManager::getFromType( 'user' );
$field_module = MK_RecordModuleManager::getFromType( 'module_field' );
$criteria     = array(
     array(
         'field' => 'module',
        'value' => $user_module->getId() 
    ),
    array(
         'field' => 'name',
        'value' => 'email' 
    ) 
);

$user_email_field = $field_module->searchRecords( $criteria );
$user_email_field = array_pop( $user_email_field );



if ( !empty( $session->registration_details ) ) {
    $body_class[] = 'narrow';
    
    $user_details = unserialize( $session->registration_details );
    $settings     = array(
         'attributes' => array(
             'class' => 'clear-fix standard standard-narrow',
            'action' => 'sign-in.php' 
        ) 
    );
    
    if ( !empty( $user_details['twitter_id'] ) ) { //Returned from twitter.
        
?>
		<h3>Twitter Sign In</h3>
<?php
    }
?>
	<p>Simply enter your email address to complete the sign-in process!</p>
<?php
    $structure = array(
         'email' => array(
             'label' => 'Email',
            'validation' => array(
                 'email' => array(),
                'instance' => array(),
                'unique' => array(
                     null,
                    $user_email_field,
                    $user_module 
                ) 
            ) 
        ) 
    );
    
    $complete_field = array(
         'type' => 'submit',
        'attributes' => array(
             'value' => 'Complete Sign In' 
        ) 
    );
    
    if ( !empty( $user_details['twitter_id'] ) ) {
        $structure['twitter'] = $complete_field;
    }
    
    $structure['cancel'] = array(
         'type' => 'submit',
        'attributes' => array(
             'value' => 'Cancel Sign-In',
            'class' => 'button-red' 
        ) 
    );
    
    $form = new MK_Form( $structure, $settings );
    
    if ( $form->isSubmitted() && $form->getField( 'cancel' )->getValue() ) {
        header( 'Location: ' . MK_Utility::serverUrl( 'sign-in.php?platform=core' ), true, 302 );
        exit;
    }
    
    if ( $form->isSuccessful() ) {
        $user_details['email']         = $form->getField( 'email' )->getValue();
        $session->registration_details = serialize( $user_details );
        
        header( 'Location: ' . MK_Utility::serverUrl( 'index.php' ), true, 302 );
        
        exit;
    } else {
        print $form->render();
    }
} else {
    $settings_login = array(
         'attributes' => array(
             'class' => 'clear-fix standard standard-right social' 
        ) 
    );
    
    $structure_login = array();
    
    
    if ( $config->site->facebook->login ) {
        $structure_login['facebook'] = array(
             'fieldset' => 'Social-SignUp',
            'type' => 'link',
            'text' => '',
            'icon' => '<span class="socicon socicon-facebook"></span>',
            'attributes' => array(
                 'href' => 'sign-in.php?platform=facebook',
                'class' => 'btn-social facebook-btn',
                'target' => "_parent" 
            ) 
        );
    }
    
    
    if ( $config->site->twitter->login ) {
        $structure_login['twitter'] = array(
             'fieldset' => 'Social-SignUp',
            'type' => 'link',
            'text' => '',
            'icon' => '<span class="socicon socicon-twitter"></span>',
            'attributes' => array(
                 'href' => 'sign-in.php?platform=twitter',
                'class' => 'btn-social twitter-btn',
                'target' => "_parent" 
            ) 
        );
    }
    
    if ( $config->site->linkedin->login ) {
        $structure_login['linkedin'] = array(
             'fieldset' => 'Social-SignUp',
            'type' => 'link',
            'text' => '',
            'icon' => '<span class="socicon socicon-linkedin"></span>',
            'attributes' => array(
                 'href' => 'sign-in.php?platform=linkedin',
                'class' => 'btn-social linkedin-btn',
                'target' => "_parent" 
            ) 
        );
    }
    
    if ( $config->site->windowslive->login ) {
        $structure_login['windowslive'] = array(
             'fieldset' => 'Social-SignUp',
            'type' => 'link',
            'text' => '',
            'icon' => '<span class="socicon socicon-windows"></span>',
            'attributes' => array(
                 'href' => 'sign-in.php?platform=windowslive',
                'class' => 'btn-social  windowslive-btn',
                'target' => "_parent" 
            ) 
        );
    }
    
    if ( $config->site->yahoo->login ) {
        $structure_login['yahoo'] = array(
             'fieldset' => 'Social-SignUp',
            'type' => 'link',
            'text' => '',
            'icon' => '<span class="socicon socicon-yahoo"></span>',
            'attributes' => array(
                 'href' => 'sign-in.php?platform=yahoo',
                'class' => 'btn-social yahoo-btn',
                'target' => "_parent" 
            ) 
        );
    }
    
    if ( $config->site->google->login ) {
        $structure_login['google'] = array(
             'fieldset' => 'Social-SignUp',
            'type' => 'link',
            'text' => '',
            'icon' => '<span class="socicon socicon-google"></span>',
            'attributes' => array(
                 'href' => 'sign-in.php?platform=google',
                'class' => 'btn-social google-btn',
                'target' => "_parent" 
            ) 
        );
    }
    
    $settings = array(
         'attributes' => array(
             'class' => 'clear-fix standard standard-' . ( count( $structure_login ) > 0 ? 'left' : 'full' ) 
        ) 
    );
    
    $structure = array(
         'email' => array(
            //'label' => 'Email',
             'fieldset' => 'Sign In',
            'validation' => array(
                 'email' => array(),
                'instance' => array ()
            ),
            'attributes' => array(
                 'placeholder' => 'Email Address' 
            ) 
        ),
        'password' => array(
            //'label' => 'Password',
             'fieldset' => 'Sign In',
            'validation' => array(
                 'instance' => array() 
            ),
            'attributes' => array(
                 'type' => 'password',
                'placeholder' => 'Password' 
            ) 
        ),
        'login' => array(
             'type' => 'submit',
            'fieldset' => 'Sign In',
            'attributes' => array(
                 'value' => 'Sign in',
                'class' => 'btn-normal btn-primary' 
            ) 
        ),
        'forgotten-password' => array(
             'type' => 'link',
            'fieldset' => 'Other',
            'text' => 'Forgotten Password?',
            'attributes' => array(
                 'href' => 'forgotten-password.php',
                'class' => 'sign-up' 
            ) 
        ),
        'signup' => array(
             'type' => 'link',
            'fieldset' => 'Other',
            'text' => 'Sign up for an Account',
            'attributes' => array(
                 'href' => '#',
                'class' => 'sign-up sign-in' 
            ) 
        ) 
    );
    
    $form = new MK_Form( $structure, $settings );
    
    if ( $form->isSuccessful() ) {
        $user = MK_Authorizer::authorizeByEmailPass( $form->getField( 'email' )->getValue(), $form->getField( 'password' )->getValue() );
        
        if ( $user->isAuthorized() ) {
            $session->login = $user->getId();
            $cookie->set( 'login', $user->getId(), $config->site->user_timeout );
            
            if ( !$redirect = $config->extensions->core->login_url ) {
                $redirect = $logical_redirect;
            }
            
            
            echo '<script type="text/JavaScript"> setTimeout("top.location.href = \'index.php\';",0); </script>';
            //Will be added for next version. Nicer message.
           // $login_success = '<div class="notice-header success-header">Awesome, You\'re Signed In!</div><p class="alert alert-success">We\'re sending you back to the home page.</p>'
           // $login_success .= '<script type="text/JavaScript"> setTimeout("top.location.href = '\index.php\';",1500); </script>'
        
            exit;
        } else {
            $form->getField( 'email' )->getValidator()->addError( 'This username and password combination does not match our records. Please try again.' );
        }
    }
    
    
    if ( count( $structure_login ) > 0 ) {
        echo '<div class="notice-header">Use a social network</div>';
        $login_form = new MK_Form( $structure_login, $settings_login );
        print $login_form->render();
        echo '<div class="notice-header">OR USE OLD SKOOL</div>';
    } else {
        echo '<div class="notice-header">OLD SKOOL LOGIN</div>';
    }
    
    print $form->render();
    
}

$output = ob_get_contents();

ob_end_clean(); ?>

<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <base href="<?php echo $config->site->url; ?>">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="robots" content="noindex">
        <title><?php echo implode(' / ', $head_title); ?></title>
        <link rel="stylesheet" type="text/css" href="css/vendor/entypo.css">
        <link rel="stylesheet" type="text/css" href="css/vendor/socicon.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
        <script src="js/vendor/modernizr.custom.min.js"></script>
        <script src="js/modal.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {
        
            var ModalContainer = '.sign-in-container';
            var ModalInnerContainer = 'body';
            
            setNewHeight2(ModalContainer, ModalInnerContainer, '#SignInFrame');
        
            $('.sign-in').bind('click',function(e) {
                e.preventDefault(); 
                parent.$("span[data-modal='modal-sign-up']", window.parent.document).click();  
            });
        
        });
        
    </script>
  </head>
  <body class="modal-body modal-sign-in">
    
  <?php echo $output; ?>
  
  </body>
</html>