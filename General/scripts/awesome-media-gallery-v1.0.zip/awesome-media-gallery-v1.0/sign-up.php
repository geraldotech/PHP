<?php
require_once('_inc.php');

//Variables
include ('_variables.php');

header('Content-type: text/html; charset=utf-8');

ob_start();

$head_title[]     = 'Sign Up';

$user_module      = MK_RecordModuleManager::getFromType('user');
$user_meta_module = MK_RecordModuleManager::getFromType('user_meta');
$field_module     = MK_RecordModuleManager::getFromType('module_field');

$social = false;

$output = '';

// If the user is already logged in then return them to the homepage
if($user->isAuthorized())
{
	//header('Location: '.MK_Utility::serverUrl('/'), true, 302);
	//exit;
  
  echo '<span class="signed-in-text">You are signed in. Redirecting....</span>';
  exit;
}

// User is logging in with their site account
if( MK_Request::getQuery('platform') === 'core' )
{
	unset( $session->registration_details );
}

if( $verification_code = MK_Request::getQuery('verification_code') )
{
	$get_user_from_code = $user_meta_module->searchRecords(array(
		array('field' => 'key', 'value' => 'verification_code'),
		array('field' => 'value', 'value' => $verification_code),
	));

	if( $user_from_code = array_pop($get_user_from_code) )
	{
		$user = $user_from_code->objectUser();
		$user
			->setVerificationCode('')
			->isEmailVerified(true)
			->save();
?>
        <div class="notice-header success-header">Awesome, You're Verified!</div>
        <p class="alert alert-success">We're sending you back to the home page.</p>
        <script type="text/JavaScript">
         // setTimeout("top.location.href = 'index.php';",1500);
        </script>
<?php
		$session->login = $user->getId();
		$cookie->set('login', $user->getId(), $config->site->user_timeout);
        exit();
	}
	else
	{
?>
        <h3>Invalid Verification Code</h3>
        <p class="alert alert-error">This verification code is invalid.</p>
<?php
	}

}
else
{

	$criteria = array(
		array('field' => 'module', 'value' => $user_module->getId()),
		array('field' => 'name', 'value' => 'email')
	);
	
	$user_email_field = $field_module->searchRecords($criteria);
	$user_email_field = array_pop( $user_email_field );
    
    $criteria_display_name = array(
		array('field' => 'module', 'value' => $user_module->getId()),
		array('field' => 'name', 'value' => 'display_name')
	);
	
	$display_name_field = $field_module->searchRecords($criteria_display_name);
	$display_name_field = array_pop( $display_name_field );
	
	$settings_login = array(
		'attributes' => array(
			'class' => 'clear-fix standard standard-right social'
		)
	);
	
	$structure_login = array();
  
	if($config->site->facebook->login)
	{
		$structure_login['facebook'] = array(
			'fieldset' => 'Social-SignUp',
			'type' => 'link',
			'text' => '',
			'icon' => '<span class="socicon socicon-facebook"></span>',
			'attributes' => array(
				'href' => 'sign-in.php?platform=facebook',
                'class' => 'btn-social facebook-btn',
                'target' => "_parent"
            )
		);	
	}

  
	if($config->site->twitter->login)
	{
		$structure_login['twitter'] = array(
			'fieldset' => 'Social-SignUp',
			'type' => 'link',
			'text' => '',
			'icon' => '<span class="socicon socicon-twitter"></span>',
			'attributes' => array(
				'href' => 'sign-in.php?platform=twitter',
                'class' => 'btn-social twitter-btn',
                'target' => "_parent"
                )
            );	
	}

	if($config->site->linkedin->login)
	{
		$structure_login['linkedin'] = array(
			'fieldset' => 'Social-SignUp',
			'type' => 'link',
			'text' => '',
			'icon' => '<span class="socicon socicon-linkedin"></span>',
			'attributes' => array(
				'href' => 'sign-in.php?platform=linkedin',
                'class' => 'btn-social linkedin-btn',
                'target' => "_parent"
			)
		);	
	}

	if($config->site->windowslive->login)
	{
		$structure_login['windowslive'] = array(
			'fieldset' => 'Social-SignUp',
			'type' => 'link',
			'text' => '',
			'icon' => '<span class="socicon socicon-windows"></span>',
			'attributes' => array(
				'href' => 'sign-in.php?platform=windowslive',
				'class'=>'btn-social  windowslive-btn',
                'target' => "_parent"
			)
		);	
	}

	if($config->site->yahoo->login)
	{
		$structure_login['yahoo'] = array(
			'fieldset' => 'Social-SignUp',
			'type' => 'link',
			'text' => '',
			'icon' => '<span class="socicon socicon-yahoo"></span>',
			'attributes' => array(
				'href' => 'sign-in.php?platform=yahoo',
				'class'=>'btn-social yahoo-btn',
                'target' => "_parent"
			)
		);
	}

	if($config->site->google->login)
	{
		$structure_login['google'] = array(
			'fieldset' => 'Social-SignUp',
			'type' => 'link',
			'text' => '',
			'icon' => '<span class="socicon socicon-google"></span>',
			'attributes' => array(
				'href' => 'sign-in.php?platform=google',
                'class'=>'btn-social google-btn',
                'target' => "_parent"
			)
		);	
	}
	
	$settings = array(
		'attributes' => array(
			'class' => 'clear-fix standard standard-'.( count($structure_login) > 0 ? 'left' : 'full' )
		)
	);
	
	$structure = array(
    
        'display_name' => array(
			//'label' => 'Display name',
			'fieldset' => 'Sign Up',
			'validation' => array(
				'instance' => array(),
                'unique' => array(null, $display_name_field, $user_module)
			),
            'attributes' => array(
                'placeholder' => 'Display Name'
			),
            'suffix' => '<div id="username-text" style="display:none;"></div>'
		),
    
        'email' => array(
			//'label' => 'Email',
			'fieldset' => 'Sign Up',
			'validation' => array(
				'email' => array(),
				'instance' => array(),
				'unique' => array(null, $user_email_field, $user_module)
			),
            'attributes' => array(
                'placeholder' => 'Email Address'
			)
		),

		'password' => array(
			//'label' => 'Password',
			'fieldset' => 'Sign Up',
			'type' => 'password',
			'validation' => array(
				'instance' => array(),
			),
            'attributes' => array(
                'placeholder' => 'Password'
			),
		),
        'terms' => array(
            'type' => 'checkbox',
			'label' => 'I agree to the <a class="terms">Terms and Conditions</a>',
			'fieldset' => 'Sign Up',
            'attributes' => array(
				'value' => '1'
			),
			'validation' => array(
				'instance' => array(),
			),
		),
        
		'register' => array(
			'type' => 'submit',
			'fieldset' => 'Sign Up',
			'attributes' => array(
				'value' => 'Sign up',
                'class' => 'btn-normal btn-primary'
			)
		)
	);
	

	$form = new MK_Form($structure, $settings);
	
	if($form->isSuccessful()==false){
        $output = '<div class="notice-header">Important</div><div class="notice-text">Please respect other people and keep it fun.</div>';
	}
	
	if($form->isSuccessful())
	{
        $username = str_replace(' ', '', $form->getField('display_name')->getValue());
        $username = strtolower($username);
    
		$new_user = MK_RecordManager::getNewRecord($user_module->getId());
		
		$new_user
			->setEmail($form->getField('email')->getValue())
			->setPassword($form->getField('password')->getValue())
			->setDisplayName($form->getField('display_name')->getValue())
            ->setCategory(1)
            ->setUsername($username)
			->save();
?>
           
<?php
		if( $config->extensions->core->email_verification )
		{
?>
			<p class="alert alert-success">You've been emailed a link to verify your email address.<br /><br>Click it to complete the sign-up process.</p>
			<div class="notice-spam">Spam Notice</div><div class="notice-spam-text">Please make sure to check your spam folder.</div>
<?php
		}
		else
		{
			$session->login = $new_user->getId();
			$cookie->set('login', $new_user->getId(), $config->site->user_timeout);
?>
			<!--<p class="alert alert-success">Thank you for signing up. You can <a href="member.php?user=<?php echo $new_user->getId(); ?>">make changes to your profile</a>.</p>
      <p class="alert alert-success">We're sending you back to the home page.</p> -->
      <script type="text/JavaScript">
       setTimeout("top.location.href = 'index.php';",0);
      </script>
<?php
		}
	
		if( $redirect = $config->extensions->core->register_url )
		{
			header('Location: '.MK_Utility::serverUrl($redirect), true, 302);
		}
	}
	else
	{

    if(count($structure_login) > 0)
		{
			$social=true;
            echo '<div class="notice-header">Use a social network</div>';
			$login_form = new MK_Form($structure_login, $settings_login);
			print $login_form->render();
            echo '<div class="notice-header">OR USE OLD SKOOL</div>';
		}
		
		print $form->render();
    
	}
}

$output .= ob_get_contents();
ob_end_clean();

?>
<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
  <head>
	<base href="<?php echo $config->site->url; ?>" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="robots" content="noindex">
    <title><?php echo implode(' / ', $head_title); ?></title>
    <link rel="stylesheet" type="text/css" href="css/vendor/entypo.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/socicon.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/green.css">
    <script src="js/vendor/modernizr.custom.min.js"></script>
    <script src="js/modal.js"></script>
  
    <style>
    
    html {
		overflow:hidden;
	}
    </style>
 
  </head>
  <body class="modal-body modal-sign-up">
    <?php echo $output; ?>

    <script type="text/javascript">
      
    var $ = jQuery = window.parent.$;
      
    $(document).ready(function() { //iFrame document is loaded.
       
       $('#SignUpFrame').contents().find('a.terms').bind('click',function(e) {
            e.preventDefault();
            //console.log('Open Terms');
          $("span[data-modal='modal-terms']", window.parent.document).click();  
        });

        var container = $('#modal-sign-up .sign-up-container');
       
        $('#SignUpFrame').contents().find('input').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green'
        });
      
        var display_name    = $('#SignUpFrame').contents().find('form #display_name');
        var password_new_1   = $('#SignUpFrame').contents().find('#password_new_1'); 
        var password_new_2 = $('#SignUpFrame').contents().find('#password_new_2');  
        var once = false;
        var pad = <?php echo (($social)?'20':'21'); ?> /*fix for bluriness */
        
        password_new_1.on('keyup', function() {
        
            if ((this.value != '' || this.value != this.defaultValue) && (password_new_2.css('display') != 'inline-block')) {
            
                password_new_2.css('display', 'inline-block');
            	var new_height =  $("#SignUpFrame").contents().find("body").outerHeight()+pad;
                
                parent.$("#modal-sign-up .sign-up-container").css('height', (new_height) +'px');
                parent.$("#modal-sign-up .sign-up-container").css('max-height', (new_height) +'px');
                parent.$('#SignUpFrame').css('height', (new_height)+'px');
            } /*else {
            
                password_new_2.css('display', 'none');
                        
            }*/
        });
        
               
       //Check if an error message is above the password field. if true, show confirm password field.
       if ($("#SignUpFrame").contents().find('.error').length) {
            //console.log('Error exsits!');
            password_new_2.css('display', 'inline-block');
       }

        function isOdd(num) { //USE WHEN SOCIAL DISABLED
            return (num % 2) == 1
        }

        function isEven(num) { //USE WHEN SOCIAL ENABLED
            return (num % 2) == 0
        }
        
        o_Pad = 50;
        
        var o_Height = parseInt(parent.$(".sign-up-container").css("height"), 10);
        var i_Height = $("#SignUpFrame").contents().find("body").outerHeight();

        new_height = i_Height;

        /*ADJUST FOR BLURRY MODALS*/
        if (<?php echo (($social)?'isOdd':'isOdd'); ?>(new_height)) {
           
            new_height = (new_height + 1);
        
        } 
       
        parent.$('#SignUpFrame').css('height', (new_height+20)+'px');

        parent.$(".sign-up-container").css("max-height", (new_height+20) + 'px');
        
        parent.$(".sign-up-container").css("height", (new_height+20) + 'px');
      
    });
    
    </script>

  </body>
</html>