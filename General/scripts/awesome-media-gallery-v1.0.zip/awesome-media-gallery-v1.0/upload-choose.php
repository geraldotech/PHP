<?php
require_once ('_inc.php');
include ('_variables.php'); //Variables ?>

<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
  <head>
	<base href="<?php echo $config->site->url; ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="robots" content="noindex">
    <title><?php echo implode(' / ', $head_title); ?></title>
    <link rel="stylesheet" type="text/css" href="css/vendor/entypo.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
    <script src="js/vendor/modernizr.custom.min.js"></script>
    <script src="js/modal.js"></script>
    
    <style>
    
    html {
		overflow:hidden!important;
	}
    </style>
    
    <script type="text/javascript">
    
    /* $(document).ready(function() { //iFrame document is loaded.
    
        iframe_src = parent.$('.choose-container iframe').attr('src');
        this_src = document.location.pathname.replace('/','');
        
        console.log('iframe source is:' + iframe_src);
        console.log('We are: ' + this_src);
        
        if( iframe_src != this_src ) {
        
            alert ('I should totally reload!');
        
        }
    }); */
    

    window.onload = function() {
    
      	parent.$('#modal-choose .choose-container').css('height','auto');
        parent.$('#modal-choose .choose-container').css('max-height','160px');
        parent.$('#ChooseFrame').css('height','160px');

    }
      
    </script>
  </head>
  <body class="modal-body modal-choose">

    <div class="logo modal-title">
         <img src="<?php echo $modal_logo_path; ?>" alt="<?php echo $config->site->name; ?>">
    </div>
  
    <div class="choose-icon">
	<!--<svg id="upload-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 512 512" enable-background="new 0 0 512 512" xml:space="preserve"><path d="M154.647 236.729l103.354-103.531l103.351 103.531h-47.529v38.77H202.177v-38.77H154.647z M313.823 293.51H202.177v31.318h111.646V293.51z M202.177 341.271v25.53h111.646v-25.53H202.177z M422 256 c0-91.756-74.258-166-166-166c-91.755 0-166 74.258-166 166c0 91.8 74.3 166 166 166C347.755 422 422 347.7 422 256z M50 256 c0-113.771 92.229-206 206-206s206 92.2 206 206c0 113.771-92.229 206-206 206S50 369.8 50 256z"/></svg>-->
    </div>
  
    <div class="dotted choose">
    
	    <!--<span class="choose-text notice-text">Choose:</span> -->
	    
	    <div class="upload-images">
            <a href="upload">
                <span>Images</span>
                <i class="pictures icon"></i>
               <!-- <svg id="photo-add-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" width="150px" height="150px" viewBox="0 0 150 150" enable-background="new 0 0 150 150" xml:space="preserve"><path d="M163.366 234.976c-15.493 0-28.056-12.56-28.056-28.054c0-15.492 12.562-28.053 28.056-28.053 c15.492 0 28.1 12.6 28.1 28.053C191.419 222.4 178.9 235 163.4 234.976z M283.859 362.131H86.755V149.869h305.069 v63.076c13.013 0.9 25.4 4.1 36.8 9.23V113.114H50v285.771h258.769C298.119 388.6 289.6 376.1 283.9 362.131z M276.067 328.865c-2.15-30.266 8.288-59.125 28.073-80.799l-26.538-40.246L231.1 273.894l-25.272-26.051l-71.309 81.022H276.067z M462 321.095c0 42.964-34.828 77.791-77.791 77.791s-77.793-34.827-77.793-77.791c0-42.963 34.83-77.791 77.793-77.791 S462 278.1 462 321.095z M432.018 309.225h-33.673v-33.672h-26.006v33.672h-33.673v26.005h33.673v33.673h26.006v-33.673h33.673 V309.225z"/></svg>-->
            </a>
        </div>
	    
	    <div class="upload-videos">
            <a href="upload-video.php">
                <span>Videos</span>
                <i class="video icon"></i>
                <!--<svg id="video-add-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" width="125px" height="125px" viewBox="0 0 125 125" enable-background="new 0 0 125 125" xml:space="preserve"><path d="M377.603 266.184c-46.613 0-84.4 37.786-84.4 84.398c0 46.6 37.8 84.4 84.4 84.4 c46.611 0 84.398-37.784 84.398-84.397C462.001 304 424.2 266.2 377.6 266.184z M429.472 365.917h-36.533v36.533h-28.215 v-36.533H328.19v-28.213h36.533v-36.532h28.215v36.532h36.533V365.917z M294.907 433.3 c-10.691-10.692-19.051-23.094-24.838-36.585H166.7V273.42h123.027c22.426-25.485 54.023-39.784 87.875-39.784 c16.877 0 33.2 3.6 48.1 10.308V77.021H49.999v356.874h245.543C295.331 433.7 295.1 433.5 294.9 433.276z M349.315 114.81h41.09v35.337h-41.09V114.81z M349.315 176.445h41.09v35.338h-41.09V176.445z M166.7 114.81h145.633v123.274H166.7 V114.81z M129.718 396.691H88.626v-35.339h41.092V396.691z M129.718 335.054H88.626v-35.337h41.092V335.054z M129.718 273.1 H88.626v-35.335h41.092V273.124z M129.718 211.783H88.626v-35.338h41.092V211.783z M129.718 150.146H88.626V114.81h41.092V150.146z"/></svg>-->
            </a>
        </div>
        
    </div>
  
  </body>
</html>