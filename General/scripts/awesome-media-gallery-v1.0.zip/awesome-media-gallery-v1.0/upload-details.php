<?php
require_once '_inc.php';

// We get an instance of the image & gallery module
$image_module   = MK_RecordModuleManager::getFromType('image'); //Image details
$gallery_module = MK_RecordModuleManager::getFromType('image_gallery'); //Gallery Info
$field_module   = MK_RecordModuleManager::getFromType('module_field');


include ('_variables.php'); //Variables

if( !$user->isAuthorized() ) { //User is not logged in, get them out of here. DH ENGAGE 29/08

  header('Location: '.MK_Utility::serverUrl('/'), true, 302);
  exit;
  
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' ) {  //Check to ensure the user came from the uploads modal.
  
    if (empty($_POST['type'])) { //Type is empty. Assume user is uploading images.
  
        if (empty($_POST["gallery_type"])) {
            $type_gallery      = 1;
            $type_gallery_name = 'Image';
        } else {
            $type_gallery = $_POST["gallery_type"];
            
            if ($type_gallery == 1) {
                $type_gallery_name = 'Image';
            } else {
                $type_gallery_name = 'Video';
            }
            
        }
        
        
        
        if( !empty($_POST['image0']) ) { //Make an array of all the post images urls.

            $counter    = 0;
            $image_file = array();
          
            while( !empty( $_POST['image' . $counter]) ) {
              
                $image_file[] = $config->site->url.$_POST['image' . $counter];
                $title[] = $_POST['title' . $counter];
                $counter++;
          
            }
          
        } else {

            $image_file = !empty($_POST['image-file']) ? $_POST['image-file'] : $_GET['image-file'];
            $title = $_POST['image-name'];

        }
        
        foreach($image_file as $key=>$value) { //Loop through the image array     
        
            $url_split_array = explode($config->site->url, $value); //Split the URL on the .com
            
            $cropped_url[]   = $config->site->url."library/thumb.php?f=".$url_split_array[1]."&amp;m=crop&amp;w=480&amp;h=360"; //Create the cropped version
            $real_url[]      = $url_split_array[1]; //Keep the real URL also.
            //$title[]         = '';
            
            
            
            $description[]   = '';
            $video_url[]     = '';
            
        }
  
    } elseif ($_POST['type'] = 'video') { //Post Type is video.
        
        $isVideo      = true;
        $type_gallery = 2;
        $type_gallery_name = 'Video';
        $title        = $_POST['title'];
        $video_url    = $_POST['url'];
        $image_file   = $_POST['image_url'];
        $description  = $_POST['description'];
        
        foreach($image_file as $key=>$value) { //Loop through the video array
             
            $uploaded_video_image = MK_FileManager::uploadFileFromUrl( $value, $config->site->upload_path ); //Upload the video image url to server.
        
            $cropped_url[]   = $config->site->url."library/thumb.php?f=".$uploaded_video_image."&amp;m=crop-hd&amp;w=480&amp;h=270"; //Create the cropped version
            
            $real_url[]     = $uploaded_video_image;
        }
        
    }
    
    /* Setup the galleries */
    
        $gallery_options = array();

        $gallery_module = MK_RecordModuleManager::getFromType('image_gallery');

        $search_criteria[] = array('literal' => "(`type_gallery` = " . $type_gallery . ")");

        foreach($gallery_module->searchRecords($search_criteria) as $gallery) {
        
            $gallery_options[$gallery->getId()] = $gallery->getName();
            
        }
    
    /* End galleries setup */
    
    /* Setup the form */
    $criteria = array(
		array('field' => 'module', 'value' => $image_module->getId()),
		array('field' => 'name', 'value' => 'title')
	);
	
	$title_field = $field_module->searchRecords($criteria);
	$title_field = array_pop( $title_field );
    
    $image_file_query = array(
        'image-file' => $image_file
    );
   
    $add_image_settings = array(
        'attributes' => array(
            'class' => 'clear-fix standard pure-g-r pure-form js-upload-form',
            //'action' => 'upload-details.php?'.http_build_query($image_file_query)
            'action' => 'upload-details.php'
        ),
        'html_start' => '<li class="pure-u-1-4" id="image-x"><figure>',
        'html_start2' => '<figcaption>',
        'image_urls' => $cropped_url,
        'html_end' => '</figcaption></figure></li>'
    );

    /******************** Build the image fields ********************/

    $add_image_structure = array();

    for ( $i = 0; $i < count($cropped_url); ++$i ) { //Loop for creating all of the fields.
    	
    	 $add_image_structure['gallery'.$i] = array(
            'label' => 'Choose a gallery:', //$type_gallery_name . ' gallery',
            'fieldset' => 'fieldset-'.$i,
            'type' => 'select',
            'options' => $gallery_options,
            'validation' => array(
                'instance' => array()
            )
        );

        $add_image_structure['title'.$i] = array(
            //'label' => 'Title',
            'fieldset' => 'fieldset-'.$i,
            'validation' => array(
                'instance' => array(),
                'unique' => array(null, $title_field, $image_module)
            ),
            'attributes' => array(
                'placeholder' => 'Title'
            ),
            'value' => stripslashes($title[$i])
        );
      
        $add_image_structure['image'.$i] = array(
            'fieldset' => 'fieldset-'.$i,
            'type' => 'text',
            'attributes' => array(
                'type' => 'hidden',
            ),
            'value' => $real_url[$i]
        );
    
        $add_image_structure['video_url'.$i] = array(
            'fieldset' => 'fieldset-'.$i,
            'type' => 'text',
            'attributes' => array(
                'type' => 'hidden',
            ),
            'value' => $video_url[$i]
        );
        
        $add_image_structure['type_gallery'.$i] = array(
            'fieldset' => 'fieldset-'.$i,
            'type' => 'text',
            'attributes' => array(
                'type' => 'hidden',
            ),
            'value' => $type_gallery
        );
    
        $add_image_structure['description'.$i] = array(
            //'label' => 'Description',
            'fieldset' => 'fieldset-'.$i,
            
            'type' => 'textarea',
            'attributes' => array(
                'placeholder' => 'Description'
            ),
            'value' => stripslashes($description[$i])
        );

        $add_image_structure['tags'.$i] = array(
            //'label' => 'Tags',
            'fieldset' => 'fieldset-'.$i,
            //'tooltip' => "Separate with a comma ','.",
            'attributes' => array(
                'placeholder' => 'Tags',
                'data-value' => !empty($_POST['hidden-tags'.$i]) ? $_POST['hidden-tags'.$i] : '',
                'class' => 'tm-input'
            )
        );
    
        $add_image_structure['hidden-tags'.$i] = array(
            'fieldset' => 'fieldset-'.$i,
            'type' => 'text',
            'attributes' => array(
                'type' => 'hidden',
            ),
            'value' => !empty($_POST['hidden-tags'.$i]) ? $_POST['hidden-tags'.$i] : ''
        );
              
        $add_image_structure['remove-btn-'.$i] = array(
            'fieldset' => 'fieldset-'.$i,
            'type' => 'link',
            'text' => 'Remove',
            'icon' => '<i class="check icon"></i>',
            'attributes' => array(
                'href' => '#',
                'class' => 'pure-button pure-button-primary remove-image'
            )
        );
        
    } //End for each loop
	
    $add_image_structure['gallery_type'] = array(
        'fieldset' => 'fieldset-bottom',
        'attributes' => array(
            'type' => 'hidden',
        ),
        'value' => $type_gallery
    );
    
    $add_image_structure['image_count'] = array(
        'fieldset' => 'fieldset-bottom',
        'attributes' => array(
            'type' => 'hidden',
        ),
        'value' => count($cropped_url)
    );
    
    $add_image_structure['image_count'] = array(
        'fieldset' => 'fieldset-bottom',
        'attributes' => array(
            'type' => 'hidden',
        ),
        'value' => count($cropped_url)
    );

    $add_image_structure['submit'] = array(
        'type' => 'submit',
        'fieldset' => 'fieldset-bottom',
        'icon' => '<i class="checkmark icon"></i>',
        'attributes' => array(
            'value' => 'Save',
            'class' => 'pure-button pure-button-primary submit'
        )
    );
    
    $add_image_structure['cancel'] = array(
        'type' => 'submit',
        'icon' => '<i class="cross icon"></i>',
        'fieldset' => 'fieldset-bottom',
        'attributes' => array(
            'value' => 'Cancel',
            'class' => 'button-red pure-button pure-button-primary cancel'
        )
    );

    $add_image_form = new MK_Form($add_image_structure, $add_image_settings);
	
	// If the user clicks 'Cancel' then send them to the main gallery page
	if( $add_image_form->isSubmitted() && $add_image_form->getField('cancel')->getValue() ) { //User clicked cancel.

        header('Location: '.MK_Utility::serverUrl($this_filename), true, 302);
        exit();
    
	} elseif( $add_image_form->isSuccessful() ) { // Form is successfull then create the record and direct them to the home page
    
		$image_count = (integer) $add_image_form->getField('image_count')->getValue();
		
		$current_image = 0;
		
        while( $image_count > $current_image ) {
        
			if( $add_image_form->isField('gallery'.$current_image) ) {
            
				$new_image = MK_RecordManager::getNewRecord( $image_module->getId() );
                
				$new_image
					->setGallery( $add_image_form->getField('gallery'.$current_image)->getValue() )
					->setImage( $add_image_form->getField('image'.$current_image)->getValue() )
                    ->setVideoUrl( $add_image_form->getField('video_url'.$current_image)->getValue() )
					->setDescription( $add_image_form->getField('description'.$current_image)->getValue() )
					->setTitle( $add_image_form->getField('title'.$current_image)->getValue() )
					->setTags( $add_image_form->getField('hidden-tags'.$current_image)->getValue() )
                    ->setTypeGallery( $add_image_form->getField('type_gallery'.$current_image)->getValue() ) 
                    ->setImageSlug( seoUrl($add_image_form->getField('title'.$current_image)->getValue()) )
					->setUser( $user->getId() )
					->save(); 
		  
          
                $action_log_module = MK_RecordModuleManager::getFromType('action_log');
                $new_logged_action = MK_RecordManager::getNewRecord($action_log_module->getId());
          
                if($add_image_form->getField('type_gallery'.$current_image)->getValue() == 2) {
                
                    $user->addNotification('<a href="'.$user->getUsername().'">'.$user->getDisplayName().'</a> shared the video <a href="video/'.$new_image->getImageSlug().'">'.$new_image->getTitle().'</a>');
                
                    $new_logged_action
                    ->setUser( $user->getId() )
                    ->setAction('Shared the video <a href="?module_path=images/index/method/edit/id/'.$new_image->getId().'">'.$new_image->getTitle().'</a>')
                    ->save();
                
                } else {

                    $user->addNotification('<a href="' . $user->getUsername() . '">'.$user->getDisplayName().'</a> uploaded the image <a href="image/' . $new_image->getImageSlug() .'">'.$new_image->getTitle().'</a>');
                
                    $new_logged_action
                    ->setUser( $user->getId() )
                    ->setAction('Uploaded the image <a href="?module_path=images/index/method/edit/id/'.$new_image->getId().'">'.$new_image->getTitle().'</a>')
                    ->save();
                    
                }
                
			
            }
		
			$current_image++;
		
        } //End while loop.

		header('Location: '.MK_Utility::serverUrl('index.php'), true, 302);
		exit;
    
	}

    //Include header.
    require_once 'header.php'; ?>   

    <script>
        jQuery(document).ready( function() { <?php  
        
            for ( $i = 0; $i < count($cropped_url); ++$i ) { //Start PHP loop for each images tags.?> 
            
                jQuery(".tm-input:eq(<?php echo $i; ?>)").tagsManager({
                    tagsContainer: '.field-tags<?php echo $i; ?>',
                    prefilled: jQuery(".tm-input:eq(<?php echo $i; ?>)").attr('data-value').split(',')
                });<?php
                
            } ?>
        
        });
    </script>

    <div class="main-container">
    
        <div class="main wrapper clearfix pure-g-r">  
  
            <!-- Content Section Starts Here -->
            <?php include ('includes/upload-details.php') ?>
  
        </div>
  
    </div><?php 

    //Include Footer.
    include ('footer.php'); } 
	
else { //Not via POST method. Bounce outta here...

    header('Location: '.MK_Utility::serverUrl('index.php'), true, 302);
    exit;

} ?>