   CF Image Hosting Script 
   -------------------------

   Author:    codefuture.co.uk
   Version:   1.6.5

   Download the latest version from - http://codefuture.co.uk/projects/imagehost/

   Please Donate! - http://pledgie.com/campaigns/11487


   Updating instructions :
   -------------------------
   BEFORE UPDATING BACKUP YOUR UPLOAD AND INC FOLDERS!!!!
   Updating can be done in one of two ways.

   1) You can just copy all files from the zip file over the top of the old ones on your server. ( this is not the
       best way as some of the old files may have been renamed or removed from this update and they would be
       left on your server)

   2) Remove all files and folders other then the UPLOAD & INC FOLDERS from your server, then upload the
       new files from the zip to your server.
   
   Then just navigate to your site were the installer/updater script should run to check the file structure and
   setup any new settings.
   


   Install instructions :
   -------------------------
   Unzip all the files and upload them to your site , then navigate to your site were the installer script should
   run to check the file structure and setup the basic settings. If you encounter an error it will most likely be
   an error related to the script not being able to right a file or to a folder just follow the instructions to set
   permissions on the file or folder affected.

   After the installer is done you will need to delete the install folder from your server, then you can navigate to the admin page 
   (www.YourSite.com/admin.php) and use the username and password below (if updating use your login info), Once logged
   in you can navigate to the settings page and edit settings to your liking.

   Username: admin
   Password: password


   Copyright :
   -----------
   Copyright (c) 2010-12 codefuture.co.uk
   This file is part of the CF Image Hosting Script.


   Warranty :
   ----------
   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
   COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
   WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
   OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

   
   License Agreement :
   -------------------
   You should have received a full copy of the LICENSE AGREEMENT along with
   CF Image Hosting Script.  If not, see http://codefuture.co.uk/projects/imagehost/license/

