<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<title>Select a option</title>
<meta charset="UTF-8">
<meta name="author" content="HackkcaH">
<meta name="description" content="Arquivos para http injector ja configurado todas operadoras.">
<meta name="msapplication-TileColor" content="#000000">
<meta name="theme-color" content="#000000">
<link rel="shortcut icon" download href="/images/logos/logosite.png" type="image/x-png" />
<noscript> <meta http-equiv="Refresh" content="1; url=https://hackkcah.xyz/erro/erroscript.html"> </noscript>
<script src="vendor/jquery/jquery-3.4.1.min.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<script async src="vendor/bootstrap/js/popper.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<script async src="vendor/bootstrap/js/bootstrap.min.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<link async rel="stylesheet" type="text/css" href="/vendor/bootstrap/css/bootstrap.min.css">
<link async rel="stylesheet" href="vendor/bulma/bulma.min.css">
<link async rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
<link rel="stylesheet" type="text/css" href="cssmenu/style.css" />
<link rel="stylesheet" type="text/css" href="cssmenu/main.css">
<link rel="stylesheet" type="text/css" href="cssmenu/login.css">
<script src="js/skel.min.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<script src="js/init.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<script src="js/login.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<script src="js/recuperando.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<link rel="stylesheet" href="/vendor/CustomScrollBar/jquery.mCustomScrollbar.min.css">
<script src="vendor/CustomScrollBar/jquery.mCustomScrollbar.concat.min.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<link rel="stylesheet" href="cssmenu/menu.css">
<script src="js/menulateral.js" type="67596a9d9077d9293cd861ee-text/javascript"></script>
<link rel="stylesheet" download href="cssmenu/bootstrap.min_studio.css">
</head>
<body>

</div></center>
<div id="wrapper1">
<div class="d-flex flex-column" id="content-wrapper">
<div id="content">
<div class="container-fluid">
</br>
<style>
          #d14 { display: none; }#d18 { display: none; }#d21 { display: none; }          #apks{ display: none; }
          #escolha {
            background: white;
          }
          </style>
<script type="efa18ed8d868f1d216b0550c-text/javascript">
          function ocultatudo(){
            document.getElementById("apks").style.display = "none";
                              document.getElementById("d14").style.display = "none";
                              document.getElementById("d18").style.display = "none";
                              document.getElementById("d21").style.display = "none";
             }

          function escolhe(){
            ocultatudo();
            escolha = document.getElementById("escolha").value;
            if(escolha == 'apks'){ document.getElementById("apks").style.display = "block"; }
                              if(escolha == "d14"){ document.getElementById("d14").style.display = "block"; }
                              if(escolha == "d18"){ document.getElementById("d18").style.display = "block"; }
                              if(escolha == "d21"){ document.getElementById("d21").style.display = "block"; }
             }

          </script>
		  <p> Exemplo de select a option in php</p>
<select onchange="if (!window.__cfRLUnblockHandlers) return false; escolhe()" id="escolha" class="mdb-select md-form" data-cf-modified-efa18ed8d868f1d216b0550c-="">
<option selected disabled>Selecione uma opção</option>
<option value="apks">Mostrar apps</option>
<option value="d14">Arquivos servidor: CAN FREE (Sv Canada)</option>
<option value="d18">Arquivos servidor: BRA Premium</option>
<option value="d21">Arquivos servidor: SGP FREE (Sv Singapura)</option>
</select>
</div>
</div>
</div>
</div>
<div id="d14">
</br>
<div id="wrapper1">
<div class="d-flex flex-column" id="content-wrapper">
<div id="content">
<div class="container-fluid">
<div class="card shadow">
<div class="card-header py-3">
<p class="text-primary m-0 font-weight-bold">Arquivos</p>
</div>
<div class="card-body">
<div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
<table class="table dataTable my-0" id="dataTable">
<thead>
<tr>
<th>OPERADORA</th>
<th>APLICATIVO</th>
<th>SERVIDOR</th>
<th>DISPONIBILIDADE</th>
</tr>
</thead>
<tbody>

<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Direct</td>
 <td style="color: red;">HTTP Injector</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA-Direct.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Proxy</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA-SQUID.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logoclaro.png">Claro</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/ClaroBRA.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logotim.png">Tim</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/TimBRA.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logooi.png">Oi</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA</td>
<td>N/ Disponivel</td> </tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Direct</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA-Direct.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Proxy</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA-SQUID.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logoclaro.png">Claro</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/ClaroBRA.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logotim.png">Tim</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA</td>
<td><a target="_blank" download href="/html/uploads/files/free/TimBRA.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logooi.png">Oi</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA</td>
<td>N/ Disponivel</td> </tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</br>
<div id="d18">
<div id="wrapper1">
<div class="d-flex flex-column" id="content-wrapper">
<div id="content">
<div class="container-fluid">
<div class="card shadow">
<div class="card-header py-3">
<p class="text-primary m-0 font-weight-bold">Arquivos</p>
</div>
<div class="card-body">
<div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
<table class="table dataTable my-0" id="dataTable">
<thead>
<tr>
<th>OPERADORA</th>
<th>APLICATIVO</th>
<th>SERVIDOR</th>
<th>DISPONIBILIDADE</th>
</tr>
</thead>
<tbody>

<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Direct</td>
<td style="color: red;">HTTP Injector</td>
<td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/VivoBRAP-Direct.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Proxy</td>
<td style="color: red;">HTTP Injector</td>
<td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/VivoBRAP-SQUID.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logoclaro.png">Claro</td>
<td style="color: red;">HTTP Injector</td>
<td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/ClaroBRAP.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logotim.png">Tim</td>
<td style="color: red;">HTTP Injector</td>
 <td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/TimBRAP.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logooi.png">Oi</td>
<td style="color: red;">HTTP Injector</td>
<td>BRAP</td>
<td>N/ Disponivel</td> </tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Direct</td>
<td style="color: black;">SocksHTTP</td>
<td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/VivoBRAP-Direct.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Proxy</td>
<td style="color: black;">SocksHTTP</td>
<td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/VivoBRAP-SQUID.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logoclaro.png">Claro</td>
<td style="color: black;">SocksHTTP</td>
<td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/ClaroBRAP.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logotim.png">Tim</td>
<td style="color: black;">SocksHTTP</td>
<td>BRAP</td>
<td><a target="_blank" download href="/html/uploads/files/premium/TimBRAP.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logooi.png">Oi</td>
<td style="color: black;">SocksHTTP</td>
<td>BRAP</td>
<td>N/ Disponivel</td> </tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</br>
</div>
<div id="d21">
<div id="wrapper1">
<div class="d-flex flex-column" id="content-wrapper">
<div id="content">
<div class="container-fluid">
<div class="card shadow">
<div class="card-header py-3">
<p class="text-primary m-0 font-weight-bold">Arquivos</p>
</div>
<div class="card-body">
<div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
<table class="table dataTable my-0" id="dataTable">
<thead>
<tr>
<th>OPERADORA</th>
<th>APLICATIVO</th>
<th>SERVIDOR</th>
<th>DISPONIBILIDADE</th>
</tr>
</thead>
<tbody>

<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Direct</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA2-Direct.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Proxy</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA2-SQUID.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logoclaro.png">Claro</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/ClaroBRA2.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logotim.png">Tim</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/TimBRA2.ehi">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logooi.png">Oi</td>
<td style="color: red;">HTTP Injector</td>
<td>BRA2</td>
<td>N/ Disponivel</td> </tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Direct</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA2-Direct.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logovivo.png">Vivo Proxy</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/VivoBRA2-SQUID.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logoclaro.png">Claro</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/ClaroBRA2.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logotim.png">Tim</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA2</td>
<td><a target="_blank" download href="/html/uploads/files/free/TimBRA2.sks">Download</a></td> </tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logooi.png">Oi</td>
<td style="color: black;">SocksHTTP</td>
<td>BRA2</td>
<td>N/ Disponivel</td> </tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</br>
</div>
<div id="apks">
<div id="wrapper1">
<div class="d-flex flex-column" id="content-wrapper">
<div id="content">
<div class="container-fluid">
<div class="card shadow">
<div class="card-header py-3">
<p class="text-primary m-0 font-weight-bold">Aplicativos</p>
</div>
<div class="card-body">
<div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
<table class="table dataTable my-0" id="dataTable">
<thead>
<tr>
<th>APLICATIVO</th>
<th>VERSÃO</th>
<th>Download</th>
</tr>
</thead>
<tbody>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logosite.png">HKH VPN</td>
<td>2.1.5</td>
<td><a target="_blank" href="https://play.google.com/store/apps/details?id=app.hackkcah.xyz">PlayStore</a></td>
</tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logohttpi.png">HTTP Injector</td>
<td>5.0.7 (122)</td>
<td><a target="_blank" download href="/html/uploads/files/outros/apk/vpn/httpinjector.apk">Direto</a> / <a target="_blank" href="https://play.google.com/store/apps/details?id=com.evozi.injector">PlayStore</a></td>
</tr>
<tr>
<td><img class="rounded-circle mr-2" width="30" height="30" src="/images/logos/logosocks.png">SocksHTTP</td>
<td>1.1.1</td>
<td><a target="_blank" download href="/html/uploads/files/outros/apk/vpn/sockshttp.apk">Direto</a> / <a target="_blank" href="https://play.google.com/store/apps/details?id=com.slipkprojects.sockshttp">PlayStore</a></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</br>
</div>
</br></br></br>

</div>
</div>
</div>
</div>
</div>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="efa18ed8d868f1d216b0550c-|49" defer=""></script></body>
</html>
