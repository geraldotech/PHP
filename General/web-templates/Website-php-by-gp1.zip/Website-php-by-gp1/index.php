<!DOCTYPE html>
<html lang="en">
<head>
<title>CSS Website Layout 2</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="mystyle.css">

</head>
<body>

<div class="header">
  <h1>Header</h1>
  <p>Resize the browser window to see the responsive effect.</p>
</div>
 <?php include 'menu.php';?>


 
  <?php include 'side1.php';?>
  
  <?php include 'home.php';?>

  
  <div class="column side">
    <h2>Side2</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elits.sdsdsd.</p>
  </div>
</div>
  
</body>
</html>