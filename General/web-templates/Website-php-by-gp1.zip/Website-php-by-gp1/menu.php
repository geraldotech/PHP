<div class="topnav">
  <a href="index.php">Home</a>
  <a href="downloads.php">Downloads</a>
  <a href="sobre.php">Sobre</a>
</div>