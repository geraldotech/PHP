<div class="row">
  <div class="column side">
    <h2>Side1</h2>
    <p>Lado 1..</p>
  </div>