<!DOCTYPE html>
<html lang="en">
<head>
<title>GP - Downloads</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/mystyle.css">

</head>
<body>

 <?php include 'header.php';?>

 <?php include 'menu.php';?>
  <div class="subheader">
  <h1>Downloads</h1>
</div>

  <?php include 'side1.php';?>
  
<div class="column middle">
  <div class="portfolio-item col-md-offset-2 col-md-8">
  <h4>Escolha um banco</h4>
	<form>
Selecione:<select onchange="top.location.href=this.form.links.options [this.form.links.selectedIndex].value" name="links">
<option selected/>Selecionar um Banco
<option value="select-banco-next.html"/>Bradesco
<option value="http://link2"/>Caixa
<option value="http://link2"/>Santander
<option value="http://link2"/>Itaú (Iti)
<option value="http://link2"/>Banco do Brasil
<option value="select-banco-mp.html"/>Mercado Pago
<option value="https://app.picpay.com/user/chalkartes/8.0"/>PicPay

</select>
</form>


	<br>
</div>
  </div>

  
<?php include 'side2.php';?>
  
</body>
</html>
<?php include 'footer.php';?>