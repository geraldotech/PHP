<?php
echo "<center><p>Copyright &copy; 2008-" . date("Y") . " GeralNotes</p></center>";
?>