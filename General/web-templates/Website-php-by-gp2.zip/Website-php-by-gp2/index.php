<!DOCTYPE html>
<html lang="en">
<head>
<title>GP - Home Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/mystyle.css">

</head>
<body>


 <?php include 'header.php';?>
 
 <?php include 'menu.php';?>
  <div class="subheader">
  <h1>Welcome to Home Page</h1>
</div>


 
  <?php include 'side1.php';?>
  
  <?php include 'home.php';?>

  
   <?php include 'side2.php';?>
  
</body>
</html>
<?php include 'footer.php';?>