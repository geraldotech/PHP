  <div class="column side">
    <h2>Side2 - Last News</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elits.sdsdsd.</p>
  </div>
</div>