<div class="header">
  <h1>GP Notes</h1>
  <p>Resize the browser window to see the responsive effect.</p>
</div>