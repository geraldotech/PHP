<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/mystyle2.css">
</head>
<body>

 <?php include 'header.php';?>

 <?php include 'menu.php';?>

 <?php include 'home.php';?>
 <?php include 'aboutme.php';?>
 <?php include 'popular.php';?>
 <?php include 'followme.php';?>
 
  
   
  
</div>
 <?php include 'footer.php';?>

</body>
</html>
