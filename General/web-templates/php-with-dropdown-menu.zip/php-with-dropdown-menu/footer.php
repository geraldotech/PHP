<?php
echo "<center><p>Copyright &copy; 2008-" . date("Y") . " W3Schools.com</p></center>";
?>