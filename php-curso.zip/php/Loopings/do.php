<?php

//do executa antes de conferir ao contrario do while

$contador = 0;
do{
	//imprimir os numeros echo $contador;
	echo 'Ola mundo';
	echo '<br />';
	$contador++;
	}while($contador < 10);


?>