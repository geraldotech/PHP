<?php

$name = 'geraldo';

	for($contador=0;$contador<=10;$contador++){
		echo '<hr>';
		echo "Geraldo $contador";
		/*echo 'Geraldo' .$contador;*/
	}


?>