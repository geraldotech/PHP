<?php

//laco de repeticao while

//Tem que declamar a variavel antes

$contador = 0;
	while($contador <= 10){
			echo $contador;
		echo 'ola mundo';
		echo '<hr>';
		$contador+=1;

	}


?>