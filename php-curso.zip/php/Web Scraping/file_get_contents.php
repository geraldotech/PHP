<?php
$content = file_get_contents('https://cursos.dankicode.com/');


echo $content;
?>