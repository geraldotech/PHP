<?php
//PHP MAIS ANTIGO
$nome [] = 'JOAO';
echo $nome[0];
?>