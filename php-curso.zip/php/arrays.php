<?php

//array variaveis com varios valores
$nome = array ('chave1'=>'<h2>Geraldos</h2>','Petronilo','Mario');

echo $nome['chave1'];



?>

