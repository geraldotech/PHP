<?php

$nome =  ['Geraldo','Filho','Costa'];
$sucess ['0'] = '<h3 style="background-color:green;color:white;text-align:center;">sucess logado</h3>';

echo $sucess[0];


echo $nome[0];

?>