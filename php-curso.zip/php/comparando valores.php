<?php

$dia = '31';
$mes = 'Agosto';

if ($dia == '31' && $mes == 'Agosto') {
	echo "Parabens";
} else
{
	echo "nao e dia";
}

?>