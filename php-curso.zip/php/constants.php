<?php

define ('NOME','GERALDO');
define('NOME2', 'GE2RALDO');

if(NOME == NOME2){
	echo 'iguais';
} else {
	echo 'diferentes';
}

?>