<?php
$content = file_get_contents('http://cursos.dankicode.com/');


echo $content;
?>