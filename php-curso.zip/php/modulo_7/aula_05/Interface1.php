<?php
	
	interface Interface1{

		public function printOnScreen($par);

	}

?>