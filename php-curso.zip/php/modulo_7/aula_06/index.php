<?php
	include('Class1.php');
	$teste = new Class1('Guilherme',23);

	echo $teste->getIdade();
?>