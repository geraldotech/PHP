<?php
	namespace Sessao2;
	
	class Class2
	{
		
		function __construct()
		{
			echo 'Class2 instanciada';
		}
	}
?>