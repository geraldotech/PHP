<?php
	include('Class1.php');
	include('Class2.php');

	use \Sessao1\Class1 as classe_exemplo;

	$class1 = new classe_exemplo;
?>