<?php

	namespace Home;

	class Inicial
	{
		
		function __construct()
		{
			//echo 'Classe inicial chamada com sucesso!';
		}
	}

?>