<?php
	/**
	* 
	*/
	class Utilidades
	{
		
		function __construct()
		{
			echo 'Classe Utilidades foi chamada com sucesso!';
		}
	}
?>