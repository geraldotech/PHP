<?php

	include('config.php');

	//new Utilidades();

	new Home\Inicial();
	
?>