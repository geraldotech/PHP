<?php

$n1 = 10;
$n2 = 5;

$soma = $n1 + $n2;

echo $soma;

?>