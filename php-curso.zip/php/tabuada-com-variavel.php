<?php
$x = 5;
for ($cont=1;$cont<=10;$cont++) {
	echo '<br />';
	echo "$x x $cont = ";
	echo $x * $cont;
}
	

?>